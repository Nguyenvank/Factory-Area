﻿namespace Fan_1
{
    partial class frmAssyFromPLC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAssyFromPLC));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_A06_AL = new System.Windows.Forms.Label();
            this.lbl_A05_AL = new System.Windows.Forms.Label();
            this.lbl_A04_AL = new System.Windows.Forms.Label();
            this.lbl_A03_AL = new System.Windows.Forms.Label();
            this.lbl_A02_AL = new System.Windows.Forms.Label();
            this.lbl_A01_AL = new System.Windows.Forms.Label();
            this.lbl_A01_PV = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lbl_A01_SV = new System.Windows.Forms.Label();
            this.lbl_A06_PV = new System.Windows.Forms.Label();
            this.lbl_A05_PV = new System.Windows.Forms.Label();
            this.lbl_A04_PV = new System.Windows.Forms.Label();
            this.lbl_A03_PV = new System.Windows.Forms.Label();
            this.lbl_A02_PV = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lbl_P12_AL = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.lbl_A06_SV = new System.Windows.Forms.Label();
            this.lbl_A05_SV = new System.Windows.Forms.Label();
            this.lbl_A04_SV = new System.Windows.Forms.Label();
            this.lbl_A03_SV = new System.Windows.Forms.Label();
            this.lbl_A02_SV = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lbl_P12_PV = new System.Windows.Forms.Label();
            this.lbl_P12_SV = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.lbl_P11_AL = new System.Windows.Forms.Label();
            this.lbl_P10_AL = new System.Windows.Forms.Label();
            this.lbl_P09_AL = new System.Windows.Forms.Label();
            this.lbl_P08_AL = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.lbl_P04_AL = new System.Windows.Forms.Label();
            this.lbl_P03_AL = new System.Windows.Forms.Label();
            this.lbl_P11_SV = new System.Windows.Forms.Label();
            this.lbl_P11_PV = new System.Windows.Forms.Label();
            this.lbl_P10_PV = new System.Windows.Forms.Label();
            this.lbl_P09_PV = new System.Windows.Forms.Label();
            this.lbl_P08_PV = new System.Windows.Forms.Label();
            this.lbl_P10_SV = new System.Windows.Forms.Label();
            this.lbl_P09_SV = new System.Windows.Forms.Label();
            this.lbl_P08_SV = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lbl_P07_AL = new System.Windows.Forms.Label();
            this.lbl_P06_AL = new System.Windows.Forms.Label();
            this.lbl_P05_AL = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.lbl_P02_AL = new System.Windows.Forms.Label();
            this.lbl_P01_AL = new System.Windows.Forms.Label();
            this.lbl_P01_PV = new System.Windows.Forms.Label();
            this.lbl_P01_SV = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_P07_SV = new System.Windows.Forms.Label();
            this.lbl_P06_SV = new System.Windows.Forms.Label();
            this.lbl_P05_SV = new System.Windows.Forms.Label();
            this.lbl_P04_SV = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lbl_P07_PV = new System.Windows.Forms.Label();
            this.lbl_P06_PV = new System.Windows.Forms.Label();
            this.lbl_P05_PV = new System.Windows.Forms.Label();
            this.lbl_P04_PV = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_P03_SV = new System.Windows.Forms.Label();
            this.lbl_P02_SV = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAB02OK = new System.Windows.Forms.TextBox();
            this.txtAB03OK = new System.Windows.Forms.TextBox();
            this.txtDI01OK = new System.Windows.Forms.TextBox();
            this.txtDI02OK = new System.Windows.Forms.TextBox();
            this.lbl_P03_PV = new System.Windows.Forms.Label();
            this.lbl_P02_PV = new System.Windows.Forms.Label();
            this.txtPU01OK = new System.Windows.Forms.TextBox();
            this.txtWB01OK = new System.Windows.Forms.TextBox();
            this.txtBL01OK = new System.Windows.Forms.TextBox();
            this.txtWB02OK = new System.Windows.Forms.TextBox();
            this.txtBL02OK = new System.Windows.Forms.TextBox();
            this.txtWB03OK = new System.Windows.Forms.TextBox();
            this.txtMX01OK = new System.Windows.Forms.TextBox();
            this.txtWD01OK = new System.Windows.Forms.TextBox();
            this.txtWD02OK = new System.Windows.Forms.TextBox();
            this.txtPU01NG = new System.Windows.Forms.TextBox();
            this.txtDI02NG = new System.Windows.Forms.TextBox();
            this.txtDI01NG = new System.Windows.Forms.TextBox();
            this.txtAB03NG = new System.Windows.Forms.TextBox();
            this.txtAB02NG = new System.Windows.Forms.TextBox();
            this.txtAB01NG = new System.Windows.Forms.TextBox();
            this.txtAB01OK = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.chkConnect = new System.Windows.Forms.CheckBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.chkOperate = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtWB04OK = new System.Windows.Forms.TextBox();
            this.lbl_R01 = new System.Windows.Forms.Label();
            this.lbl_R01_SV = new System.Windows.Forms.Label();
            this.lbl_R02 = new System.Windows.Forms.Label();
            this.lbl_R02_SV = new System.Windows.Forms.Label();
            this.lbl_R03_SV = new System.Windows.Forms.Label();
            this.lbl_R04_SV = new System.Windows.Forms.Label();
            this.lbl_R05_SV = new System.Windows.Forms.Label();
            this.lbl_R06_SV = new System.Windows.Forms.Label();
            this.lbl_R07_SV = new System.Windows.Forms.Label();
            this.lbl_R08_SV = new System.Windows.Forms.Label();
            this.lbl_R09_SV = new System.Windows.Forms.Label();
            this.lbl_R10_SV = new System.Windows.Forms.Label();
            this.lbl_R11_SV = new System.Windows.Forms.Label();
            this.lbl_R12_SV = new System.Windows.Forms.Label();
            this.lbl_R13_SV = new System.Windows.Forms.Label();
            this.lbl_R14_SV = new System.Windows.Forms.Label();
            this.lbl_R15_SV = new System.Windows.Forms.Label();
            this.lbl_R16_SV = new System.Windows.Forms.Label();
            this.lbl_R16 = new System.Windows.Forms.Label();
            this.lbl_R15 = new System.Windows.Forms.Label();
            this.lbl_R14 = new System.Windows.Forms.Label();
            this.lbl_R13 = new System.Windows.Forms.Label();
            this.lbl_R12 = new System.Windows.Forms.Label();
            this.lbl_R11 = new System.Windows.Forms.Label();
            this.lbl_R10 = new System.Windows.Forms.Label();
            this.lbl_R09 = new System.Windows.Forms.Label();
            this.lbl_R08 = new System.Windows.Forms.Label();
            this.lbl_R07 = new System.Windows.Forms.Label();
            this.lbl_R06 = new System.Windows.Forms.Label();
            this.lbl_R05 = new System.Windows.Forms.Label();
            this.lbl_R04 = new System.Windows.Forms.Label();
            this.lbl_R03 = new System.Windows.Forms.Label();
            this.lbl_R01_PV = new System.Windows.Forms.Label();
            this.lbl_R02_PV = new System.Windows.Forms.Label();
            this.lbl_R03_PV = new System.Windows.Forms.Label();
            this.lbl_R04_PV = new System.Windows.Forms.Label();
            this.lbl_R05_PV = new System.Windows.Forms.Label();
            this.lbl_R06_PV = new System.Windows.Forms.Label();
            this.lbl_R07_PV = new System.Windows.Forms.Label();
            this.lbl_R08_PV = new System.Windows.Forms.Label();
            this.lbl_R09_PV = new System.Windows.Forms.Label();
            this.lbl_R10_PV = new System.Windows.Forms.Label();
            this.lbl_R11_PV = new System.Windows.Forms.Label();
            this.lbl_R12_PV = new System.Windows.Forms.Label();
            this.lbl_R13_PV = new System.Windows.Forms.Label();
            this.lbl_R14_PV = new System.Windows.Forms.Label();
            this.lbl_R15_PV = new System.Windows.Forms.Label();
            this.lbl_R16_PV = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.lbl_R01_AL = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lbl_R02_AL = new System.Windows.Forms.Label();
            this.lbl_R03_AL = new System.Windows.Forms.Label();
            this.lbl_R04_AL = new System.Windows.Forms.Label();
            this.lbl_R05_AL = new System.Windows.Forms.Label();
            this.lbl_R06_AL = new System.Windows.Forms.Label();
            this.lbl_R07_AL = new System.Windows.Forms.Label();
            this.lbl_R08_AL = new System.Windows.Forms.Label();
            this.lbl_R09_AL = new System.Windows.Forms.Label();
            this.lbl_R10_AL = new System.Windows.Forms.Label();
            this.lbl_R11_AL = new System.Windows.Forms.Label();
            this.lbl_R12_AL = new System.Windows.Forms.Label();
            this.lbl_R13_AL = new System.Windows.Forms.Label();
            this.lbl_R14_AL = new System.Windows.Forms.Label();
            this.lbl_R15_AL = new System.Windows.Forms.Label();
            this.lbl_R16_AL = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_R_Start = new System.Windows.Forms.Label();
            this.lbl_P_Start = new System.Windows.Forms.Label();
            this.lbl_A_Start = new System.Windows.Forms.Label();
            this.lbl_R_DT = new System.Windows.Forms.Label();
            this.lbl_P_DT = new System.Windows.Forms.Label();
            this.lbl_A_DT = new System.Windows.Forms.Label();
            this.chk_R_Connect = new System.Windows.Forms.CheckBox();
            this.chk_P_Connect = new System.Windows.Forms.CheckBox();
            this.chk_A_Connect = new System.Windows.Forms.CheckBox();
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 25;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4F));
            this.tableLayoutPanel1.Controls.Add(this.lbl_A06_AL, 24, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A05_AL, 24, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A04_AL, 24, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A03_AL, 24, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A02_AL, 24, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A01_AL, 24, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A01_PV, 23, 3);
            this.tableLayoutPanel1.Controls.Add(this.label31, 24, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A01_SV, 22, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A06_PV, 23, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A05_PV, 23, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A04_PV, 23, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A03_PV, 23, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A02_PV, 23, 4);
            this.tableLayoutPanel1.Controls.Add(this.label46, 20, 3);
            this.tableLayoutPanel1.Controls.Add(this.label29, 23, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P12_AL, 19, 14);
            this.tableLayoutPanel1.Controls.Add(this.label45, 15, 14);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A06_SV, 22, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A05_SV, 22, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A04_SV, 22, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A03_SV, 22, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A02_SV, 22, 4);
            this.tableLayoutPanel1.Controls.Add(this.label27, 22, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P12_PV, 18, 14);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P12_SV, 17, 14);
            this.tableLayoutPanel1.Controls.Add(this.label25, 20, 2);
            this.tableLayoutPanel1.Controls.Add(this.label86, 20, 8);
            this.tableLayoutPanel1.Controls.Add(this.label85, 20, 7);
            this.tableLayoutPanel1.Controls.Add(this.label84, 20, 6);
            this.tableLayoutPanel1.Controls.Add(this.label83, 20, 5);
            this.tableLayoutPanel1.Controls.Add(this.label82, 20, 4);
            this.tableLayoutPanel1.Controls.Add(this.label44, 15, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P11_AL, 19, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P10_AL, 19, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P09_AL, 19, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P08_AL, 19, 10);
            this.tableLayoutPanel1.Controls.Add(this.label43, 15, 12);
            this.tableLayoutPanel1.Controls.Add(this.label42, 15, 11);
            this.tableLayoutPanel1.Controls.Add(this.label41, 15, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P04_AL, 19, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P03_AL, 19, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P11_SV, 17, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P11_PV, 18, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P10_PV, 18, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P09_PV, 18, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P08_PV, 18, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P10_SV, 17, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P09_SV, 17, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P08_SV, 17, 10);
            this.tableLayoutPanel1.Controls.Add(this.label40, 15, 9);
            this.tableLayoutPanel1.Controls.Add(this.label39, 15, 8);
            this.tableLayoutPanel1.Controls.Add(this.label38, 15, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P07_AL, 19, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P06_AL, 19, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P05_AL, 19, 7);
            this.tableLayoutPanel1.Controls.Add(this.label37, 15, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P02_AL, 19, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P01_AL, 19, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P01_PV, 18, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P01_SV, 17, 3);
            this.tableLayoutPanel1.Controls.Add(this.label20, 15, 3);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P07_SV, 17, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P06_SV, 17, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P05_SV, 17, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P04_SV, 17, 6);
            this.tableLayoutPanel1.Controls.Add(this.label30, 19, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P07_PV, 18, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P06_PV, 18, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P05_PV, 18, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P04_PV, 18, 6);
            this.tableLayoutPanel1.Controls.Add(this.label36, 15, 5);
            this.tableLayoutPanel1.Controls.Add(this.label35, 15, 4);
            this.tableLayoutPanel1.Controls.Add(this.label28, 18, 2);
            this.tableLayoutPanel1.Controls.Add(this.label26, 17, 2);
            this.tableLayoutPanel1.Controls.Add(this.label24, 15, 2);
            this.tableLayoutPanel1.Controls.Add(this.label10, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label11, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.label14, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.label17, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.label15, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.label8, 6, 12);
            this.tableLayoutPanel1.Controls.Add(this.label9, 6, 13);
            this.tableLayoutPanel1.Controls.Add(this.label12, 6, 14);
            this.tableLayoutPanel1.Controls.Add(this.label13, 1, 17);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P03_SV, 17, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P02_SV, 17, 4);
            this.tableLayoutPanel1.Controls.Add(this.label16, 1, 18);
            this.tableLayoutPanel1.Controls.Add(this.txtAB02OK, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtAB03OK, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtDI01OK, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtDI02OK, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P03_PV, 18, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P02_PV, 18, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtPU01OK, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.txtWB01OK, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.txtBL01OK, 8, 12);
            this.tableLayoutPanel1.Controls.Add(this.txtWB02OK, 3, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtBL02OK, 8, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtWB03OK, 3, 14);
            this.tableLayoutPanel1.Controls.Add(this.txtMX01OK, 8, 14);
            this.tableLayoutPanel1.Controls.Add(this.txtWD01OK, 3, 17);
            this.tableLayoutPanel1.Controls.Add(this.txtWD02OK, 3, 18);
            this.tableLayoutPanel1.Controls.Add(this.txtPU01NG, 8, 10);
            this.tableLayoutPanel1.Controls.Add(this.txtDI02NG, 8, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtDI01NG, 8, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtAB03NG, 8, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtAB02NG, 8, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtAB01NG, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtAB01OK, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblStatus, 6, 16);
            this.tableLayoutPanel1.Controls.Add(this.chkConnect, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblMessage, 0, 19);
            this.tableLayoutPanel1.Controls.Add(this.chkOperate, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 6, 18);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.txtWB04OK, 3, 15);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R01, 10, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R01_SV, 12, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R02, 10, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R02_SV, 12, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R03_SV, 12, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R04_SV, 12, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R05_SV, 12, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R06_SV, 12, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R07_SV, 12, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R08_SV, 12, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R09_SV, 12, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R10_SV, 12, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R11_SV, 12, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R12_SV, 12, 14);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R13_SV, 12, 15);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R14_SV, 12, 16);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R15_SV, 12, 17);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R16_SV, 12, 18);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R16, 10, 18);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R15, 10, 17);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R14, 10, 16);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R13, 10, 15);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R12, 10, 14);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R11, 10, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R10, 10, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R09, 10, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R08, 10, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R07, 10, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R06, 10, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R05, 10, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R04, 10, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R03, 10, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R01_PV, 13, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R02_PV, 13, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R03_PV, 13, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R04_PV, 13, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R05_PV, 13, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R06_PV, 13, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R07_PV, 13, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R08_PV, 13, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R09_PV, 13, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R10_PV, 13, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R11_PV, 13, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R12_PV, 13, 14);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R13_PV, 13, 15);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R14_PV, 13, 16);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R15_PV, 13, 17);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R16_PV, 13, 18);
            this.tableLayoutPanel1.Controls.Add(this.label66, 12, 2);
            this.tableLayoutPanel1.Controls.Add(this.label67, 13, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R01_AL, 14, 3);
            this.tableLayoutPanel1.Controls.Add(this.label19, 14, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R02_AL, 14, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R03_AL, 14, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R04_AL, 14, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R05_AL, 14, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R06_AL, 14, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R07_AL, 14, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R08_AL, 14, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R09_AL, 14, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R10_AL, 14, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R11_AL, 14, 13);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R12_AL, 14, 14);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R13_AL, 14, 15);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R14_AL, 14, 16);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R15_AL, 14, 17);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R16_AL, 14, 18);
            this.tableLayoutPanel1.Controls.Add(this.label18, 10, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R_Start, 10, 19);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P_Start, 15, 15);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A_Start, 20, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl_R_DT, 13, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_P_DT, 18, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_A_DT, 23, 0);
            this.tableLayoutPanel1.Controls.Add(this.chk_R_Connect, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.chk_P_Connect, 15, 0);
            this.tableLayoutPanel1.Controls.Add(this.chk_A_Connect, 20, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 20;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1150, 537);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lbl_A06_AL
            // 
            this.lbl_A06_AL.AutoSize = true;
            this.lbl_A06_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_A06_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A06_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A06_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A06_AL.Location = new System.Drawing.Point(1105, 209);
            this.lbl_A06_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_A06_AL.Name = "lbl_A06_AL";
            this.lbl_A06_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_A06_AL.TabIndex = 0;
            this.lbl_A06_AL.Text = "0";
            this.lbl_A06_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A05_AL
            // 
            this.lbl_A05_AL.AutoSize = true;
            this.lbl_A05_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_A05_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A05_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A05_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A05_AL.Location = new System.Drawing.Point(1105, 183);
            this.lbl_A05_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_A05_AL.Name = "lbl_A05_AL";
            this.lbl_A05_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_A05_AL.TabIndex = 0;
            this.lbl_A05_AL.Text = "0";
            this.lbl_A05_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A04_AL
            // 
            this.lbl_A04_AL.AutoSize = true;
            this.lbl_A04_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_A04_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A04_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A04_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A04_AL.Location = new System.Drawing.Point(1105, 157);
            this.lbl_A04_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_A04_AL.Name = "lbl_A04_AL";
            this.lbl_A04_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_A04_AL.TabIndex = 0;
            this.lbl_A04_AL.Text = "0";
            this.lbl_A04_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A03_AL
            // 
            this.lbl_A03_AL.AutoSize = true;
            this.lbl_A03_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_A03_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A03_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A03_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A03_AL.Location = new System.Drawing.Point(1105, 131);
            this.lbl_A03_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_A03_AL.Name = "lbl_A03_AL";
            this.lbl_A03_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_A03_AL.TabIndex = 0;
            this.lbl_A03_AL.Text = "0";
            this.lbl_A03_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A02_AL
            // 
            this.lbl_A02_AL.AutoSize = true;
            this.lbl_A02_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_A02_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A02_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A02_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A02_AL.Location = new System.Drawing.Point(1105, 105);
            this.lbl_A02_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_A02_AL.Name = "lbl_A02_AL";
            this.lbl_A02_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_A02_AL.TabIndex = 0;
            this.lbl_A02_AL.Text = "0";
            this.lbl_A02_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A01_AL
            // 
            this.lbl_A01_AL.AutoSize = true;
            this.lbl_A01_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_A01_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A01_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A01_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A01_AL.Location = new System.Drawing.Point(1105, 79);
            this.lbl_A01_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_A01_AL.Name = "lbl_A01_AL";
            this.lbl_A01_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_A01_AL.TabIndex = 0;
            this.lbl_A01_AL.Text = "0";
            this.lbl_A01_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A01_PV
            // 
            this.lbl_A01_PV.AutoSize = true;
            this.lbl_A01_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A01_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A01_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A01_PV.Location = new System.Drawing.Point(1061, 81);
            this.lbl_A01_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A01_PV.Name = "lbl_A01_PV";
            this.lbl_A01_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A01_PV.TabIndex = 0;
            this.lbl_A01_PV.Text = "0";
            this.lbl_A01_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(1107, 55);
            this.label31.Margin = new System.Windows.Forms.Padding(3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 20);
            this.label31.TabIndex = 0;
            this.label31.Text = "AL";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A01_SV
            // 
            this.lbl_A01_SV.AutoSize = true;
            this.lbl_A01_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A01_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A01_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A01_SV.Location = new System.Drawing.Point(1015, 81);
            this.lbl_A01_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A01_SV.Name = "lbl_A01_SV";
            this.lbl_A01_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A01_SV.TabIndex = 0;
            this.lbl_A01_SV.Text = "0";
            this.lbl_A01_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A06_PV
            // 
            this.lbl_A06_PV.AutoSize = true;
            this.lbl_A06_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A06_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A06_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A06_PV.Location = new System.Drawing.Point(1061, 211);
            this.lbl_A06_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A06_PV.Name = "lbl_A06_PV";
            this.lbl_A06_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A06_PV.TabIndex = 0;
            this.lbl_A06_PV.Text = "0";
            this.lbl_A06_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A05_PV
            // 
            this.lbl_A05_PV.AutoSize = true;
            this.lbl_A05_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A05_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A05_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A05_PV.Location = new System.Drawing.Point(1061, 185);
            this.lbl_A05_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A05_PV.Name = "lbl_A05_PV";
            this.lbl_A05_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A05_PV.TabIndex = 0;
            this.lbl_A05_PV.Text = "0";
            this.lbl_A05_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A04_PV
            // 
            this.lbl_A04_PV.AutoSize = true;
            this.lbl_A04_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A04_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A04_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A04_PV.Location = new System.Drawing.Point(1061, 159);
            this.lbl_A04_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A04_PV.Name = "lbl_A04_PV";
            this.lbl_A04_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A04_PV.TabIndex = 0;
            this.lbl_A04_PV.Text = "0";
            this.lbl_A04_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A03_PV
            // 
            this.lbl_A03_PV.AutoSize = true;
            this.lbl_A03_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A03_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A03_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A03_PV.Location = new System.Drawing.Point(1061, 133);
            this.lbl_A03_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A03_PV.Name = "lbl_A03_PV";
            this.lbl_A03_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A03_PV.TabIndex = 0;
            this.lbl_A03_PV.Text = "0";
            this.lbl_A03_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A02_PV
            // 
            this.lbl_A02_PV.AutoSize = true;
            this.lbl_A02_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A02_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A02_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A02_PV.Location = new System.Drawing.Point(1061, 107);
            this.lbl_A02_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A02_PV.Name = "lbl_A02_PV";
            this.lbl_A02_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A02_PV.TabIndex = 0;
            this.lbl_A02_PV.Text = "0";
            this.lbl_A02_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label46, 2);
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(923, 81);
            this.label46.Margin = new System.Windows.Forms.Padding(3);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(86, 20);
            this.label46.TabIndex = 0;
            this.label46.Text = "Welding 01:";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(1061, 55);
            this.label29.Margin = new System.Windows.Forms.Padding(3);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(40, 20);
            this.label29.TabIndex = 0;
            this.label29.Text = "PV";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P12_AL
            // 
            this.lbl_P12_AL.AutoSize = true;
            this.lbl_P12_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P12_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P12_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P12_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P12_AL.Location = new System.Drawing.Point(875, 365);
            this.lbl_P12_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P12_AL.Name = "lbl_P12_AL";
            this.lbl_P12_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P12_AL.TabIndex = 0;
            this.lbl_P12_AL.Text = "0";
            this.lbl_P12_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label45, 2);
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(693, 367);
            this.label45.Margin = new System.Windows.Forms.Padding(3);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(86, 20);
            this.label45.TabIndex = 0;
            this.label45.Text = "Injection 12:";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_A06_SV
            // 
            this.lbl_A06_SV.AutoSize = true;
            this.lbl_A06_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A06_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A06_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A06_SV.Location = new System.Drawing.Point(1015, 211);
            this.lbl_A06_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A06_SV.Name = "lbl_A06_SV";
            this.lbl_A06_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A06_SV.TabIndex = 0;
            this.lbl_A06_SV.Text = "0";
            this.lbl_A06_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A05_SV
            // 
            this.lbl_A05_SV.AutoSize = true;
            this.lbl_A05_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A05_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A05_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A05_SV.Location = new System.Drawing.Point(1015, 185);
            this.lbl_A05_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A05_SV.Name = "lbl_A05_SV";
            this.lbl_A05_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A05_SV.TabIndex = 0;
            this.lbl_A05_SV.Text = "0";
            this.lbl_A05_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A04_SV
            // 
            this.lbl_A04_SV.AutoSize = true;
            this.lbl_A04_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A04_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A04_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A04_SV.Location = new System.Drawing.Point(1015, 159);
            this.lbl_A04_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A04_SV.Name = "lbl_A04_SV";
            this.lbl_A04_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A04_SV.TabIndex = 0;
            this.lbl_A04_SV.Text = "0";
            this.lbl_A04_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A03_SV
            // 
            this.lbl_A03_SV.AutoSize = true;
            this.lbl_A03_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A03_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A03_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A03_SV.Location = new System.Drawing.Point(1015, 133);
            this.lbl_A03_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A03_SV.Name = "lbl_A03_SV";
            this.lbl_A03_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A03_SV.TabIndex = 0;
            this.lbl_A03_SV.Text = "0";
            this.lbl_A03_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A02_SV
            // 
            this.lbl_A02_SV.AutoSize = true;
            this.lbl_A02_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_A02_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A02_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_A02_SV.Location = new System.Drawing.Point(1015, 107);
            this.lbl_A02_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A02_SV.Name = "lbl_A02_SV";
            this.lbl_A02_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_A02_SV.TabIndex = 0;
            this.lbl_A02_SV.Text = "0";
            this.lbl_A02_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(1015, 55);
            this.label27.Margin = new System.Windows.Forms.Padding(3);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 20);
            this.label27.TabIndex = 0;
            this.label27.Text = "SV";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P12_PV
            // 
            this.lbl_P12_PV.AutoSize = true;
            this.lbl_P12_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P12_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P12_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P12_PV.Location = new System.Drawing.Point(831, 367);
            this.lbl_P12_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P12_PV.Name = "lbl_P12_PV";
            this.lbl_P12_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P12_PV.TabIndex = 0;
            this.lbl_P12_PV.Text = "0";
            this.lbl_P12_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P12_SV
            // 
            this.lbl_P12_SV.AutoSize = true;
            this.lbl_P12_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P12_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P12_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P12_SV.Location = new System.Drawing.Point(785, 367);
            this.lbl_P12_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P12_SV.Name = "lbl_P12_SV";
            this.lbl_P12_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P12_SV.TabIndex = 0;
            this.lbl_P12_SV.Text = "0";
            this.lbl_P12_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label25, 2);
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(923, 55);
            this.label25.Margin = new System.Windows.Forms.Padding(3);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(86, 20);
            this.label25.TabIndex = 0;
            this.label25.Text = "MACHINES";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label86, 2);
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(923, 211);
            this.label86.Margin = new System.Windows.Forms.Padding(3);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(86, 20);
            this.label86.TabIndex = 0;
            this.label86.Text = "Blower 02:";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label85, 2);
            this.label85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label85.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(923, 185);
            this.label85.Margin = new System.Windows.Forms.Padding(3);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(86, 20);
            this.label85.TabIndex = 0;
            this.label85.Text = "Blower 01:";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label84, 2);
            this.label84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label84.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(923, 159);
            this.label84.Margin = new System.Windows.Forms.Padding(3);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(86, 20);
            this.label84.TabIndex = 0;
            this.label84.Text = "Balance 02:";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label83, 2);
            this.label83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label83.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(923, 133);
            this.label83.Margin = new System.Windows.Forms.Padding(3);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(86, 20);
            this.label83.TabIndex = 0;
            this.label83.Text = "Balance 01:";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label82, 2);
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(923, 107);
            this.label82.Margin = new System.Windows.Forms.Padding(3);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(86, 20);
            this.label82.TabIndex = 0;
            this.label82.Text = "Welding 02:";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label44, 2);
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(693, 341);
            this.label44.Margin = new System.Windows.Forms.Padding(3);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(86, 20);
            this.label44.TabIndex = 0;
            this.label44.Text = "Injection 11:";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_P11_AL
            // 
            this.lbl_P11_AL.AutoSize = true;
            this.lbl_P11_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P11_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P11_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P11_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P11_AL.Location = new System.Drawing.Point(875, 339);
            this.lbl_P11_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P11_AL.Name = "lbl_P11_AL";
            this.lbl_P11_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P11_AL.TabIndex = 0;
            this.lbl_P11_AL.Text = "0";
            this.lbl_P11_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P10_AL
            // 
            this.lbl_P10_AL.AutoSize = true;
            this.lbl_P10_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P10_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P10_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P10_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P10_AL.Location = new System.Drawing.Point(875, 313);
            this.lbl_P10_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P10_AL.Name = "lbl_P10_AL";
            this.lbl_P10_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P10_AL.TabIndex = 0;
            this.lbl_P10_AL.Text = "0";
            this.lbl_P10_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P09_AL
            // 
            this.lbl_P09_AL.AutoSize = true;
            this.lbl_P09_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P09_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P09_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P09_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P09_AL.Location = new System.Drawing.Point(875, 287);
            this.lbl_P09_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P09_AL.Name = "lbl_P09_AL";
            this.lbl_P09_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P09_AL.TabIndex = 0;
            this.lbl_P09_AL.Text = "0";
            this.lbl_P09_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P08_AL
            // 
            this.lbl_P08_AL.AutoSize = true;
            this.lbl_P08_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P08_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P08_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P08_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P08_AL.Location = new System.Drawing.Point(875, 261);
            this.lbl_P08_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P08_AL.Name = "lbl_P08_AL";
            this.lbl_P08_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P08_AL.TabIndex = 0;
            this.lbl_P08_AL.Text = "0";
            this.lbl_P08_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label43, 2);
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(693, 315);
            this.label43.Margin = new System.Windows.Forms.Padding(3);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(86, 20);
            this.label43.TabIndex = 0;
            this.label43.Text = "Injection 10:";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label42, 2);
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(693, 289);
            this.label42.Margin = new System.Windows.Forms.Padding(3);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(86, 20);
            this.label42.TabIndex = 0;
            this.label42.Text = "Injection 09:";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label41, 2);
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(693, 263);
            this.label41.Margin = new System.Windows.Forms.Padding(3);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(86, 20);
            this.label41.TabIndex = 0;
            this.label41.Text = "Injection 08:";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_P04_AL
            // 
            this.lbl_P04_AL.AutoSize = true;
            this.lbl_P04_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P04_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P04_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P04_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P04_AL.Location = new System.Drawing.Point(875, 157);
            this.lbl_P04_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P04_AL.Name = "lbl_P04_AL";
            this.lbl_P04_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P04_AL.TabIndex = 0;
            this.lbl_P04_AL.Text = "0";
            this.lbl_P04_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P03_AL
            // 
            this.lbl_P03_AL.AutoSize = true;
            this.lbl_P03_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P03_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P03_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P03_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P03_AL.Location = new System.Drawing.Point(875, 131);
            this.lbl_P03_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P03_AL.Name = "lbl_P03_AL";
            this.lbl_P03_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P03_AL.TabIndex = 0;
            this.lbl_P03_AL.Text = "0";
            this.lbl_P03_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P11_SV
            // 
            this.lbl_P11_SV.AutoSize = true;
            this.lbl_P11_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P11_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P11_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P11_SV.Location = new System.Drawing.Point(785, 341);
            this.lbl_P11_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P11_SV.Name = "lbl_P11_SV";
            this.lbl_P11_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P11_SV.TabIndex = 0;
            this.lbl_P11_SV.Text = "0";
            this.lbl_P11_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P11_PV
            // 
            this.lbl_P11_PV.AutoSize = true;
            this.lbl_P11_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P11_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P11_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P11_PV.Location = new System.Drawing.Point(831, 341);
            this.lbl_P11_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P11_PV.Name = "lbl_P11_PV";
            this.lbl_P11_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P11_PV.TabIndex = 0;
            this.lbl_P11_PV.Text = "0";
            this.lbl_P11_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P10_PV
            // 
            this.lbl_P10_PV.AutoSize = true;
            this.lbl_P10_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P10_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P10_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P10_PV.Location = new System.Drawing.Point(831, 315);
            this.lbl_P10_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P10_PV.Name = "lbl_P10_PV";
            this.lbl_P10_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P10_PV.TabIndex = 0;
            this.lbl_P10_PV.Text = "0";
            this.lbl_P10_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P09_PV
            // 
            this.lbl_P09_PV.AutoSize = true;
            this.lbl_P09_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P09_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P09_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P09_PV.Location = new System.Drawing.Point(831, 289);
            this.lbl_P09_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P09_PV.Name = "lbl_P09_PV";
            this.lbl_P09_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P09_PV.TabIndex = 0;
            this.lbl_P09_PV.Text = "0";
            this.lbl_P09_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P08_PV
            // 
            this.lbl_P08_PV.AutoSize = true;
            this.lbl_P08_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P08_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P08_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P08_PV.Location = new System.Drawing.Point(831, 263);
            this.lbl_P08_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P08_PV.Name = "lbl_P08_PV";
            this.lbl_P08_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P08_PV.TabIndex = 0;
            this.lbl_P08_PV.Text = "0";
            this.lbl_P08_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P10_SV
            // 
            this.lbl_P10_SV.AutoSize = true;
            this.lbl_P10_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P10_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P10_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P10_SV.Location = new System.Drawing.Point(785, 315);
            this.lbl_P10_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P10_SV.Name = "lbl_P10_SV";
            this.lbl_P10_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P10_SV.TabIndex = 0;
            this.lbl_P10_SV.Text = "0";
            this.lbl_P10_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P09_SV
            // 
            this.lbl_P09_SV.AutoSize = true;
            this.lbl_P09_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P09_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P09_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P09_SV.Location = new System.Drawing.Point(785, 289);
            this.lbl_P09_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P09_SV.Name = "lbl_P09_SV";
            this.lbl_P09_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P09_SV.TabIndex = 0;
            this.lbl_P09_SV.Text = "0";
            this.lbl_P09_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P08_SV
            // 
            this.lbl_P08_SV.AutoSize = true;
            this.lbl_P08_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P08_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P08_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P08_SV.Location = new System.Drawing.Point(785, 263);
            this.lbl_P08_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P08_SV.Name = "lbl_P08_SV";
            this.lbl_P08_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P08_SV.TabIndex = 0;
            this.lbl_P08_SV.Text = "0";
            this.lbl_P08_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label40, 2);
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(693, 237);
            this.label40.Margin = new System.Windows.Forms.Padding(3);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(86, 20);
            this.label40.TabIndex = 0;
            this.label40.Text = "Injection 07:";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label39, 2);
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(693, 211);
            this.label39.Margin = new System.Windows.Forms.Padding(3);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(86, 20);
            this.label39.TabIndex = 0;
            this.label39.Text = "Injection 06:";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label38, 2);
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(693, 185);
            this.label38.Margin = new System.Windows.Forms.Padding(3);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(86, 20);
            this.label38.TabIndex = 0;
            this.label38.Text = "Injection 05:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_P07_AL
            // 
            this.lbl_P07_AL.AutoSize = true;
            this.lbl_P07_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P07_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P07_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P07_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P07_AL.Location = new System.Drawing.Point(875, 235);
            this.lbl_P07_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P07_AL.Name = "lbl_P07_AL";
            this.lbl_P07_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P07_AL.TabIndex = 0;
            this.lbl_P07_AL.Text = "0";
            this.lbl_P07_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P06_AL
            // 
            this.lbl_P06_AL.AutoSize = true;
            this.lbl_P06_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P06_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P06_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P06_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P06_AL.Location = new System.Drawing.Point(875, 209);
            this.lbl_P06_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P06_AL.Name = "lbl_P06_AL";
            this.lbl_P06_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P06_AL.TabIndex = 0;
            this.lbl_P06_AL.Text = "0";
            this.lbl_P06_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P05_AL
            // 
            this.lbl_P05_AL.AutoSize = true;
            this.lbl_P05_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P05_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P05_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P05_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P05_AL.Location = new System.Drawing.Point(875, 183);
            this.lbl_P05_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P05_AL.Name = "lbl_P05_AL";
            this.lbl_P05_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P05_AL.TabIndex = 0;
            this.lbl_P05_AL.Text = "0";
            this.lbl_P05_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label37, 2);
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(693, 159);
            this.label37.Margin = new System.Windows.Forms.Padding(3);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(86, 20);
            this.label37.TabIndex = 0;
            this.label37.Text = "Injection 04:";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_P02_AL
            // 
            this.lbl_P02_AL.AutoSize = true;
            this.lbl_P02_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P02_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P02_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P02_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P02_AL.Location = new System.Drawing.Point(875, 105);
            this.lbl_P02_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P02_AL.Name = "lbl_P02_AL";
            this.lbl_P02_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P02_AL.TabIndex = 0;
            this.lbl_P02_AL.Text = "0";
            this.lbl_P02_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P01_AL
            // 
            this.lbl_P01_AL.AutoSize = true;
            this.lbl_P01_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_P01_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P01_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P01_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P01_AL.Location = new System.Drawing.Point(875, 79);
            this.lbl_P01_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_P01_AL.Name = "lbl_P01_AL";
            this.lbl_P01_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_P01_AL.TabIndex = 0;
            this.lbl_P01_AL.Text = "0";
            this.lbl_P01_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P01_PV
            // 
            this.lbl_P01_PV.AutoSize = true;
            this.lbl_P01_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P01_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P01_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P01_PV.Location = new System.Drawing.Point(831, 81);
            this.lbl_P01_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P01_PV.Name = "lbl_P01_PV";
            this.lbl_P01_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P01_PV.TabIndex = 0;
            this.lbl_P01_PV.Text = "0";
            this.lbl_P01_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P01_SV
            // 
            this.lbl_P01_SV.AutoSize = true;
            this.lbl_P01_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P01_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P01_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P01_SV.Location = new System.Drawing.Point(785, 81);
            this.lbl_P01_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P01_SV.Name = "lbl_P01_SV";
            this.lbl_P01_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P01_SV.TabIndex = 0;
            this.lbl_P01_SV.Text = "0";
            this.lbl_P01_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label20, 2);
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(693, 81);
            this.label20.Margin = new System.Windows.Forms.Padding(3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 20);
            this.label20.TabIndex = 0;
            this.label20.Text = "Injection 01:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label1, 10);
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(3);
            this.label1.Name = "label1";
            this.tableLayoutPanel1.SetRowSpan(this.label1, 2);
            this.label1.Size = new System.Drawing.Size(454, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "ASSEMBLY DATA FROM OPC";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label4, 2);
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(49, 81);
            this.label4.Margin = new System.Windows.Forms.Padding(3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "A/Balance 01:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label5, 2);
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(49, 107);
            this.label5.Margin = new System.Windows.Forms.Padding(3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "A/Balance 02:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label6, 2);
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(49, 133);
            this.label6.Margin = new System.Windows.Forms.Padding(3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "A/Balance 03:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_P07_SV
            // 
            this.lbl_P07_SV.AutoSize = true;
            this.lbl_P07_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P07_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P07_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P07_SV.Location = new System.Drawing.Point(785, 237);
            this.lbl_P07_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P07_SV.Name = "lbl_P07_SV";
            this.lbl_P07_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P07_SV.TabIndex = 0;
            this.lbl_P07_SV.Text = "0";
            this.lbl_P07_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P06_SV
            // 
            this.lbl_P06_SV.AutoSize = true;
            this.lbl_P06_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P06_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P06_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P06_SV.Location = new System.Drawing.Point(785, 211);
            this.lbl_P06_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P06_SV.Name = "lbl_P06_SV";
            this.lbl_P06_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P06_SV.TabIndex = 0;
            this.lbl_P06_SV.Text = "0";
            this.lbl_P06_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P05_SV
            // 
            this.lbl_P05_SV.AutoSize = true;
            this.lbl_P05_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P05_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P05_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P05_SV.Location = new System.Drawing.Point(785, 185);
            this.lbl_P05_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P05_SV.Name = "lbl_P05_SV";
            this.lbl_P05_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P05_SV.TabIndex = 0;
            this.lbl_P05_SV.Text = "0";
            this.lbl_P05_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P04_SV
            // 
            this.lbl_P04_SV.AutoSize = true;
            this.lbl_P04_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P04_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P04_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P04_SV.Location = new System.Drawing.Point(785, 159);
            this.lbl_P04_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P04_SV.Name = "lbl_P04_SV";
            this.lbl_P04_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P04_SV.TabIndex = 0;
            this.lbl_P04_SV.Text = "0";
            this.lbl_P04_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(877, 55);
            this.label30.Margin = new System.Windows.Forms.Padding(3);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(40, 20);
            this.label30.TabIndex = 0;
            this.label30.Text = "AL";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P07_PV
            // 
            this.lbl_P07_PV.AutoSize = true;
            this.lbl_P07_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P07_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P07_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P07_PV.Location = new System.Drawing.Point(831, 237);
            this.lbl_P07_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P07_PV.Name = "lbl_P07_PV";
            this.lbl_P07_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P07_PV.TabIndex = 0;
            this.lbl_P07_PV.Text = "0";
            this.lbl_P07_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P06_PV
            // 
            this.lbl_P06_PV.AutoSize = true;
            this.lbl_P06_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P06_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P06_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P06_PV.Location = new System.Drawing.Point(831, 211);
            this.lbl_P06_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P06_PV.Name = "lbl_P06_PV";
            this.lbl_P06_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P06_PV.TabIndex = 0;
            this.lbl_P06_PV.Text = "0";
            this.lbl_P06_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P05_PV
            // 
            this.lbl_P05_PV.AutoSize = true;
            this.lbl_P05_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P05_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P05_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P05_PV.Location = new System.Drawing.Point(831, 185);
            this.lbl_P05_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P05_PV.Name = "lbl_P05_PV";
            this.lbl_P05_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P05_PV.TabIndex = 0;
            this.lbl_P05_PV.Text = "0";
            this.lbl_P05_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P04_PV
            // 
            this.lbl_P04_PV.AutoSize = true;
            this.lbl_P04_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P04_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P04_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P04_PV.Location = new System.Drawing.Point(831, 159);
            this.lbl_P04_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P04_PV.Name = "lbl_P04_PV";
            this.lbl_P04_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P04_PV.TabIndex = 0;
            this.lbl_P04_PV.Text = "0";
            this.lbl_P04_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label36, 2);
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(693, 133);
            this.label36.Margin = new System.Windows.Forms.Padding(3);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(86, 20);
            this.label36.TabIndex = 0;
            this.label36.Text = "Injection 03:";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label35, 2);
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(693, 107);
            this.label35.Margin = new System.Windows.Forms.Padding(3);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(86, 20);
            this.label35.TabIndex = 0;
            this.label35.Text = "Injection 02:";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(831, 55);
            this.label28.Margin = new System.Windows.Forms.Padding(3);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 20);
            this.label28.TabIndex = 0;
            this.label28.Text = "PV";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(785, 55);
            this.label26.Margin = new System.Windows.Forms.Padding(3);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 20);
            this.label26.TabIndex = 0;
            this.label26.Text = "SV";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label24, 2);
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(693, 55);
            this.label24.Margin = new System.Windows.Forms.Padding(3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 20);
            this.label24.TabIndex = 0;
            this.label24.Text = "MACHINES";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label10, 2);
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(49, 185);
            this.label10.Margin = new System.Windows.Forms.Padding(3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "Dispenser 01:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label11, 2);
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(49, 211);
            this.label11.Margin = new System.Windows.Forms.Padding(3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "Dispenser 02:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label14, 2);
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(49, 263);
            this.label14.Margin = new System.Windows.Forms.Padding(3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(86, 20);
            this.label14.TabIndex = 0;
            this.label14.Text = "Pump 01:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label17, 2);
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(49, 367);
            this.label17.Margin = new System.Windows.Forms.Padding(3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 20);
            this.label17.TabIndex = 0;
            this.label17.Text = "W/B 03:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label15, 2);
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(49, 341);
            this.label15.Margin = new System.Windows.Forms.Padding(3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "W/B 02:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label7, 2);
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(49, 315);
            this.label7.Margin = new System.Windows.Forms.Padding(3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "W/B 01:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label8, 2);
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(279, 315);
            this.label8.Margin = new System.Windows.Forms.Padding(3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Blower 01:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label9, 2);
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(279, 341);
            this.label9.Margin = new System.Windows.Forms.Padding(3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Blower 02:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label12, 2);
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(279, 367);
            this.label12.Margin = new System.Windows.Forms.Padding(3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Mixing:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label13, 2);
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(49, 445);
            this.label13.Margin = new System.Windows.Forms.Padding(3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 20);
            this.label13.TabIndex = 0;
            this.label13.Text = "Welding 01:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_P03_SV
            // 
            this.lbl_P03_SV.AutoSize = true;
            this.lbl_P03_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P03_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P03_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P03_SV.Location = new System.Drawing.Point(785, 133);
            this.lbl_P03_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P03_SV.Name = "lbl_P03_SV";
            this.lbl_P03_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P03_SV.TabIndex = 0;
            this.lbl_P03_SV.Text = "0";
            this.lbl_P03_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P02_SV
            // 
            this.lbl_P02_SV.AutoSize = true;
            this.lbl_P02_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P02_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P02_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P02_SV.Location = new System.Drawing.Point(785, 107);
            this.lbl_P02_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P02_SV.Name = "lbl_P02_SV";
            this.lbl_P02_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P02_SV.TabIndex = 0;
            this.lbl_P02_SV.Text = "0";
            this.lbl_P02_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label16, 2);
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(49, 471);
            this.label16.Margin = new System.Windows.Forms.Padding(3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Welding 02:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtAB02OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtAB02OK, 2);
            this.txtAB02OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAB02OK.Location = new System.Drawing.Point(141, 107);
            this.txtAB02OK.Name = "txtAB02OK";
            this.txtAB02OK.ReadOnly = true;
            this.txtAB02OK.Size = new System.Drawing.Size(86, 26);
            this.txtAB02OK.TabIndex = 4;
            this.txtAB02OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAB02OK.TextChanged += new System.EventHandler(this.txtAB02OK_TextChanged);
            // 
            // txtAB03OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtAB03OK, 2);
            this.txtAB03OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAB03OK.Location = new System.Drawing.Point(141, 133);
            this.txtAB03OK.Name = "txtAB03OK";
            this.txtAB03OK.ReadOnly = true;
            this.txtAB03OK.Size = new System.Drawing.Size(86, 26);
            this.txtAB03OK.TabIndex = 6;
            this.txtAB03OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAB03OK.TextChanged += new System.EventHandler(this.txtAB03OK_TextChanged);
            // 
            // txtDI01OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtDI01OK, 2);
            this.txtDI01OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDI01OK.Location = new System.Drawing.Point(141, 185);
            this.txtDI01OK.Name = "txtDI01OK";
            this.txtDI01OK.ReadOnly = true;
            this.txtDI01OK.Size = new System.Drawing.Size(86, 26);
            this.txtDI01OK.TabIndex = 8;
            this.txtDI01OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDI01OK.TextChanged += new System.EventHandler(this.txtDI01OK_TextChanged);
            // 
            // txtDI02OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtDI02OK, 2);
            this.txtDI02OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDI02OK.Location = new System.Drawing.Point(141, 211);
            this.txtDI02OK.Name = "txtDI02OK";
            this.txtDI02OK.ReadOnly = true;
            this.txtDI02OK.Size = new System.Drawing.Size(86, 26);
            this.txtDI02OK.TabIndex = 10;
            this.txtDI02OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDI02OK.TextChanged += new System.EventHandler(this.txtDI02OK_TextChanged);
            // 
            // lbl_P03_PV
            // 
            this.lbl_P03_PV.AutoSize = true;
            this.lbl_P03_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P03_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P03_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P03_PV.Location = new System.Drawing.Point(831, 133);
            this.lbl_P03_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P03_PV.Name = "lbl_P03_PV";
            this.lbl_P03_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P03_PV.TabIndex = 0;
            this.lbl_P03_PV.Text = "0";
            this.lbl_P03_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P02_PV
            // 
            this.lbl_P02_PV.AutoSize = true;
            this.lbl_P02_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_P02_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P02_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P02_PV.Location = new System.Drawing.Point(831, 107);
            this.lbl_P02_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P02_PV.Name = "lbl_P02_PV";
            this.lbl_P02_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_P02_PV.TabIndex = 0;
            this.lbl_P02_PV.Text = "0";
            this.lbl_P02_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPU01OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtPU01OK, 2);
            this.txtPU01OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPU01OK.Location = new System.Drawing.Point(141, 263);
            this.txtPU01OK.Name = "txtPU01OK";
            this.txtPU01OK.ReadOnly = true;
            this.txtPU01OK.Size = new System.Drawing.Size(86, 26);
            this.txtPU01OK.TabIndex = 12;
            this.txtPU01OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPU01OK.TextChanged += new System.EventHandler(this.txtPU01OK_TextChanged);
            // 
            // txtWB01OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtWB01OK, 2);
            this.txtWB01OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWB01OK.Location = new System.Drawing.Point(141, 315);
            this.txtWB01OK.Name = "txtWB01OK";
            this.txtWB01OK.ReadOnly = true;
            this.txtWB01OK.Size = new System.Drawing.Size(86, 26);
            this.txtWB01OK.TabIndex = 14;
            this.txtWB01OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWB01OK.TextChanged += new System.EventHandler(this.txtWB01OK_TextChanged);
            // 
            // txtBL01OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtBL01OK, 2);
            this.txtBL01OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBL01OK.Location = new System.Drawing.Point(371, 315);
            this.txtBL01OK.Name = "txtBL01OK";
            this.txtBL01OK.ReadOnly = true;
            this.txtBL01OK.Size = new System.Drawing.Size(86, 26);
            this.txtBL01OK.TabIndex = 17;
            this.txtBL01OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBL01OK.TextChanged += new System.EventHandler(this.txtBL01OK_TextChanged);
            // 
            // txtWB02OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtWB02OK, 2);
            this.txtWB02OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWB02OK.Location = new System.Drawing.Point(141, 341);
            this.txtWB02OK.Name = "txtWB02OK";
            this.txtWB02OK.ReadOnly = true;
            this.txtWB02OK.Size = new System.Drawing.Size(86, 26);
            this.txtWB02OK.TabIndex = 15;
            this.txtWB02OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWB02OK.TextChanged += new System.EventHandler(this.txtWB02OK_TextChanged);
            // 
            // txtBL02OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtBL02OK, 2);
            this.txtBL02OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBL02OK.Location = new System.Drawing.Point(371, 341);
            this.txtBL02OK.Name = "txtBL02OK";
            this.txtBL02OK.ReadOnly = true;
            this.txtBL02OK.Size = new System.Drawing.Size(86, 26);
            this.txtBL02OK.TabIndex = 18;
            this.txtBL02OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBL02OK.TextChanged += new System.EventHandler(this.txtBL02OK_TextChanged);
            // 
            // txtWB03OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtWB03OK, 2);
            this.txtWB03OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWB03OK.Location = new System.Drawing.Point(141, 367);
            this.txtWB03OK.Name = "txtWB03OK";
            this.txtWB03OK.ReadOnly = true;
            this.txtWB03OK.Size = new System.Drawing.Size(86, 26);
            this.txtWB03OK.TabIndex = 16;
            this.txtWB03OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWB03OK.TextChanged += new System.EventHandler(this.txtWB03OK_TextChanged);
            // 
            // txtMX01OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtMX01OK, 2);
            this.txtMX01OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMX01OK.Location = new System.Drawing.Point(371, 367);
            this.txtMX01OK.Name = "txtMX01OK";
            this.txtMX01OK.ReadOnly = true;
            this.txtMX01OK.Size = new System.Drawing.Size(86, 26);
            this.txtMX01OK.TabIndex = 19;
            this.txtMX01OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMX01OK.TextChanged += new System.EventHandler(this.txtMX01OK_TextChanged);
            // 
            // txtWD01OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtWD01OK, 2);
            this.txtWD01OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWD01OK.Location = new System.Drawing.Point(141, 445);
            this.txtWD01OK.Name = "txtWD01OK";
            this.txtWD01OK.ReadOnly = true;
            this.txtWD01OK.Size = new System.Drawing.Size(86, 26);
            this.txtWD01OK.TabIndex = 20;
            this.txtWD01OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWD01OK.TextChanged += new System.EventHandler(this.txtWD01OK_TextChanged);
            // 
            // txtWD02OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtWD02OK, 2);
            this.txtWD02OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWD02OK.Location = new System.Drawing.Point(141, 471);
            this.txtWD02OK.Name = "txtWD02OK";
            this.txtWD02OK.ReadOnly = true;
            this.txtWD02OK.Size = new System.Drawing.Size(86, 26);
            this.txtWD02OK.TabIndex = 21;
            this.txtWD02OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWD02OK.TextChanged += new System.EventHandler(this.txtWD02OK_TextChanged);
            // 
            // txtPU01NG
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtPU01NG, 2);
            this.txtPU01NG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPU01NG.Location = new System.Drawing.Point(371, 263);
            this.txtPU01NG.Name = "txtPU01NG";
            this.txtPU01NG.ReadOnly = true;
            this.txtPU01NG.Size = new System.Drawing.Size(86, 26);
            this.txtPU01NG.TabIndex = 13;
            this.txtPU01NG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPU01NG.TextChanged += new System.EventHandler(this.txtPU01NG_TextChanged);
            // 
            // txtDI02NG
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtDI02NG, 2);
            this.txtDI02NG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDI02NG.Location = new System.Drawing.Point(371, 211);
            this.txtDI02NG.Name = "txtDI02NG";
            this.txtDI02NG.ReadOnly = true;
            this.txtDI02NG.Size = new System.Drawing.Size(86, 26);
            this.txtDI02NG.TabIndex = 11;
            this.txtDI02NG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDI02NG.TextChanged += new System.EventHandler(this.txtDI02NG_TextChanged);
            // 
            // txtDI01NG
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtDI01NG, 2);
            this.txtDI01NG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDI01NG.Location = new System.Drawing.Point(371, 185);
            this.txtDI01NG.Name = "txtDI01NG";
            this.txtDI01NG.ReadOnly = true;
            this.txtDI01NG.Size = new System.Drawing.Size(86, 26);
            this.txtDI01NG.TabIndex = 9;
            this.txtDI01NG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDI01NG.TextChanged += new System.EventHandler(this.txtDI01NG_TextChanged);
            // 
            // txtAB03NG
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtAB03NG, 2);
            this.txtAB03NG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAB03NG.Location = new System.Drawing.Point(371, 133);
            this.txtAB03NG.Name = "txtAB03NG";
            this.txtAB03NG.ReadOnly = true;
            this.txtAB03NG.Size = new System.Drawing.Size(86, 26);
            this.txtAB03NG.TabIndex = 7;
            this.txtAB03NG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAB03NG.TextChanged += new System.EventHandler(this.txtAB03NG_TextChanged);
            // 
            // txtAB02NG
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtAB02NG, 2);
            this.txtAB02NG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAB02NG.Location = new System.Drawing.Point(371, 107);
            this.txtAB02NG.Name = "txtAB02NG";
            this.txtAB02NG.ReadOnly = true;
            this.txtAB02NG.Size = new System.Drawing.Size(86, 26);
            this.txtAB02NG.TabIndex = 5;
            this.txtAB02NG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAB02NG.TextChanged += new System.EventHandler(this.txtAB02NG_TextChanged);
            // 
            // txtAB01NG
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtAB01NG, 2);
            this.txtAB01NG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAB01NG.Location = new System.Drawing.Point(371, 81);
            this.txtAB01NG.Name = "txtAB01NG";
            this.txtAB01NG.ReadOnly = true;
            this.txtAB01NG.Size = new System.Drawing.Size(86, 26);
            this.txtAB01NG.TabIndex = 3;
            this.txtAB01NG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAB01NG.TextChanged += new System.EventHandler(this.txtAB01NG_TextChanged);
            // 
            // txtAB01OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtAB01OK, 2);
            this.txtAB01OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAB01OK.Location = new System.Drawing.Point(141, 81);
            this.txtAB01OK.Name = "txtAB01OK";
            this.txtAB01OK.ReadOnly = true;
            this.txtAB01OK.Size = new System.Drawing.Size(86, 26);
            this.txtAB01OK.TabIndex = 2;
            this.txtAB01OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAB01OK.TextChanged += new System.EventHandler(this.txtAB01OK_TextChanged);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lblStatus, 4);
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblStatus.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(279, 419);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(3);
            this.lblStatus.Name = "lblStatus";
            this.tableLayoutPanel1.SetRowSpan(this.lblStatus, 2);
            this.lblStatus.Size = new System.Drawing.Size(178, 46);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "Disconnected";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkConnect
            // 
            this.chkConnect.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.chkConnect, 4);
            this.chkConnect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkConnect.Location = new System.Drawing.Point(49, 55);
            this.chkConnect.Name = "chkConnect";
            this.chkConnect.Size = new System.Drawing.Size(178, 20);
            this.chkConnect.TabIndex = 1;
            this.chkConnect.Text = "Connect to OPC";
            this.chkConnect.UseVisualStyleBackColor = true;
            this.chkConnect.CheckedChanged += new System.EventHandler(this.chkConnect_CheckedChanged);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lblMessage, 10);
            this.lblMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMessage.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(3, 497);
            this.lblMessage.Margin = new System.Windows.Forms.Padding(3);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(454, 37);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.Text = "Message";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkOperate
            // 
            this.chkOperate.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.chkOperate, 4);
            this.chkOperate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkOperate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOperate.Location = new System.Drawing.Point(279, 55);
            this.chkOperate.Name = "chkOperate";
            this.chkOperate.Size = new System.Drawing.Size(178, 20);
            this.chkOperate.TabIndex = 22;
            this.chkOperate.Text = "MONITORING";
            this.chkOperate.UseVisualStyleBackColor = true;
            this.chkOperate.Visible = false;
            this.chkOperate.CheckedChanged += new System.EventHandler(this.chkOperate_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(279, 471);
            this.label2.Margin = new System.Windows.Forms.Padding(3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Disconnected";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label3, 2);
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 393);
            this.label3.Margin = new System.Windows.Forms.Padding(3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "W/B 04:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtWB04OK
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtWB04OK, 2);
            this.txtWB04OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWB04OK.Location = new System.Drawing.Point(141, 393);
            this.txtWB04OK.Name = "txtWB04OK";
            this.txtWB04OK.ReadOnly = true;
            this.txtWB04OK.Size = new System.Drawing.Size(86, 26);
            this.txtWB04OK.TabIndex = 16;
            this.txtWB04OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWB04OK.TextChanged += new System.EventHandler(this.txtWB04OK_TextChanged);
            // 
            // lbl_R01
            // 
            this.lbl_R01.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R01, 2);
            this.lbl_R01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R01.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R01.Location = new System.Drawing.Point(463, 81);
            this.lbl_R01.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R01.Name = "lbl_R01";
            this.lbl_R01.Size = new System.Drawing.Size(86, 20);
            this.lbl_R01.TabIndex = 0;
            this.lbl_R01.Text = "Rubber 01:";
            this.lbl_R01.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R01_SV
            // 
            this.lbl_R01_SV.AutoSize = true;
            this.lbl_R01_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R01_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R01_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R01_SV.Location = new System.Drawing.Point(555, 81);
            this.lbl_R01_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R01_SV.Name = "lbl_R01_SV";
            this.lbl_R01_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R01_SV.TabIndex = 0;
            this.lbl_R01_SV.Text = "0";
            this.lbl_R01_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R02
            // 
            this.lbl_R02.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R02, 2);
            this.lbl_R02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R02.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R02.Location = new System.Drawing.Point(463, 107);
            this.lbl_R02.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R02.Name = "lbl_R02";
            this.lbl_R02.Size = new System.Drawing.Size(86, 20);
            this.lbl_R02.TabIndex = 0;
            this.lbl_R02.Text = "Rubber 02:";
            this.lbl_R02.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R02_SV
            // 
            this.lbl_R02_SV.AutoSize = true;
            this.lbl_R02_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R02_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R02_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R02_SV.Location = new System.Drawing.Point(555, 107);
            this.lbl_R02_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R02_SV.Name = "lbl_R02_SV";
            this.lbl_R02_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R02_SV.TabIndex = 0;
            this.lbl_R02_SV.Text = "0";
            this.lbl_R02_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R03_SV
            // 
            this.lbl_R03_SV.AutoSize = true;
            this.lbl_R03_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R03_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R03_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R03_SV.Location = new System.Drawing.Point(555, 133);
            this.lbl_R03_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R03_SV.Name = "lbl_R03_SV";
            this.lbl_R03_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R03_SV.TabIndex = 0;
            this.lbl_R03_SV.Text = "0";
            this.lbl_R03_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R04_SV
            // 
            this.lbl_R04_SV.AutoSize = true;
            this.lbl_R04_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R04_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R04_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R04_SV.Location = new System.Drawing.Point(555, 159);
            this.lbl_R04_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R04_SV.Name = "lbl_R04_SV";
            this.lbl_R04_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R04_SV.TabIndex = 0;
            this.lbl_R04_SV.Text = "0";
            this.lbl_R04_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R05_SV
            // 
            this.lbl_R05_SV.AutoSize = true;
            this.lbl_R05_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R05_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R05_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R05_SV.Location = new System.Drawing.Point(555, 185);
            this.lbl_R05_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R05_SV.Name = "lbl_R05_SV";
            this.lbl_R05_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R05_SV.TabIndex = 0;
            this.lbl_R05_SV.Text = "0";
            this.lbl_R05_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R06_SV
            // 
            this.lbl_R06_SV.AutoSize = true;
            this.lbl_R06_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R06_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R06_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R06_SV.Location = new System.Drawing.Point(555, 211);
            this.lbl_R06_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R06_SV.Name = "lbl_R06_SV";
            this.lbl_R06_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R06_SV.TabIndex = 0;
            this.lbl_R06_SV.Text = "0";
            this.lbl_R06_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R07_SV
            // 
            this.lbl_R07_SV.AutoSize = true;
            this.lbl_R07_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R07_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R07_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R07_SV.Location = new System.Drawing.Point(555, 237);
            this.lbl_R07_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R07_SV.Name = "lbl_R07_SV";
            this.lbl_R07_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R07_SV.TabIndex = 0;
            this.lbl_R07_SV.Text = "0";
            this.lbl_R07_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R08_SV
            // 
            this.lbl_R08_SV.AutoSize = true;
            this.lbl_R08_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R08_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R08_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R08_SV.Location = new System.Drawing.Point(555, 263);
            this.lbl_R08_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R08_SV.Name = "lbl_R08_SV";
            this.lbl_R08_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R08_SV.TabIndex = 0;
            this.lbl_R08_SV.Text = "0";
            this.lbl_R08_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R09_SV
            // 
            this.lbl_R09_SV.AutoSize = true;
            this.lbl_R09_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R09_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R09_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R09_SV.Location = new System.Drawing.Point(555, 289);
            this.lbl_R09_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R09_SV.Name = "lbl_R09_SV";
            this.lbl_R09_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R09_SV.TabIndex = 0;
            this.lbl_R09_SV.Text = "0";
            this.lbl_R09_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R10_SV
            // 
            this.lbl_R10_SV.AutoSize = true;
            this.lbl_R10_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R10_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R10_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R10_SV.Location = new System.Drawing.Point(555, 315);
            this.lbl_R10_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R10_SV.Name = "lbl_R10_SV";
            this.lbl_R10_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R10_SV.TabIndex = 0;
            this.lbl_R10_SV.Text = "0";
            this.lbl_R10_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R11_SV
            // 
            this.lbl_R11_SV.AutoSize = true;
            this.lbl_R11_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R11_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R11_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R11_SV.Location = new System.Drawing.Point(555, 341);
            this.lbl_R11_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R11_SV.Name = "lbl_R11_SV";
            this.lbl_R11_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R11_SV.TabIndex = 0;
            this.lbl_R11_SV.Text = "0";
            this.lbl_R11_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R12_SV
            // 
            this.lbl_R12_SV.AutoSize = true;
            this.lbl_R12_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R12_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R12_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R12_SV.Location = new System.Drawing.Point(555, 367);
            this.lbl_R12_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R12_SV.Name = "lbl_R12_SV";
            this.lbl_R12_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R12_SV.TabIndex = 0;
            this.lbl_R12_SV.Text = "0";
            this.lbl_R12_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R13_SV
            // 
            this.lbl_R13_SV.AutoSize = true;
            this.lbl_R13_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R13_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R13_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R13_SV.Location = new System.Drawing.Point(555, 393);
            this.lbl_R13_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R13_SV.Name = "lbl_R13_SV";
            this.lbl_R13_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R13_SV.TabIndex = 0;
            this.lbl_R13_SV.Text = "0";
            this.lbl_R13_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R14_SV
            // 
            this.lbl_R14_SV.AutoSize = true;
            this.lbl_R14_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R14_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R14_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R14_SV.Location = new System.Drawing.Point(555, 419);
            this.lbl_R14_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R14_SV.Name = "lbl_R14_SV";
            this.lbl_R14_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R14_SV.TabIndex = 0;
            this.lbl_R14_SV.Text = "0";
            this.lbl_R14_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R15_SV
            // 
            this.lbl_R15_SV.AutoSize = true;
            this.lbl_R15_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R15_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R15_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R15_SV.Location = new System.Drawing.Point(555, 445);
            this.lbl_R15_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R15_SV.Name = "lbl_R15_SV";
            this.lbl_R15_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R15_SV.TabIndex = 0;
            this.lbl_R15_SV.Text = "0";
            this.lbl_R15_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R16_SV
            // 
            this.lbl_R16_SV.AutoSize = true;
            this.lbl_R16_SV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R16_SV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R16_SV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R16_SV.Location = new System.Drawing.Point(555, 471);
            this.lbl_R16_SV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R16_SV.Name = "lbl_R16_SV";
            this.lbl_R16_SV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R16_SV.TabIndex = 0;
            this.lbl_R16_SV.Text = "0";
            this.lbl_R16_SV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R16
            // 
            this.lbl_R16.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R16, 2);
            this.lbl_R16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R16.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R16.Location = new System.Drawing.Point(463, 471);
            this.lbl_R16.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R16.Name = "lbl_R16";
            this.lbl_R16.Size = new System.Drawing.Size(86, 20);
            this.lbl_R16.TabIndex = 0;
            this.lbl_R16.Text = "Rubber 16:";
            this.lbl_R16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R15
            // 
            this.lbl_R15.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R15, 2);
            this.lbl_R15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R15.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R15.Location = new System.Drawing.Point(463, 445);
            this.lbl_R15.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R15.Name = "lbl_R15";
            this.lbl_R15.Size = new System.Drawing.Size(86, 20);
            this.lbl_R15.TabIndex = 0;
            this.lbl_R15.Text = "Rubber 15:";
            this.lbl_R15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R14
            // 
            this.lbl_R14.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R14, 2);
            this.lbl_R14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R14.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R14.Location = new System.Drawing.Point(463, 419);
            this.lbl_R14.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R14.Name = "lbl_R14";
            this.lbl_R14.Size = new System.Drawing.Size(86, 20);
            this.lbl_R14.TabIndex = 0;
            this.lbl_R14.Text = "Rubber 14:";
            this.lbl_R14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R13
            // 
            this.lbl_R13.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R13, 2);
            this.lbl_R13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R13.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R13.Location = new System.Drawing.Point(463, 393);
            this.lbl_R13.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R13.Name = "lbl_R13";
            this.lbl_R13.Size = new System.Drawing.Size(86, 20);
            this.lbl_R13.TabIndex = 0;
            this.lbl_R13.Text = "Rubber 13:";
            this.lbl_R13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R12
            // 
            this.lbl_R12.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R12, 2);
            this.lbl_R12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R12.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R12.Location = new System.Drawing.Point(463, 367);
            this.lbl_R12.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R12.Name = "lbl_R12";
            this.lbl_R12.Size = new System.Drawing.Size(86, 20);
            this.lbl_R12.TabIndex = 0;
            this.lbl_R12.Text = "Rubber 12:";
            this.lbl_R12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R11
            // 
            this.lbl_R11.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R11, 2);
            this.lbl_R11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R11.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R11.Location = new System.Drawing.Point(463, 341);
            this.lbl_R11.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R11.Name = "lbl_R11";
            this.lbl_R11.Size = new System.Drawing.Size(86, 20);
            this.lbl_R11.TabIndex = 0;
            this.lbl_R11.Text = "Rubber 11:";
            this.lbl_R11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R10
            // 
            this.lbl_R10.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R10, 2);
            this.lbl_R10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R10.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R10.Location = new System.Drawing.Point(463, 315);
            this.lbl_R10.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R10.Name = "lbl_R10";
            this.lbl_R10.Size = new System.Drawing.Size(86, 20);
            this.lbl_R10.TabIndex = 0;
            this.lbl_R10.Text = "Rubber 10:";
            this.lbl_R10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R09
            // 
            this.lbl_R09.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R09, 2);
            this.lbl_R09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R09.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R09.Location = new System.Drawing.Point(463, 289);
            this.lbl_R09.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R09.Name = "lbl_R09";
            this.lbl_R09.Size = new System.Drawing.Size(86, 20);
            this.lbl_R09.TabIndex = 0;
            this.lbl_R09.Text = "Rubber 09:";
            this.lbl_R09.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R08
            // 
            this.lbl_R08.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R08, 2);
            this.lbl_R08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R08.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R08.Location = new System.Drawing.Point(463, 263);
            this.lbl_R08.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R08.Name = "lbl_R08";
            this.lbl_R08.Size = new System.Drawing.Size(86, 20);
            this.lbl_R08.TabIndex = 0;
            this.lbl_R08.Text = "Rubber 08:";
            this.lbl_R08.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R07
            // 
            this.lbl_R07.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R07, 2);
            this.lbl_R07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R07.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R07.Location = new System.Drawing.Point(463, 237);
            this.lbl_R07.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R07.Name = "lbl_R07";
            this.lbl_R07.Size = new System.Drawing.Size(86, 20);
            this.lbl_R07.TabIndex = 0;
            this.lbl_R07.Text = "Rubber 07:";
            this.lbl_R07.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R06
            // 
            this.lbl_R06.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R06, 2);
            this.lbl_R06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R06.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R06.Location = new System.Drawing.Point(463, 211);
            this.lbl_R06.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R06.Name = "lbl_R06";
            this.lbl_R06.Size = new System.Drawing.Size(86, 20);
            this.lbl_R06.TabIndex = 0;
            this.lbl_R06.Text = "Rubber 06:";
            this.lbl_R06.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R05
            // 
            this.lbl_R05.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R05, 2);
            this.lbl_R05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R05.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R05.Location = new System.Drawing.Point(463, 185);
            this.lbl_R05.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R05.Name = "lbl_R05";
            this.lbl_R05.Size = new System.Drawing.Size(86, 20);
            this.lbl_R05.TabIndex = 0;
            this.lbl_R05.Text = "Rubber 05:";
            this.lbl_R05.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R04
            // 
            this.lbl_R04.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R04, 2);
            this.lbl_R04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R04.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R04.Location = new System.Drawing.Point(463, 159);
            this.lbl_R04.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R04.Name = "lbl_R04";
            this.lbl_R04.Size = new System.Drawing.Size(86, 20);
            this.lbl_R04.TabIndex = 0;
            this.lbl_R04.Text = "Rubber 04:";
            this.lbl_R04.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R03
            // 
            this.lbl_R03.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R03, 2);
            this.lbl_R03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R03.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R03.Location = new System.Drawing.Point(463, 133);
            this.lbl_R03.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R03.Name = "lbl_R03";
            this.lbl_R03.Size = new System.Drawing.Size(86, 20);
            this.lbl_R03.TabIndex = 0;
            this.lbl_R03.Text = "Rubber 03:";
            this.lbl_R03.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_R01_PV
            // 
            this.lbl_R01_PV.AutoSize = true;
            this.lbl_R01_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R01_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R01_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R01_PV.Location = new System.Drawing.Point(601, 81);
            this.lbl_R01_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R01_PV.Name = "lbl_R01_PV";
            this.lbl_R01_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R01_PV.TabIndex = 0;
            this.lbl_R01_PV.Text = "0";
            this.lbl_R01_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R02_PV
            // 
            this.lbl_R02_PV.AutoSize = true;
            this.lbl_R02_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R02_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R02_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R02_PV.Location = new System.Drawing.Point(601, 107);
            this.lbl_R02_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R02_PV.Name = "lbl_R02_PV";
            this.lbl_R02_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R02_PV.TabIndex = 0;
            this.lbl_R02_PV.Text = "0";
            this.lbl_R02_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R03_PV
            // 
            this.lbl_R03_PV.AutoSize = true;
            this.lbl_R03_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R03_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R03_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R03_PV.Location = new System.Drawing.Point(601, 133);
            this.lbl_R03_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R03_PV.Name = "lbl_R03_PV";
            this.lbl_R03_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R03_PV.TabIndex = 0;
            this.lbl_R03_PV.Text = "0";
            this.lbl_R03_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R04_PV
            // 
            this.lbl_R04_PV.AutoSize = true;
            this.lbl_R04_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R04_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R04_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R04_PV.Location = new System.Drawing.Point(601, 159);
            this.lbl_R04_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R04_PV.Name = "lbl_R04_PV";
            this.lbl_R04_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R04_PV.TabIndex = 0;
            this.lbl_R04_PV.Text = "0";
            this.lbl_R04_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R05_PV
            // 
            this.lbl_R05_PV.AutoSize = true;
            this.lbl_R05_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R05_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R05_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R05_PV.Location = new System.Drawing.Point(601, 185);
            this.lbl_R05_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R05_PV.Name = "lbl_R05_PV";
            this.lbl_R05_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R05_PV.TabIndex = 0;
            this.lbl_R05_PV.Text = "0";
            this.lbl_R05_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R06_PV
            // 
            this.lbl_R06_PV.AutoSize = true;
            this.lbl_R06_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R06_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R06_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R06_PV.Location = new System.Drawing.Point(601, 211);
            this.lbl_R06_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R06_PV.Name = "lbl_R06_PV";
            this.lbl_R06_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R06_PV.TabIndex = 0;
            this.lbl_R06_PV.Text = "0";
            this.lbl_R06_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R07_PV
            // 
            this.lbl_R07_PV.AutoSize = true;
            this.lbl_R07_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R07_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R07_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R07_PV.Location = new System.Drawing.Point(601, 237);
            this.lbl_R07_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R07_PV.Name = "lbl_R07_PV";
            this.lbl_R07_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R07_PV.TabIndex = 0;
            this.lbl_R07_PV.Text = "0";
            this.lbl_R07_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R08_PV
            // 
            this.lbl_R08_PV.AutoSize = true;
            this.lbl_R08_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R08_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R08_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R08_PV.Location = new System.Drawing.Point(601, 263);
            this.lbl_R08_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R08_PV.Name = "lbl_R08_PV";
            this.lbl_R08_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R08_PV.TabIndex = 0;
            this.lbl_R08_PV.Text = "0";
            this.lbl_R08_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R09_PV
            // 
            this.lbl_R09_PV.AutoSize = true;
            this.lbl_R09_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R09_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R09_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R09_PV.Location = new System.Drawing.Point(601, 289);
            this.lbl_R09_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R09_PV.Name = "lbl_R09_PV";
            this.lbl_R09_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R09_PV.TabIndex = 0;
            this.lbl_R09_PV.Text = "0";
            this.lbl_R09_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R10_PV
            // 
            this.lbl_R10_PV.AutoSize = true;
            this.lbl_R10_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R10_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R10_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R10_PV.Location = new System.Drawing.Point(601, 315);
            this.lbl_R10_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R10_PV.Name = "lbl_R10_PV";
            this.lbl_R10_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R10_PV.TabIndex = 0;
            this.lbl_R10_PV.Text = "0";
            this.lbl_R10_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R11_PV
            // 
            this.lbl_R11_PV.AutoSize = true;
            this.lbl_R11_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R11_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R11_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R11_PV.Location = new System.Drawing.Point(601, 341);
            this.lbl_R11_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R11_PV.Name = "lbl_R11_PV";
            this.lbl_R11_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R11_PV.TabIndex = 0;
            this.lbl_R11_PV.Text = "0";
            this.lbl_R11_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R12_PV
            // 
            this.lbl_R12_PV.AutoSize = true;
            this.lbl_R12_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R12_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R12_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R12_PV.Location = new System.Drawing.Point(601, 367);
            this.lbl_R12_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R12_PV.Name = "lbl_R12_PV";
            this.lbl_R12_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R12_PV.TabIndex = 0;
            this.lbl_R12_PV.Text = "0";
            this.lbl_R12_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R13_PV
            // 
            this.lbl_R13_PV.AutoSize = true;
            this.lbl_R13_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R13_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R13_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R13_PV.Location = new System.Drawing.Point(601, 393);
            this.lbl_R13_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R13_PV.Name = "lbl_R13_PV";
            this.lbl_R13_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R13_PV.TabIndex = 0;
            this.lbl_R13_PV.Text = "0";
            this.lbl_R13_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R14_PV
            // 
            this.lbl_R14_PV.AutoSize = true;
            this.lbl_R14_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R14_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R14_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R14_PV.Location = new System.Drawing.Point(601, 419);
            this.lbl_R14_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R14_PV.Name = "lbl_R14_PV";
            this.lbl_R14_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R14_PV.TabIndex = 0;
            this.lbl_R14_PV.Text = "0";
            this.lbl_R14_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R15_PV
            // 
            this.lbl_R15_PV.AutoSize = true;
            this.lbl_R15_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R15_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R15_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R15_PV.Location = new System.Drawing.Point(601, 445);
            this.lbl_R15_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R15_PV.Name = "lbl_R15_PV";
            this.lbl_R15_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R15_PV.TabIndex = 0;
            this.lbl_R15_PV.Text = "0";
            this.lbl_R15_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R16_PV
            // 
            this.lbl_R16_PV.AutoSize = true;
            this.lbl_R16_PV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R16_PV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R16_PV.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R16_PV.Location = new System.Drawing.Point(601, 471);
            this.lbl_R16_PV.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R16_PV.Name = "lbl_R16_PV";
            this.lbl_R16_PV.Size = new System.Drawing.Size(40, 20);
            this.lbl_R16_PV.TabIndex = 0;
            this.lbl_R16_PV.Text = "0";
            this.lbl_R16_PV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(555, 55);
            this.label66.Margin = new System.Windows.Forms.Padding(3);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(40, 20);
            this.label66.TabIndex = 0;
            this.label66.Text = "SV";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(601, 55);
            this.label67.Margin = new System.Windows.Forms.Padding(3);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(40, 20);
            this.label67.TabIndex = 0;
            this.label67.Text = "PV";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R01_AL
            // 
            this.lbl_R01_AL.AutoSize = true;
            this.lbl_R01_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R01_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R01_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R01_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R01_AL.Location = new System.Drawing.Point(645, 79);
            this.lbl_R01_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R01_AL.Name = "lbl_R01_AL";
            this.lbl_R01_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R01_AL.TabIndex = 0;
            this.lbl_R01_AL.Text = "0";
            this.lbl_R01_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(647, 55);
            this.label19.Margin = new System.Windows.Forms.Padding(3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 20);
            this.label19.TabIndex = 0;
            this.label19.Text = "AL";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R02_AL
            // 
            this.lbl_R02_AL.AutoSize = true;
            this.lbl_R02_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R02_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R02_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R02_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R02_AL.Location = new System.Drawing.Point(645, 105);
            this.lbl_R02_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R02_AL.Name = "lbl_R02_AL";
            this.lbl_R02_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R02_AL.TabIndex = 0;
            this.lbl_R02_AL.Text = "0";
            this.lbl_R02_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R03_AL
            // 
            this.lbl_R03_AL.AutoSize = true;
            this.lbl_R03_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R03_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R03_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R03_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R03_AL.Location = new System.Drawing.Point(645, 131);
            this.lbl_R03_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R03_AL.Name = "lbl_R03_AL";
            this.lbl_R03_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R03_AL.TabIndex = 0;
            this.lbl_R03_AL.Text = "0";
            this.lbl_R03_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R04_AL
            // 
            this.lbl_R04_AL.AutoSize = true;
            this.lbl_R04_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R04_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R04_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R04_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R04_AL.Location = new System.Drawing.Point(645, 157);
            this.lbl_R04_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R04_AL.Name = "lbl_R04_AL";
            this.lbl_R04_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R04_AL.TabIndex = 0;
            this.lbl_R04_AL.Text = "0";
            this.lbl_R04_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R05_AL
            // 
            this.lbl_R05_AL.AutoSize = true;
            this.lbl_R05_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R05_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R05_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R05_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R05_AL.Location = new System.Drawing.Point(645, 183);
            this.lbl_R05_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R05_AL.Name = "lbl_R05_AL";
            this.lbl_R05_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R05_AL.TabIndex = 0;
            this.lbl_R05_AL.Text = "0";
            this.lbl_R05_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R06_AL
            // 
            this.lbl_R06_AL.AutoSize = true;
            this.lbl_R06_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R06_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R06_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R06_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R06_AL.Location = new System.Drawing.Point(645, 209);
            this.lbl_R06_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R06_AL.Name = "lbl_R06_AL";
            this.lbl_R06_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R06_AL.TabIndex = 0;
            this.lbl_R06_AL.Text = "0";
            this.lbl_R06_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R07_AL
            // 
            this.lbl_R07_AL.AutoSize = true;
            this.lbl_R07_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R07_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R07_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R07_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R07_AL.Location = new System.Drawing.Point(645, 235);
            this.lbl_R07_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R07_AL.Name = "lbl_R07_AL";
            this.lbl_R07_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R07_AL.TabIndex = 0;
            this.lbl_R07_AL.Text = "0";
            this.lbl_R07_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R08_AL
            // 
            this.lbl_R08_AL.AutoSize = true;
            this.lbl_R08_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R08_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R08_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R08_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R08_AL.Location = new System.Drawing.Point(645, 261);
            this.lbl_R08_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R08_AL.Name = "lbl_R08_AL";
            this.lbl_R08_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R08_AL.TabIndex = 0;
            this.lbl_R08_AL.Text = "0";
            this.lbl_R08_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R09_AL
            // 
            this.lbl_R09_AL.AutoSize = true;
            this.lbl_R09_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R09_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R09_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R09_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R09_AL.Location = new System.Drawing.Point(645, 287);
            this.lbl_R09_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R09_AL.Name = "lbl_R09_AL";
            this.lbl_R09_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R09_AL.TabIndex = 0;
            this.lbl_R09_AL.Text = "0";
            this.lbl_R09_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R10_AL
            // 
            this.lbl_R10_AL.AutoSize = true;
            this.lbl_R10_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R10_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R10_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R10_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R10_AL.Location = new System.Drawing.Point(645, 313);
            this.lbl_R10_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R10_AL.Name = "lbl_R10_AL";
            this.lbl_R10_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R10_AL.TabIndex = 0;
            this.lbl_R10_AL.Text = "0";
            this.lbl_R10_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R11_AL
            // 
            this.lbl_R11_AL.AutoSize = true;
            this.lbl_R11_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R11_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R11_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R11_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R11_AL.Location = new System.Drawing.Point(645, 339);
            this.lbl_R11_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R11_AL.Name = "lbl_R11_AL";
            this.lbl_R11_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R11_AL.TabIndex = 0;
            this.lbl_R11_AL.Text = "0";
            this.lbl_R11_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R12_AL
            // 
            this.lbl_R12_AL.AutoSize = true;
            this.lbl_R12_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R12_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R12_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R12_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R12_AL.Location = new System.Drawing.Point(645, 365);
            this.lbl_R12_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R12_AL.Name = "lbl_R12_AL";
            this.lbl_R12_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R12_AL.TabIndex = 0;
            this.lbl_R12_AL.Text = "0";
            this.lbl_R12_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R13_AL
            // 
            this.lbl_R13_AL.AutoSize = true;
            this.lbl_R13_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R13_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R13_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R13_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R13_AL.Location = new System.Drawing.Point(645, 391);
            this.lbl_R13_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R13_AL.Name = "lbl_R13_AL";
            this.lbl_R13_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R13_AL.TabIndex = 0;
            this.lbl_R13_AL.Text = "0";
            this.lbl_R13_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R14_AL
            // 
            this.lbl_R14_AL.AutoSize = true;
            this.lbl_R14_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R14_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R14_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R14_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R14_AL.Location = new System.Drawing.Point(645, 417);
            this.lbl_R14_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R14_AL.Name = "lbl_R14_AL";
            this.lbl_R14_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R14_AL.TabIndex = 0;
            this.lbl_R14_AL.Text = "0";
            this.lbl_R14_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R15_AL
            // 
            this.lbl_R15_AL.AutoSize = true;
            this.lbl_R15_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R15_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R15_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R15_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R15_AL.Location = new System.Drawing.Point(645, 443);
            this.lbl_R15_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R15_AL.Name = "lbl_R15_AL";
            this.lbl_R15_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R15_AL.TabIndex = 0;
            this.lbl_R15_AL.Text = "0";
            this.lbl_R15_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R16_AL
            // 
            this.lbl_R16_AL.AutoSize = true;
            this.lbl_R16_AL.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_R16_AL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_R16_AL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R16_AL.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R16_AL.Location = new System.Drawing.Point(645, 469);
            this.lbl_R16_AL.Margin = new System.Windows.Forms.Padding(1);
            this.lbl_R16_AL.Name = "lbl_R16_AL";
            this.lbl_R16_AL.Size = new System.Drawing.Size(44, 24);
            this.lbl_R16_AL.TabIndex = 0;
            this.lbl_R16_AL.Text = "0";
            this.lbl_R16_AL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label18, 2);
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(463, 55);
            this.label18.Margin = new System.Windows.Forms.Padding(3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 20);
            this.label18.TabIndex = 0;
            this.label18.Text = "MACHINES";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R_Start
            // 
            this.lbl_R_Start.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R_Start, 5);
            this.lbl_R_Start.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R_Start.Location = new System.Drawing.Point(463, 497);
            this.lbl_R_Start.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R_Start.Name = "lbl_R_Start";
            this.lbl_R_Start.Size = new System.Drawing.Size(224, 37);
            this.lbl_R_Start.TabIndex = 23;
            this.lbl_R_Start.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P_Start
            // 
            this.lbl_P_Start.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_P_Start, 5);
            this.lbl_P_Start.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P_Start.Location = new System.Drawing.Point(693, 393);
            this.lbl_P_Start.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P_Start.Name = "lbl_P_Start";
            this.tableLayoutPanel1.SetRowSpan(this.lbl_P_Start, 5);
            this.lbl_P_Start.Size = new System.Drawing.Size(224, 141);
            this.lbl_P_Start.TabIndex = 23;
            this.lbl_P_Start.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A_Start
            // 
            this.lbl_A_Start.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_A_Start, 5);
            this.lbl_A_Start.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A_Start.Location = new System.Drawing.Point(923, 237);
            this.lbl_A_Start.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A_Start.Name = "lbl_A_Start";
            this.tableLayoutPanel1.SetRowSpan(this.lbl_A_Start, 11);
            this.lbl_A_Start.Size = new System.Drawing.Size(224, 297);
            this.lbl_A_Start.TabIndex = 23;
            this.lbl_A_Start.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_R_DT
            // 
            this.lbl_R_DT.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_R_DT, 2);
            this.lbl_R_DT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_R_DT.Font = new System.Drawing.Font("Times New Roman", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_R_DT.Location = new System.Drawing.Point(601, 3);
            this.lbl_R_DT.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_R_DT.Name = "lbl_R_DT";
            this.tableLayoutPanel1.SetRowSpan(this.lbl_R_DT, 2);
            this.lbl_R_DT.Size = new System.Drawing.Size(86, 46);
            this.lbl_R_DT.TabIndex = 23;
            this.lbl_R_DT.Text = "0";
            this.lbl_R_DT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_P_DT
            // 
            this.lbl_P_DT.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_P_DT, 2);
            this.lbl_P_DT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_P_DT.Font = new System.Drawing.Font("Times New Roman", 25F, System.Drawing.FontStyle.Bold);
            this.lbl_P_DT.Location = new System.Drawing.Point(831, 3);
            this.lbl_P_DT.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_P_DT.Name = "lbl_P_DT";
            this.tableLayoutPanel1.SetRowSpan(this.lbl_P_DT, 2);
            this.lbl_P_DT.Size = new System.Drawing.Size(86, 46);
            this.lbl_P_DT.TabIndex = 23;
            this.lbl_P_DT.Text = "0";
            this.lbl_P_DT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_A_DT
            // 
            this.lbl_A_DT.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_A_DT, 2);
            this.lbl_A_DT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_A_DT.Font = new System.Drawing.Font("Times New Roman", 25F, System.Drawing.FontStyle.Bold);
            this.lbl_A_DT.Location = new System.Drawing.Point(1061, 3);
            this.lbl_A_DT.Margin = new System.Windows.Forms.Padding(3);
            this.lbl_A_DT.Name = "lbl_A_DT";
            this.tableLayoutPanel1.SetRowSpan(this.lbl_A_DT, 2);
            this.lbl_A_DT.Size = new System.Drawing.Size(86, 46);
            this.lbl_A_DT.TabIndex = 23;
            this.lbl_A_DT.Text = "0";
            this.lbl_A_DT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chk_R_Connect
            // 
            this.chk_R_Connect.AutoSize = true;
            this.chk_R_Connect.BackColor = System.Drawing.Color.LightGreen;
            this.chk_R_Connect.Checked = true;
            this.chk_R_Connect.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tableLayoutPanel1.SetColumnSpan(this.chk_R_Connect, 3);
            this.chk_R_Connect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_R_Connect.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_R_Connect.Location = new System.Drawing.Point(463, 3);
            this.chk_R_Connect.Name = "chk_R_Connect";
            this.chk_R_Connect.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.tableLayoutPanel1.SetRowSpan(this.chk_R_Connect, 2);
            this.chk_R_Connect.Size = new System.Drawing.Size(132, 46);
            this.chk_R_Connect.TabIndex = 24;
            this.chk_R_Connect.Text = "RUBBER";
            this.chk_R_Connect.UseVisualStyleBackColor = false;
            this.chk_R_Connect.CheckedChanged += new System.EventHandler(this.chk_R_Connect_CheckedChanged);
            // 
            // chk_P_Connect
            // 
            this.chk_P_Connect.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.chk_P_Connect, 3);
            this.chk_P_Connect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_P_Connect.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_P_Connect.Location = new System.Drawing.Point(693, 3);
            this.chk_P_Connect.Name = "chk_P_Connect";
            this.chk_P_Connect.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.tableLayoutPanel1.SetRowSpan(this.chk_P_Connect, 2);
            this.chk_P_Connect.Size = new System.Drawing.Size(132, 46);
            this.chk_P_Connect.TabIndex = 24;
            this.chk_P_Connect.Text = "PLASTIC";
            this.chk_P_Connect.UseVisualStyleBackColor = true;
            // 
            // chk_A_Connect
            // 
            this.chk_A_Connect.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.chk_A_Connect, 3);
            this.chk_A_Connect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_A_Connect.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_A_Connect.Location = new System.Drawing.Point(923, 3);
            this.chk_A_Connect.Name = "chk_A_Connect";
            this.tableLayoutPanel1.SetRowSpan(this.chk_A_Connect, 2);
            this.chk_A_Connect.Size = new System.Drawing.Size(132, 46);
            this.chk_A_Connect.TabIndex = 24;
            this.chk_A_Connect.Text = "ASSEMBLY";
            this.chk_A_Connect.UseVisualStyleBackColor = true;
            // 
            // notifyIcon
            // 
            this.notifyIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon.BalloonTipText = "Gathering data still running";
            this.notifyIcon.BalloonTipTitle = "Assembly Data from OPC";
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "Assembly Data from OPC";
            this.notifyIcon.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_MouseDoubleClick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // frmAssyFromPLC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 537);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1170, 591);
            this.MinimumSize = new System.Drawing.Size(1170, 580);
            this.Name = "frmAssyFromPLC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Garthering Data From OPC";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmAssyFromPLC_Load);
            this.Resize += new System.EventHandler(this.frmAssyFromPLC_Resize);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAB02OK;
        private System.Windows.Forms.TextBox txtAB03OK;
        private System.Windows.Forms.TextBox txtDI01OK;
        private System.Windows.Forms.TextBox txtDI02OK;
        private System.Windows.Forms.TextBox txtPU01OK;
        private System.Windows.Forms.TextBox txtWB01OK;
        private System.Windows.Forms.TextBox txtBL01OK;
        private System.Windows.Forms.TextBox txtWB02OK;
        private System.Windows.Forms.TextBox txtBL02OK;
        private System.Windows.Forms.TextBox txtWB03OK;
        private System.Windows.Forms.TextBox txtMX01OK;
        private System.Windows.Forms.TextBox txtWD01OK;
        private System.Windows.Forms.TextBox txtWD02OK;
        private System.Windows.Forms.TextBox txtPU01NG;
        private System.Windows.Forms.TextBox txtDI02NG;
        private System.Windows.Forms.TextBox txtDI01NG;
        private System.Windows.Forms.TextBox txtAB03NG;
        private System.Windows.Forms.TextBox txtAB02NG;
        private System.Windows.Forms.TextBox txtAB01NG;
        private System.Windows.Forms.TextBox txtAB01OK;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.CheckBox chkConnect;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.CheckBox chkOperate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtWB04OK;
        private System.Windows.Forms.Label lbl_R01;
        private System.Windows.Forms.Label lbl_R01_SV;
        private System.Windows.Forms.Label lbl_R02;
        private System.Windows.Forms.Label lbl_R02_SV;
        private System.Windows.Forms.Label lbl_R03_SV;
        private System.Windows.Forms.Label lbl_R04_SV;
        private System.Windows.Forms.Label lbl_R05_SV;
        private System.Windows.Forms.Label lbl_R06_SV;
        private System.Windows.Forms.Label lbl_R07_SV;
        private System.Windows.Forms.Label lbl_R08_SV;
        private System.Windows.Forms.Label lbl_R09_SV;
        private System.Windows.Forms.Label lbl_R10_SV;
        private System.Windows.Forms.Label lbl_R11_SV;
        private System.Windows.Forms.Label lbl_R12_SV;
        private System.Windows.Forms.Label lbl_R13_SV;
        private System.Windows.Forms.Label lbl_R14_SV;
        private System.Windows.Forms.Label lbl_R15_SV;
        private System.Windows.Forms.Label lbl_R16_SV;
        private System.Windows.Forms.Label lbl_R16;
        private System.Windows.Forms.Label lbl_R15;
        private System.Windows.Forms.Label lbl_R14;
        private System.Windows.Forms.Label lbl_R13;
        private System.Windows.Forms.Label lbl_R12;
        private System.Windows.Forms.Label lbl_R11;
        private System.Windows.Forms.Label lbl_R10;
        private System.Windows.Forms.Label lbl_R09;
        private System.Windows.Forms.Label lbl_R08;
        private System.Windows.Forms.Label lbl_R07;
        private System.Windows.Forms.Label lbl_R06;
        private System.Windows.Forms.Label lbl_R05;
        private System.Windows.Forms.Label lbl_R04;
        private System.Windows.Forms.Label lbl_R03;
        private System.Windows.Forms.Label lbl_R01_PV;
        private System.Windows.Forms.Label lbl_R02_PV;
        private System.Windows.Forms.Label lbl_R03_PV;
        private System.Windows.Forms.Label lbl_R04_PV;
        private System.Windows.Forms.Label lbl_R05_PV;
        private System.Windows.Forms.Label lbl_R06_PV;
        private System.Windows.Forms.Label lbl_R07_PV;
        private System.Windows.Forms.Label lbl_R08_PV;
        private System.Windows.Forms.Label lbl_R09_PV;
        private System.Windows.Forms.Label lbl_R10_PV;
        private System.Windows.Forms.Label lbl_R11_PV;
        private System.Windows.Forms.Label lbl_R12_PV;
        private System.Windows.Forms.Label lbl_R13_PV;
        private System.Windows.Forms.Label lbl_R14_PV;
        private System.Windows.Forms.Label lbl_R15_PV;
        private System.Windows.Forms.Label lbl_R16_PV;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label lbl_R01_AL;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lbl_R02_AL;
        private System.Windows.Forms.Label lbl_R03_AL;
        private System.Windows.Forms.Label lbl_R04_AL;
        private System.Windows.Forms.Label lbl_R05_AL;
        private System.Windows.Forms.Label lbl_R06_AL;
        private System.Windows.Forms.Label lbl_R07_AL;
        private System.Windows.Forms.Label lbl_R08_AL;
        private System.Windows.Forms.Label lbl_R09_AL;
        private System.Windows.Forms.Label lbl_R10_AL;
        private System.Windows.Forms.Label lbl_R11_AL;
        private System.Windows.Forms.Label lbl_R12_AL;
        private System.Windows.Forms.Label lbl_R13_AL;
        private System.Windows.Forms.Label lbl_R14_AL;
        private System.Windows.Forms.Label lbl_R15_AL;
        private System.Windows.Forms.Label lbl_R16_AL;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lbl_R_Start;
        private System.Windows.Forms.Label lbl_R_DT;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbl_P01_SV;
        private System.Windows.Forms.Label lbl_P01_PV;
        private System.Windows.Forms.Label lbl_P01_AL;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lbl_P02_AL;
        private System.Windows.Forms.Label lbl_P03_AL;
        private System.Windows.Forms.Label lbl_P04_AL;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lbl_P05_AL;
        private System.Windows.Forms.Label lbl_P06_AL;
        private System.Windows.Forms.Label lbl_P07_AL;
        private System.Windows.Forms.Label lbl_P08_AL;
        private System.Windows.Forms.Label lbl_P09_AL;
        private System.Windows.Forms.Label lbl_P10_AL;
        private System.Windows.Forms.Label lbl_P11_AL;
        private System.Windows.Forms.Label lbl_P12_AL;
        private System.Windows.Forms.Label lbl_P02_SV;
        private System.Windows.Forms.Label lbl_P03_SV;
        private System.Windows.Forms.Label lbl_P04_SV;
        private System.Windows.Forms.Label lbl_P05_SV;
        private System.Windows.Forms.Label lbl_P06_SV;
        private System.Windows.Forms.Label lbl_P07_SV;
        private System.Windows.Forms.Label lbl_P08_SV;
        private System.Windows.Forms.Label lbl_P09_SV;
        private System.Windows.Forms.Label lbl_P10_SV;
        private System.Windows.Forms.Label lbl_P11_SV;
        private System.Windows.Forms.Label lbl_P12_SV;
        private System.Windows.Forms.Label lbl_P02_PV;
        private System.Windows.Forms.Label lbl_P03_PV;
        private System.Windows.Forms.Label lbl_P04_PV;
        private System.Windows.Forms.Label lbl_P05_PV;
        private System.Windows.Forms.Label lbl_P06_PV;
        private System.Windows.Forms.Label lbl_P07_PV;
        private System.Windows.Forms.Label lbl_P09_PV;
        private System.Windows.Forms.Label lbl_P10_PV;
        private System.Windows.Forms.Label lbl_P11_PV;
        private System.Windows.Forms.Label lbl_P12_PV;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label lbl_A01_SV;
        private System.Windows.Forms.Label lbl_A01_PV;
        private System.Windows.Forms.Label lbl_A01_AL;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label lbl_A02_SV;
        private System.Windows.Forms.Label lbl_A03_SV;
        private System.Windows.Forms.Label lbl_A04_SV;
        private System.Windows.Forms.Label lbl_A05_SV;
        private System.Windows.Forms.Label lbl_A06_SV;
        private System.Windows.Forms.Label lbl_A02_PV;
        private System.Windows.Forms.Label lbl_A03_PV;
        private System.Windows.Forms.Label lbl_A04_PV;
        private System.Windows.Forms.Label lbl_A05_PV;
        private System.Windows.Forms.Label lbl_A06_PV;
        private System.Windows.Forms.Label lbl_A02_AL;
        private System.Windows.Forms.Label lbl_A03_AL;
        private System.Windows.Forms.Label lbl_A04_AL;
        private System.Windows.Forms.Label lbl_A05_AL;
        private System.Windows.Forms.Label lbl_A06_AL;
        private System.Windows.Forms.Label lbl_P_Start;
        private System.Windows.Forms.Label lbl_A_Start;
        private System.Windows.Forms.Label lbl_P_DT;
        private System.Windows.Forms.Label lbl_A_DT;
        private System.Windows.Forms.Label lbl_P08_PV;
        private System.Windows.Forms.CheckBox chk_R_Connect;
        private System.Windows.Forms.CheckBox chk_P_Connect;
        private System.Windows.Forms.CheckBox chk_A_Connect;
    }
}