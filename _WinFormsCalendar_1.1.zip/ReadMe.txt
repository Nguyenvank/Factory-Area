This is the read me file for the WindowsFormsCalendar project.

This project is a fork of the A Professional Calendar project on codeplex.

The current version is 1.1

1.1 features
	- Added Font selection for calendar items
	- Added Foreground Color settings for calendar items
	- Added Background Color settings for calendar items
	- Updated the assembly version information to be correct.

1.0 features
	- Moved the project to the 4.0 framework
	- Added a clock format selection to the calendar