﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections;
using System.Drawing.Printing;
using System.Data.OleDb;
using System.Timers;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Diagnostics;
using System.ComponentModel;
using System.Security.Principal;

//using DataMatrix.net;               // Add ref to DataMatrix.net.dll

namespace Inventory_Data
{
    public static class DBConnect
    {
        public static SqlConnection myCon = null;

        public static void CreateConnection()
        {
            myCon = new SqlConnection(cls.getConnectionString());
            myCon.Open();

        }
    }

    public static class cls
    {
        public static BindingSource bindingSource0 = new BindingSource();
        public static BindingSource bindingSource1 = new BindingSource();
        public static BindingSource bindingSource2 = new BindingSource();
        public static BindingSource bindingSource3 = new BindingSource();
        public static BindingSource bindingSource4 = new BindingSource();
        public static SqlDataAdapter dataAdapter0 = new SqlDataAdapter();
        public static SqlDataAdapter dataAdapter1 = new SqlDataAdapter();
        public static SqlDataAdapter dataAdapter2 = new SqlDataAdapter();
        public static SqlDataAdapter dataAdapter3 = new SqlDataAdapter();
        public static SqlDataAdapter dataAdapter4 = new SqlDataAdapter();

        public static string factcd = "F1";
        public static string factnm = "본사";
        public static string shiftsno = "1";
        public static string shiftsnm = "Night";
        public static string workdate = "";
        public static string sNow = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
        public static DateTime sTime1 = new DateTime();
        public static DateTime sTime2 = new DateTime();



        public static string fnGetDate(string format)
        {
            string s = "";

            DateTime nNow = DateTime.Now;
            //sNow = nNow.ToString("yyyy-MM-dd HH:mm:ss");

            //button2.Text = sNow;//DateTime.Now.TimeOfDay.ToString();

            if (DateTime.Now.TimeOfDay < TimeSpan.Parse("08:00:00"))
            {
                sTime1 = new DateTime(nNow.Year, nNow.Month, nNow.Day, 20, 0, 0).AddDays(-1);
                sTime2 = new DateTime(nNow.Year, nNow.Month, nNow.Day, 8, 0, 0);
                shiftsnm = "Night";
                shiftsno = "2";
            }
            else if (nNow.TimeOfDay >= TimeSpan.Parse("20:00:00"))
            {

                sTime1 = new DateTime(nNow.Year, nNow.Month, nNow.Day, 20, 0, 0);
                sTime2 = new DateTime(nNow.Year, nNow.Month, nNow.Day, 8, 0, 0).AddDays(1);
                shiftsnm = "Night";
                shiftsno = "2";
            }
            else
            {
                sTime1 = new DateTime(nNow.Year, nNow.Month, nNow.Day, 8, 0, 0);
                sTime2 = new DateTime(nNow.Year, nNow.Month, nNow.Day, 20, 0, 0);
                shiftsnm = "Day";
                shiftsno = "1";
            }
            // sTime1 = sTime1.AddDays(-2);
            //workdate = sTime1.ToString("yyyyMMdd");
            //button1.Text = sTime1.ToString("yyyy/MM/dd") + " " + shiftsnm;
            switch (format)
            {
                case "d":   //Date: 09/10/2017
                    s = nNow.ToString("dd/MM/yyyy");
                    break;
                case "dt":  //Date time: 09/10/2017 19:36:22
                    s = nNow.ToString("dd/MM/yyyy HH:mm:ss");
                    break;
                case "t":   //Time: 19:36:22
                    s = nNow.ToString("HH:mm:ss");
                    break;
                case "sd":  //Shift date: Day(Night) 09/10/2017
                    s = (shiftsno == "1") ? (shiftsnm + " " + nNow.ToString("dd/MM/yyyy")) : (shiftsnm + " " + nNow.AddDays(-1).ToString("dd/MM/yyyy"));
                    break;
                case "SD":  // Shift date: DAY(NIGHT) 09/10/2017
                    s = (shiftsno == "1") ? (shiftsnm.ToUpper() + " " + nNow.ToString("dd/MM/yyyy")) : (shiftsnm.ToUpper() + " " + nNow.AddDays(-1).ToString("dd/MM/yyyy"));
                    break;
                case "ct":  //Country time: Vina 19:36:22
                    s = "Vina " + nNow.ToString("HH:mm:ss");
                    break;
                case "CT":  // Country time: VINA 19:36:22
                    s = "VINA " + nNow.ToString("HH:mm:ss");
                    break;
                case "s":   // Shift: Day/Night
                    s = shiftsnm;
                    break;
                case "S":   // Shift (capital): DAY/NIGHT
                    s = shiftsnm.ToUpper();
                    break;
                case "sn":  // Shift number: 1-Day; 2-Night
                    s = shiftsno;
                    break;
                case "lot": // LOT date: 20171009
                    s = (shiftsno == "1") ? nNow.ToString("yyyyMMdd") : nNow.AddDays(-1).ToString("yyyyMMdd");
                    break;
                case "ls":  // LOT number: 20171009-1 (Day); 20171009-2 (Night)
                    s = (shiftsno == "1") ? nNow.ToString("yyyyMMdd") + "-1" : nNow.AddDays(-1).ToString("yyyyMMdd") + "-2";
                    break;
            }

            return s;
        }

        public static DataSet ExecuteDataSet(string sql)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
        }

        public static DataSet ExecuteDataSet(string sql, string conName)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
        }

        public static DataSet ExecuteDataSet(string sql, CommandType cmdType)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
        }

        public static DataSet ExecuteDataSet(string sql, CommandType cmdType, string conName)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
        }

        public static DataSet ExecuteDataSet(string sql, CommandType cmdType, string conName, params SqlParameter[] parameters)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;
                foreach (var item in parameters)
                {
                    cmd.Parameters.Add(item);
                }

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
            //SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            //sParams[0] = new SqlParameter();
            //sParams[0].SqlDbType = SqlDbType.Int;
            //sParams[0].ParameterName = "@IMPORTID";
            //sParams[0].Value = SelectedListID;

            //sParams[1] = new SqlParameter();
            //sParams[1].SqlDbType = SqlDbType.VarChar;
            //sParams[1].ParameterName = "@PREFIX";
            //sParams[1].Value = selectedPrefix;
        }

        public static DataSet ExecuteDataSet(string sql, CommandType cmdType, params SqlParameter[] parameters)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;
                foreach (var item in parameters)
                {
                    cmd.Parameters.Add(item);
                }

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
            //SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            //sParams[0] = new SqlParameter();
            //sParams[0].SqlDbType = SqlDbType.Int;
            //sParams[0].ParameterName = "@IMPORTID";
            //sParams[0].Value = SelectedListID;

            //sParams[1] = new SqlParameter();
            //sParams[1].SqlDbType = SqlDbType.VarChar;
            //sParams[1].ParameterName = "@PREFIX";
            //sParams[1].Value = selectedPrefix;
        }

        public static DataSet ExecuteDataSet(string sql, params SqlParameter[] parameters)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (var item in parameters)
                {
                    cmd.Parameters.Add(item);
                }

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
            //SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            //sParams[0] = new SqlParameter();
            //sParams[0].SqlDbType = SqlDbType.Int;
            //sParams[0].ParameterName = "@IMPORTID";
            //sParams[0].Value = SelectedListID;

            //sParams[1] = new SqlParameter();
            //sParams[1].SqlDbType = SqlDbType.VarChar;
            //sParams[1].ParameterName = "@PREFIX";
            //sParams[1].Value = selectedPrefix;
        }

        public static DataSet ExecuteDataSet(string sql, string table, params SqlParameter[] parameters)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (var item in parameters)
                {
                    cmd.Parameters.Add(item);
                }

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds,table);
                }
                //catch (SqlException ex)
                catch
                {
                    //log to a file or Throw a message ex.Message;
                }
                return ds;
            }
            //SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            //sParams[0] = new SqlParameter();
            //sParams[0].SqlDbType = SqlDbType.Int;
            //sParams[0].ParameterName = "@IMPORTID";
            //sParams[0].Value = SelectedListID;

            //sParams[1] = new SqlParameter();
            //sParams[1].SqlDbType = SqlDbType.VarChar;
            //sParams[1].ParameterName = "@PREFIX";
            //sParams[1].Value = selectedPrefix;
        }

        public static DataTable ExecuteDataTable(string sql)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //Show a message or log a message on ex.Message
                }
                return ds.Tables[0];
            }
        }

        public static DataTable ExecuteDataTable(string sql, string conName)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //Show a message or log a message on ex.Message
                }
                return ds.Tables[0];
            }
        }

        public static DataTable ExecuteDataTable(string sql, CommandType cmdType)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //Show a message or log a message on ex.Message
                }
                return ds.Tables[0];
            }
        }

        public static DataTable ExecuteDataTable(string sql, CommandType cmdType, string conName)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //Show a message or log a message on ex.Message
                }
                return ds.Tables[0];
            }
        }

        public static DataTable ExecuteDataTable(string sql, CommandType cmdType, string conName, params SqlParameter[] parameters)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;
                foreach (var item in parameters)
                {
                    cmd.Parameters.Add(item);
                }

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //Show a message or log a message on ex.Message
                }
                return ds.Tables[0];
            }
            //SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            //sParams[0] = new SqlParameter();
            //sParams[0].SqlDbType = SqlDbType.Int;
            //sParams[0].ParameterName = "@IMPORTID";
            //sParams[0].Value = SelectedListID;

            //sParams[1] = new SqlParameter();
            //sParams[1].SqlDbType = SqlDbType.VarChar;
            //sParams[1].ParameterName = "@PREFIX";
            //sParams[1].Value = selectedPrefix;
        }

        public static DataTable ExecuteDataTable(string sql, CommandType cmdType, params SqlParameter[] parameters)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = cmdType;
                foreach (var item in parameters)
                {
                    cmd.Parameters.Add(item);
                }

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //Show a message or log a message on ex.Message
                }
                return ds.Tables[0];
            }
            //SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            //sParams[0] = new SqlParameter();
            //sParams[0].SqlDbType = SqlDbType.Int;
            //sParams[0].ParameterName = "@IMPORTID";
            //sParams[0].Value = SelectedListID;

            //sParams[1] = new SqlParameter();
            //sParams[1].SqlDbType = SqlDbType.VarChar;
            //sParams[1].ParameterName = "@PREFIX";
            //sParams[1].Value = selectedPrefix;
        }

        public static DataTable ExecuteDataTable(string sql, params SqlParameter[] parameters)
        {
            using (DataSet ds = new DataSet())
            using (SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand(sql, connStr))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (var item in parameters)
                {
                    cmd.Parameters.Add(item);
                }

                try
                {
                    cmd.Connection.Open();
                    new SqlDataAdapter(cmd).Fill(ds);
                }
                //catch (SqlException ex)
                catch
                {
                    //Show a message or log a message on ex.Message
                }
                return ds.Tables[0];
            }
            //SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            //sParams[0] = new SqlParameter();
            //sParams[0].SqlDbType = SqlDbType.Int;
            //sParams[0].ParameterName = "@IMPORTID";
            //sParams[0].Value = SelectedListID;

            //sParams[1] = new SqlParameter();
            //sParams[1].SqlDbType = SqlDbType.VarChar;
            //sParams[1].ParameterName = "@PREFIX";
            //sParams[1].Value = selectedPrefix;
        }

        public static SqlDataReader ExecuteDataReader(string sql)
        {
            SqlDataReader dr;
            SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);

            SqlCommand cmd = new SqlCommand(sql, connStr);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {

                //connStr.Open();
                cmd.Connection.Open();
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                dr.Read();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connStr.Close();
            }

            return dr;
        }

        public static SqlDataReader ExecuteDataReader(string sql, params SqlParameter[] parameters)
        {
            SqlDataReader dr;
            SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);

            SqlCommand cmd = new SqlCommand(sql, connStr);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (var item in parameters)
            {
                cmd.Parameters.Add(item);
            }
            try
            {

                connStr.Open();
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                dr.Read();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connStr.Close();
            }

            return dr;
        }

        public static SqlDataReader ExecuteDataReader(string sql, string conName, params SqlParameter[] parameters)
        {
            SqlDataReader dr;
            SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString);

            SqlCommand cmd = new SqlCommand(sql, connStr);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (var item in parameters)
            {
                cmd.Parameters.Add(item);
            }
            try
            {

                connStr.Open();
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                dr.Read();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connStr.Close();
            }

            return dr;
        }

        public static SqlDataReader ExecuteDataReader(string sql, CommandType cmdType, string conName, params SqlParameter[] parameters)
        {
            SqlDataReader dr;
            SqlConnection connStr = new SqlConnection(ConfigurationManager.ConnectionStrings[conName].ConnectionString);

            SqlCommand cmd = new SqlCommand(sql, connStr);
            cmd.CommandType = cmdType;
            foreach (var item in parameters)
            {
                cmd.Parameters.Add(item);
            }
            try
            {

                connStr.Open();
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                dr.Read();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connStr.Close();
            }

            return dr;
        }

        public static string fnGetRow(string sql, params SqlParameter[] parameters)
        {
            string rowValue = "";
            DataSet ds = new DataSet();
            ds = ExecuteDataSet(sql, parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                rowValue = ds.Tables[0].Rows[0][0].ToString();
            }
            return rowValue;
        }

        public static void RemoveSelection(Object obj)
        {
            TextBox textbox = obj as TextBox;
            if (textbox != null)
            {
                textbox.SelectionLength = 0;
            }
        }

        public static int fnGetCount(string sql)
        {
            int count = 0;
            DataSet ds = new DataSet();
            ds = ExecuteDataSet(sql, CommandType.StoredProcedure);
            count = ds.Tables[0].Rows.Count;
            return count;
        }
        
        public static string getConnectionString()
        {
            string strConn = "";
            strConn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            //strConn = ConfigurationSettings.AppSettings["conn"];
            return strConn;
        }

        public static string GetConnectionStringByName(string name)
        {
            // Assume failure.
            string returnValue = null;

            // Look for the name in the connectionStrings section.
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings[name];

            // If found, return the connection string.
            if (settings != null)
                returnValue = settings.ConnectionString;

            return returnValue;
        }

        public static DataTable fnSelect(string procedure)
        {
            using (DataTable dt = new DataTable())
            {
                string connString = getConnectionString();
                string sql = procedure;

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    try
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter())
                        {
                            da.SelectCommand = new SqlCommand(sql, conn);
                            da.SelectCommand.CommandType = CommandType.StoredProcedure;

                            //DataSet ds = new DataSet();
                            //da.Fill(ds, "result_name");

                            //dt = ds.Tables["result_name"];
                            da.Fill(dt);
                            //foreach (DataRow row in dt.Rows)
                            //{
                            //    //manipulate your data
                            //}
                            //dtData = dt;
                        }
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine("SQL Error: " + ex.Message);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                    finally
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }
                return dt;
            }
        }

        public static DataTable fnSelect(string procedure,string connName)
        {
            using (DataTable dt = new DataTable())
            {
                string connString = GetConnectionStringByName(connName);
                string sql = procedure;

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    try
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter())
                        {
                            da.SelectCommand = new SqlCommand(sql, conn);
                            da.SelectCommand.CommandType = CommandType.StoredProcedure;

                            //DataSet ds = new DataSet();
                            //da.Fill(ds, "result_name");

                            //dt = ds.Tables["result_name"];
                            da.Fill(dt);
                            //foreach (DataRow row in dt.Rows)
                            //{
                            //    //manipulate your data
                            //}
                            //dtData = dt;
                        }
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine("SQL Error: " + ex.Message);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                    finally
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }
                return dt;
            }
        }

        public static DataSet fnDsSelect(string procedure)
        {
            using (DataSet ds = new DataSet())
            {
                string connString = getConnectionString();
                string sql = procedure;

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    try
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter())
                        {
                            da.SelectCommand = new SqlCommand(sql, conn);
                            da.SelectCommand.CommandType = CommandType.StoredProcedure;

                            //DataSet ds = new DataSet();
                            //da.Fill(ds, "result_name");

                            //dt = ds.Tables["result_name"];
                            da.Fill(ds);
                            //foreach (DataRow row in dt.Rows)
                            //{
                            //    //manipulate your data
                            //}
                            //dtData = dt;
                        }
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine("SQL Error: " + ex.Message);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                    finally
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }
                return ds;
            }
        }

        public static void fnUpdDel(string procedure,string connName, params SqlParameter[] parameters)
        {
            try
            {
                using (SqlConnection _con = new SqlConnection(GetConnectionStringByName(connName)))
                using (SqlCommand _cmdDelete = new SqlCommand())
                {
                    _cmdDelete.CommandType = CommandType.StoredProcedure;
                    _cmdDelete.CommandText = procedure;
                    _cmdDelete.Connection = _con;

                    // add parameter
                    foreach (var item in parameters)
                    {
                        _cmdDelete.Parameters.Add(item);
                    }

                    // open connection, execute command, close connection
                    _con.Open();
                    _cmdDelete.ExecuteNonQuery();
                    _con.Close();
                }
            }
            catch
            {

            }
            finally
            {

            }
        }

        public static void fnUpdDel(string procedure, params SqlParameter[] parameters)
        {
            try
            {
                using (SqlConnection _con = new SqlConnection(GetConnectionStringByName("conn")))
                using (SqlCommand _cmdDelete = new SqlCommand())
                {
                    _cmdDelete.CommandType = CommandType.StoredProcedure;
                    _cmdDelete.CommandText = procedure;
                    _cmdDelete.Connection = _con;

                    // add parameter
                    foreach (var item in parameters)
                    {
                        _cmdDelete.Parameters.Add(item);
                    }

                    // open connection, execute command, close connection
                    _con.Open();
                    _cmdDelete.ExecuteNonQuery();
                    _con.Close();
                }
            }
            catch
            {

            }
            finally
            {

            }
        }

        public static int fnUpdDel_Return(string procedure, params SqlParameter[] parameters)
        {
            int returnValue = -1;

            try
            {
                using (SqlConnection _con = new SqlConnection(GetConnectionStringByName("conn")))
                using (SqlCommand _cmd = new SqlCommand())
                {
                    _cmd.CommandType = CommandType.StoredProcedure;
                    _cmd.CommandText = procedure;
                    _cmd.Connection = _con;

                    // add parameter
                    foreach (var item in parameters)
                    {
                        _cmd.Parameters.Add(item);
                    }

                    // open connection, execute command, close connection
                    _con.Open();
                    object returnObj = _cmd.ExecuteScalar();
                    if (returnObj != null)
                    {
                        int.TryParse(returnObj.ToString(), out returnValue);
                    }
                    _con.Close();

                }
            }
            catch
            {

            }
            finally
            {

            }

            return returnValue;
        }

        public static bool IsFormOpen(Type t)
        {
            if (!t.IsSubclassOf(typeof(Form)) && !(t == typeof(Form)))
                throw new ArgumentException("Type is not a form", "t");
            try
            {
                for (int i1 = 0; i1 < Application.OpenForms.Count; i1++)
                {
                    Form f = Application.OpenForms[i1];
                    if (t.IsInstanceOfType(f))
                        return true;
                }
            }
            catch (IndexOutOfRangeException)
            {
                //This can change if they close/open a form while code is running. Just throw it away
            }
            return false;
        }

        public static void GetDataProcedure(string selectProcedure,DataGridView dgv,string strCon)
        {

        }

        public static void fnDatagridClickCell(DataGridView dgv, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = new DataGridViewRow();
            row = dgv.Rows[e.RowIndex];
            dgv.DefaultCellStyle.SelectionBackColor = Color.LightSkyBlue;
            row.Selected = true;
        }

        public static void fnFormatDatagridview(DataGridView dgv, byte fontsize)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridview(DataGridView dgv, byte fontsize, int headerHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridview(DataGridView dgv, byte fontsize, int headerHeight, int rowHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            dgv.RowTemplate.Height = rowHeight;

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridviewWhite(DataGridView dgv, byte fontsize, int headerHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.White;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridviewWhite(DataGridView dgv, byte fontsize, int headerHeight, int rowHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.White;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            dgv.RowTemplate.Height = rowHeight;

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridview(DataGridView dgv, byte fontsize,string scroll)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            switch(scroll)
            {
                case "vertical":
                    dgv.ScrollBars = ScrollBars.Vertical;
                    break;
                case "horizontal":
                    dgv.ScrollBars = ScrollBars.Horizontal;
                    break;
                case "both":
                    dgv.ScrollBars = ScrollBars.Both;
                    break;
            }
            

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridview_FullWidth(DataGridView dgv, byte fontsize)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridview_FullWidth(DataGridView dgv, byte fontsize, int headerHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridview_FullWidth(DataGridView dgv, byte fontsize, int headerHeight, int rowHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            dgv.RowTemplate.Height = rowHeight;

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridviewWhite_FullWidth(DataGridView dgv, byte fontsize, int headerHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.White;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static void fnFormatDatagridviewWhite_FullWidth(DataGridView dgv, byte fontsize, int headerHeight, int rowHeight)
        {
            // Initialize basic DataGridView properties.
            dgv.Dock = DockStyle.Fill;
            dgv.BackgroundColor = Color.LightGray;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            //// Set property values appropriate for read-only display and 
            //// limited interactivity. 
            //dgv.AllowUserToAddRows = false;
            //dgv.AllowUserToDeleteRows = false;
            //dgv.AllowUserToOrderColumns = true;
            //dgv.ReadOnly = true;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.MultiSelect = false;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AllowUserToResizeColumns = false;
            //dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //dgv.AllowUserToResizeRows = false;
            //dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            // Hide row header
            dgv.RowHeadersVisible = false;

            // Hide horizontal scrollbar
            dgv.ScrollBars = ScrollBars.Vertical;

            // Align content to center of cell/column
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set format to column headers
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", fontsize, FontStyle.Bold);

            // Set the selection background color for all the cells.
            dgv.DefaultCellStyle.SelectionBackColor = Color.White;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            // Set the background color for all rows and for alternating rows. 
            // The value for alternating rows overrides the value for all rows. 
            ////dgv.RowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowsDefaultCellStyle.BackColor = Color.White;
            ////dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.White;

            // Set the row and column header styles.
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = headerHeight;


            // Clear selection
            dgv.ClearSelection();

            // Set font and fontsize
            dgv.DefaultCellStyle.Font = new Font("Times New Roman", fontsize);

            dgv.RowTemplate.Height = rowHeight;

            //using (Font font = new Font(dgv.DefaultCellStyle.Font.FontFamily, fontsize, FontStyle.Regular))
            //{
            //    //dgvCodeDefine.Columns["Rating"].DefaultCellStyle.Font = font;
            //    dgv.DefaultCellStyle.Font = font;
            //}
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public class MyDataGrid : DataGrid
        {

            public MyDataGrid()
            {
                //make scrollbar visible & hook up handler
                this.VertScrollBar.Visible = true;
                this.VertScrollBar.VisibleChanged += new EventHandler(ShowScrollBars);
            }

            private int CAPTIONHEIGHT = 21;
            private int BORDERWIDTH = 2;

            private void ShowScrollBars(object sender, EventArgs e)
            {
                if (!this.VertScrollBar.Visible)
                {
                    int width = this.VertScrollBar.Width;
                    this.VertScrollBar.Location = new Point(this.ClientRectangle.Width - width - BORDERWIDTH, CAPTIONHEIGHT);
                    this.VertScrollBar.Size = new Size(width, this.ClientRectangle.Height - CAPTIONHEIGHT - BORDERWIDTH);
                    this.VertScrollBar.Show();
                }
            }
        }

        public static int fnGetDataGridWidth(DataGridView dgv)
        {
            int dgvWidth = 0;
            int verticalWidth = (System.Windows.Forms.SystemInformation.VerticalScrollBarWidth + 5);
            if (dgv.Height > dgv.Rows.GetRowsHeight(DataGridViewElementStates.Visible))
            {
                // Scrollbar not visible
                dgvWidth = dgv.Width;
            }
            else
            {
                // Scrollbar visible
                dgvWidth = dgv.Width - verticalWidth;
            }
            //dgvWidth = (scroll.Visible) ? dgv.Width = 20 : dgv.Width;
            //dgvWidth = ((dgv.ScrollBars & ScrollBars.Vertical) != ScrollBars.None) ? dgv.Width : dgv.Width - 20;
            return dgvWidth;
        }

        public static void GetData(string selectCommand, DataGridView dgv, BindingSource bindingSource, SqlDataAdapter dataAdapter)
        {
            try
            {
                // Specify a connection string. Replace the given value with a 
                // valid connection string for a Northwind SQL Server sample
                // database accessible to your system.
                ////String connectionString = GetConnectionStringByName("conn");
                String connectionString = getConnectionString();

                // Create a new data adapter based on the specified query.
                dataAdapter = new SqlDataAdapter(selectCommand, connectionString);

                // Create a command builder to generate SQL update, insert, and
                // delete commands based on selectCommand. These are used to
                // update the database.
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

                // Populate a new data table and bind it to the BindingSource.
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                bindingSource.DataSource = table;

                // Resize the DataGridView columns to fit the newly loaded content.
                dgv.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader);
            }
            catch (SqlException)
            {
                MessageBox.Show("Please check connection string again.");
            }
        }

        /// <summary>
        /// creates and open a sqlconnection
        /// </summary>
        /// <param name="connectionString">
        /// A <see cref="System.String"/> that contains the sql connectin parameters
        /// </param>
        /// <returns>
        /// A <see cref="SqlConnection"/> 
        /// </returns>
        public static SqlConnection GetConnection(string connectionString)
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
            }
            //catch (SqlException ex)
            catch
            {
                //ex should be written into a error log

                // dispose of the connection to avoid connections leak
                if (connection != null)
                {
                    connection.Dispose();
                }
            }
            return connection;
        }

        /// <summary>
        /// Creates a sqlcommand
        /// </summary>
        /// <param name="connection">
        /// A <see cref="SqlConnection"/>
        /// </param>
        /// <param name="commandText">
        /// A <see cref="System.String"/> of the sql query.
        /// </param>
        /// <param name="commandType">
        /// A <see cref="CommandType"/> of the query type.
        /// </param>
        /// <returns>
        /// A <see cref="SqlCommand"/>
        /// </returns>
        public static SqlCommand GetCommand(this SqlConnection connection, string commandText, CommandType commandType)
        {
            SqlCommand command = connection.CreateCommand();
            command.CommandTimeout = connection.ConnectionTimeout;
            command.CommandType = commandType;
            command.CommandText = commandText;
            return command;
        }

        /// <summary>
        /// Adds a parameter to the command parameter array.
        /// </summary>
        /// <param name="command">
        /// A <see cref="SqlCommand"/> 
        /// </param>
        /// <param name="parameterName">
        /// A <see cref="System.String"/> of the named parameter in the sql query.
        /// </param>
        /// <param name="parameterValue">
        /// A <see cref="System.Object"/> of the parameter value.
        /// </param>
        /// <param name="parameterSqlType">
        /// A <see cref="SqlDbType"/>
        /// </param>
        public static void AddParameter(this SqlCommand command, string parameterName, object parameterValue, SqlDbType parameterSqlType)
        {
            if (!parameterName.StartsWith("@"))
            {
                parameterName = "@" + parameterName;
            }
            command.Parameters.Add(parameterName, parameterSqlType);
            command.Parameters[parameterName].Value = parameterValue;
        }

        public static string Encrypt(string clearText)
        {
            string EncryptionKey = "abc!123123";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }

        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "abc!123123";
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        public static string Left(string Text, int TextLenth)
        {
            string ConvertText;
            if (Text.Length < TextLenth)
            {
                TextLenth = Text.Length;
            }
            ConvertText = Text.Substring(0, TextLenth);
            return ConvertText;
        }

        public static string Right(string Text, int TextLenth)
        {
            string ConvertText;
            if (Text.Length < TextLenth)
            {
                TextLenth = Text.Length;
            }
            ConvertText = Text.Substring(Text.Length - TextLenth, TextLenth);
            return ConvertText;
        }

        public static string Mid(string Text, int Startint, int Endint)
        {
            string ConvertText;
            if (Startint < Text.Length || Endint < Text.Length)
            {
                ConvertText = Text.Substring(Startint, Endint);
                return ConvertText;
            }
            else
                return Text;
        }

        public static string VietHoa(string s)
        {
            if (String.IsNullOrEmpty(s))
                return s;

            string result = "";

            //lấy danh sách các từ  

            string[] words = s.Split(' ');

            foreach (string word in words)
            {
                // từ nào là các khoảng trắng thừa thì bỏ  
                if (word.Trim() != "")
                {
                    if (word.Length > 1)
                        result += word.Substring(0, 1).ToUpper() + word.Substring(1).ToLower() + " ";
                    else
                        result += word.ToUpper() + " ";
                }

            }
            return result.Trim();
        }

        public static string IndexOf(string str,byte strPosReturn)
        {
            // strPosReturn: 0: before; 1: after
            string pos = "";
            int dot = str.IndexOf(". ");
            string before = str.Substring(0, dot);
            string after = str.Substring(dot + 1);
            pos = (strPosReturn == 0) ? before : after;
            return pos;
        }

        public static string IndexOf(string str,string compare, byte strPosReturn)
        {
            // strPosReturn: 0: before; 1: after
            string pos = "";
            int dot = str.IndexOf(compare);
            string before = str.Substring(0, dot);
            string after = str.Substring(dot + 1);
            pos = (strPosReturn == 0) ? before : after;
            return pos;
        }

        public static void SerialPortOpen(SerialPort srp, string portname)
        {
            srp.Close();
            srp.PortName = portname;
            srp.BaudRate = 38400;
            srp.DataBits = 8;
            srp.Parity = Parity.None;
            srp.StopBits = StopBits.One;
            srp.Open();
        }

        public static bool IsNumeric(this string s)
        {
            foreach (char c in s)
            {
                if (!char.IsDigit(c) && c != '.')
                {
                    return false;
                }
            }

            return true;
        }

        public class AutoClosingMessageBox
        {
            System.Threading.Timer _timeoutTimer;
            string _caption;
            AutoClosingMessageBox(string text, string caption, int timeout)
            {
                _caption = caption;
                _timeoutTimer = new System.Threading.Timer(OnTimerElapsed,
                    null, timeout, System.Threading.Timeout.Infinite);
                MessageBox.Show(text, caption);
            }

            public static void Show(string text, string caption, int timeout)
            {
                new AutoClosingMessageBox(text, caption, timeout);
            }

            void OnTimerElapsed(object state)
            {
                IntPtr mbWnd = FindWindow(null, _caption);
                if (mbWnd != IntPtr.Zero)
                    SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                _timeoutTimer.Dispose();
            }
            const int WM_CLOSE = 0x0010;
            [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
            static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
            [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
            static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
        }

        public static string appName()
        {
            string _appname = "";
            return _appname = Application.ProductName;
        }

        public static bool isTimeBetween(this DateTime time, DateTime startTime, DateTime endTime)
        {
            if (time.TimeOfDay == startTime.TimeOfDay) return true;
            if (time.TimeOfDay == endTime.TimeOfDay) return true;

            if (startTime.TimeOfDay <= endTime.TimeOfDay)
                return (time.TimeOfDay >= startTime.TimeOfDay && time.TimeOfDay <= endTime.TimeOfDay);
            else
                return !(time.TimeOfDay >= endTime.TimeOfDay && time.TimeOfDay <= startTime.TimeOfDay);
        }

        public static double fnTimeSpan(DateTime _timeFr, DateTime _timeTo, string type)
        {
            double _span = 0;
            TimeSpan span;
            double second;
            if (_timeTo >= _timeFr)
            {
                span = _timeTo - _timeFr;
            }
            else
            {
                span = _timeTo.AddDays(1) - _timeFr;
            }
            switch(type.ToLower())
            {
                case "h":
                case "hour":
                    second = (span.TotalSeconds) / 3600;
                    _span = second;
                    break;
                case "m":
                case "minute":
                    second = (span.TotalSeconds) / 60;
                    _span = second;
                    break;
                case "s":
                case "second":
                    second = (span.TotalSeconds);
                    _span = second;
                    break;
            }
            return _span;
        }

        public static byte ExportToExcel(DataGridView dgv, string wsheet)
        {
            byte status = 0;
            // Creating a Excel object. 
            Microsoft.Office.Interop.Excel._Application excel = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel._Workbook workbook = excel.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

            try
            {
                //excel.Columns.ColumnWidth = 25;
                //worksheet = workbook.ActiveSheet;
                excel.Visible = true;
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "Records";


                //worksheet.Name = "ExportedFromDatGrid";
                worksheet.Name = wsheet;

                int cellRowIndex = 1;
                int cellColumnIndex = 1;

                for (int i = 0; i < dgv.Columns.Count; i++)
                {
                    worksheet.Cells[1, i + 1] = dgv.Columns[i].HeaderText;
                }

                //for (int i = 1; i < dgv.Columns.Count + 1; i++)
                //{
                //    excel.Cells[1, i] = dgv.Columns[i - 1].HeaderText;
                //}

                //Loop through each row and read value from each column. 
                for (int i = 0; i < dgv.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dgv.Columns.Count; j++)
                    {
                        //// Excel index starts from 1,1. As first Row would have the Column headers, adding a condition check. 
                        //if (cellRowIndex == 1)
                        //{
                        //    worksheet.Cells[cellRowIndex, cellColumnIndex] = dgv.Columns[j].HeaderText;
                        //}
                        //else
                        //{
                        //    worksheet.Cells[cellRowIndex, cellColumnIndex] = dgv.Rows[i-1].Cells[j-1].Value.ToString();
                        //}

                        worksheet.Cells[cellRowIndex, cellColumnIndex] = dgv.Rows[i].Cells[j].Value.ToString();
                        cellColumnIndex++;
                    }
                    cellColumnIndex = 1;
                    cellRowIndex++;
                }

                //Getting the location and file name of the excel to save from user. 
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx";
                saveDialog.FilterIndex = 1;

                if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    workbook.SaveAs(saveDialog.FileName);
                    //MessageBox.Show("Export Successful");
                    status = 1;
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
                status = 0;
            }
            finally
            {
                excel.Quit();
                workbook = null;
                excel = null;
            }
            return status;
        }

        public static void ExportTOExcel(DataGridView gridviewID)
        {
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            //add data 
            int StartCol = 1;//`enter code here`
                int StartRow = 1;
            int j = 0, i = 0;

            //Write Headers
            for (j = 0; j < gridviewID.Columns.Count; j++)
            {
                Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)xlWorkSheet.Cells[StartRow, StartCol + j];
                myRange.Value2 = gridviewID.Columns[j].HeaderText;
            }

            StartRow++;

            //Write datagridview content
            for (i = 0; i < gridviewID.Rows.Count; i++)
            {
                for (j = 0; j < gridviewID.Columns.Count; j++)
                {
                    try
                    {
                        Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)xlWorkSheet.Cells[StartRow + i, StartCol + j];
                        myRange.Value2 = gridviewID[j, i].Value == null ? "" : gridviewID[j, i].Value;
                    }
                    catch
                    {
                        ;
                    }
                }
            }

            Microsoft.Office.Interop.Excel.Range chartRange;

            Microsoft.Office.Interop.Excel.ChartObjects xlCharts = (Microsoft.Office.Interop.Excel.ChartObjects)xlWorkSheet.ChartObjects(Type.Missing);
            Microsoft.Office.Interop.Excel.ChartObject myChart = (Microsoft.Office.Interop.Excel.ChartObject)xlCharts.Add(10, 80, 300, 250);
            Microsoft.Office.Interop.Excel.Chart chartPage = myChart.Chart;

            chartRange = xlWorkSheet.get_Range("A1", "B" + gridviewID.Rows.Count);
            chartPage.SetSourceData(chartRange, misValue);
            chartPage.ChartType = Microsoft.Office.Interop.Excel.XlChartType.xlColumnClustered;

            xlApp.Visible = true;

        }

        public static void ExportToExcel_v2(DataGridView dgv)
        {
            try
            {
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                app.Visible = true;
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "Records";

                try
                {
                    for (int i = 0; i < dgv.Columns.Count; i++)
                    {
                        worksheet.Cells[1, i + 1] = dgv.Columns[i].HeaderText;
                    }
                    for (int i = 0; i < dgv.Rows.Count; i++)
                    {
                        for (int j = 0; j < dgv.Columns.Count; j++)
                        {
                            if (dgv.Rows[i].Cells[j].Value != null)
                            {
                                worksheet.Cells[i + 2, j + 1] = dgv.Rows[i].Cells[j].Value.ToString();
                            }
                            else
                            {
                                worksheet.Cells[i + 2, j + 1] = "";
                            }
                        }
                    }

                    //Getting the location and file name of the excel to save from user. 
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                    saveDialog.FilterIndex = 2;

                    if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        workbook.SaveAs(saveDialog.FileName);
                        MessageBox.Show("Export Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                finally
                {
                    app.Quit();
                    workbook = null;
                    worksheet = null;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString()); }
        }

        public static void showTooltip(Label lbl, string title, string msg)
        {
            ToolTip yourToolTip = new ToolTip();
            //The below are optional, of course,

            yourToolTip.ToolTipTitle = title;
            yourToolTip.ToolTipIcon = ToolTipIcon.Info;
            yourToolTip.IsBalloon = true;
            yourToolTip.ShowAlways = true;

            yourToolTip.SetToolTip(lbl, msg);
        }

        public static void ManageCheckGroupBox(CheckBox chk, GroupBox grp)
        {
            // Make sure the CheckBox isn't in the GroupBox.
            // This will only happen the first time.
            if (chk.Parent == grp)
            {
                // Reparent the CheckBox so it's not in the GroupBox.
                grp.Parent.Controls.Add(chk);

                // Adjust the CheckBox's location.
                chk.Location = new Point(
                    chk.Left + grp.Left,
                    chk.Top + grp.Top);

                // Move the CheckBox to the top of the stacking order.
                chk.BringToFront();
            }

            // Enable or disable the GroupBox.
            grp.Enabled = chk.Checked;
        }

        public static bool fnCheckPackCode(string packCode)
        {
            string codeCheck = cls.Left(packCode, 3);
            string codeType = cls.Mid(packCode, 4, 3);
            string codeID = cls.Right(packCode, 5);


            if (codeCheck.ToUpper() == "MMT" && (codeType.ToUpper() == "PCS" || codeType.ToUpper() == "BOX" || codeType.ToUpper() == "PAK" || codeType.ToUpper() == "PAL"))
                return true;

            if (codeCheck.ToUpper() == "PRO" && (codeType.ToUpper() == "PCS" || codeType.ToUpper() == "BOX" || codeType.ToUpper() == "CAR" || codeType.ToUpper() == "PAL"))
                return true;

            return false;
        }

        public static void fnDateTime(Label lbl,byte kind)
        {
            DateTime _dt = DateTime.Now;
            if(check.IsConnectedToInternet())
            {
                switch(kind)
                {
                    case 1:
                        lbl.Text = cls.fnGetDate("SD");
                        break;
                    case 2:
                        lbl.Text = cls.fnGetDate("CT");
                        break;
                    case 3:
                        lbl.Text = cls.fnGetDate("SD") + " - " + cls.fnGetDate("CT");
                        break;
                }
                lbl.ForeColor = Color.Black;
            }
            else
            {
                switch (kind)
                {
                    case 1:
                        lbl.Text = String.Format("{0:dd/MM/yyyy}", _dt);
                        break;
                    case 2:
                        lbl.Text = String.Format("{0:HH:mm:ss}", _dt);
                        break;
                    case 3:
                        lbl.Text = String.Format("{0:dd/MM/yyyy HH:mm:ss}", _dt);
                        break;
                }
                lbl.ForeColor = Color.Red;
            }
        }

        public static void fnDateTime(ToolStripStatusLabel lbl, byte kind)
        {
            DateTime _dt = DateTime.Now;
            if (check.IsConnectedToInternet())
            {
                switch (kind)
                {
                    case 1:
                        lbl.Text = cls.fnGetDate("SD");
                        break;
                    case 2:
                        lbl.Text = cls.fnGetDate("CT");
                        break;
                    case 3:
                        lbl.Text = cls.fnGetDate("SD") + " - " + cls.fnGetDate("CT");
                        break;
                }
                lbl.ForeColor = Color.Black;
            }
            else
            {
                switch (kind)
                {
                    case 1:
                        lbl.Text = String.Format("{0:dd/MM/yyyy}", _dt);
                        break;
                    case 2:
                        lbl.Text = String.Format("{0:HH:mm:ss}", _dt);
                        break;
                    case 3:
                        lbl.Text = String.Format("{0:dd/MM/yyyy HH:mm:ss}", _dt);
                        break;
                }
                lbl.ForeColor = Color.Red;
            }
        }

        public static void fnDateTime(Button btn, byte kind)
        {
            DateTime _dt = DateTime.Now;
            if (check.IsConnectedToInternet())
            {
                switch (kind)
                {
                    case 1:
                        btn.Text = cls.fnGetDate("SD");
                        break;
                    case 2:
                        btn.Text = cls.fnGetDate("CT");
                        break;
                    case 3:
                        btn.Text = cls.fnGetDate("SD") + " - " + cls.fnGetDate("CT");
                        break;
                }
                btn.ForeColor = Color.Black;
            }
            else
            {
                switch (kind)
                {
                    case 1:
                        btn.Text = String.Format("{0:dd/MM/yyyy}", _dt);
                        break;
                    case 2:
                        btn.Text = String.Format("{0:HH:mm:ss}", _dt);
                        break;
                    case 3:
                        btn.Text = String.Format("{0:dd/MM/yyyy HH:mm:ss}", _dt);
                        break;
                }
                btn.ForeColor = Color.Red;
            }
        }

        public static void fnMessage(ToolStripStatusLabel tssMessage, string msg, int type)
        {
            tssMessage.Text = "";
            if (msg != "" && msg != null)
            {
                switch (type)
                {
                    case 0:
                        // NORMAL MESSAGE
                        tssMessage.ForeColor = Color.Black;
                        break;
                    case 1:
                        // SUCCESS MESSAGE
                        tssMessage.ForeColor = Color.DarkGreen;
                        break;
                    case 2:
                        // COMMON ERRORS MESSAGE
                        tssMessage.ForeColor = Color.White;
                        tssMessage.BackColor = Color.Red;
                        break;
                    case 3:
                        // SQL ERRORS MESSAGE
                        tssMessage.ForeColor = Color.White;
                        tssMessage.BackColor = Color.Tomato;
                        break;
                }
                tssMessage.Text = msg;
            }
            else
            {
                tssMessage.Text = "";
                tssMessage.ForeColor = Color.FromKnownColor(KnownColor.ControlText);
            }
        }

        public static void fnMessage(Label lblMessage, string msg, int type)
        {
            lblMessage.Text = "";
            if (msg != "" && msg != null)
            {
                switch (type)
                {
                    case 0:
                        // NORMAL MESSAGE
                        lblMessage.ForeColor = Color.Black;
                        break;
                    case 1:
                        // SUCCESS MESSAGE
                        lblMessage.ForeColor = Color.DarkGreen;
                        break;
                    case 2:
                        // COMMON ERRORS MESSAGE
                        lblMessage.ForeColor = Color.Red;
                        break;
                    case 3:
                        // SQL ERRORS MESSAGE
                        lblMessage.ForeColor = Color.Tomato;
                        break;
                }
                lblMessage.Text = msg;
            }
            else
            {
                lblMessage.Text = "";
                lblMessage.ForeColor = Color.FromKnownColor(KnownColor.ControlText);
            }
        }

        public static void fnSetDateTime(ToolStripStatusLabel tss)
        {
            if (check.IsConnectedToInternet())
            {
                tss.Text = cls.fnGetDate("SD") + " - " + cls.fnGetDate("CT");
                tss.ForeColor = Color.Black;
            }
            else
            {
                tss.Text = String.Format("{0:dd/MM/yyyy HH:mm:ss}", DateTime.Now);
                tss.ForeColor = Color.Red;
            }
        }

        public static void fnSetDateTime(Label lbl)
        {
            if (check.IsConnectedToInternet())
            {
                lbl.Text = cls.fnGetDate("SD") + " - " + cls.fnGetDate("CT");
                lbl.ForeColor = Color.Black;
            }
            else
            {
                lbl.Text = String.Format("{0:dd/MM/yyyy HH:mm:ss}", DateTime.Now);
                lbl.ForeColor = Color.Red;
            }
        }

        public static void fnCopyDatagridviewContent(DataGridView dgv, ToolStripStatusLabel tss)

        {
            string _msgText = "";
            int _msgType = 0;
            if (dgv.Rows.Count > 0)
            {
                try
                {
                    dgv.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
                    dgv.SelectAll();
                    Clipboard.SetDataObject(dgv.GetClipboardContent());
                    dgv.ClearSelection();

                    _msgText = "Danh sách đã copy xong";
                    _msgType = 1;
                }
                catch (Exception ex)
                {
                    _msgText = "Có lỗi phát sinh";
                    _msgType = 2;
                    MessageBox.Show(ex.ToString());
                }
                finally
                {

                }
            }
            else
            {
                _msgText = "Danh sách không có gì để copy. Hãy kiểm tra lại";
                _msgType = 1;
            }
            cls.fnMessage(tss, _msgText, _msgType);
        }

        public static void fnCopyDatagridviewContent(DataGridView dgv, string msg)

        {
            string _msgText = "";
            int _msgType = 0;
            if (dgv.Rows.Count > 0)
            {
                try
                {
                    dgv.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
                    dgv.SelectAll();
                    Clipboard.SetDataObject(dgv.GetClipboardContent());
                    dgv.ClearSelection();

                    _msgText = "Danh sách đã copy xong";
                    _msgType = 1;
                }
                catch (Exception ex)
                {
                    _msgText = "Có lỗi phát sinh";
                    _msgType = 2;
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    _msgText = msg;
                }
            }
            else
            {
                _msgText = "Danh sách không có gì để copy. Hãy kiểm tra lại";
                _msgType = 1;
            }
            MessageBox.Show(_msgText);
        }

        public static string CreateFolderMissing(string path)
        {
            string pathReturn = "";
            bool folderExists = Directory.Exists(path);
            if (!folderExists)
                Directory.CreateDirectory(path);
            pathReturn = path;
            return pathReturn;
        }

        public static string RemoveUnicode(string text)
        {
            string[] arr1 = new string[] { "á", "à", "ả", "ã", "ạ", "â", "ấ", "ầ", "ẩ", "ẫ", "ậ", "ă", "ắ", "ằ", "ẳ", "ẵ", "ặ", "đ", "é","è","ẻ","ẽ","ẹ","ê","ế","ề","ể","ễ","ệ","í","ì","ỉ","ĩ","ị","ó","ò","ỏ","õ","ọ","ô","ố","ồ","ổ","ỗ","ộ","ơ","ớ","ờ","ở","ỡ","ợ","ú","ù","ủ","ũ","ụ","ư","ứ","ừ","ử","ữ","ự","ý","ỳ","ỷ","ỹ","ỵ",};
            string[] arr2 = new string[] { "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a","d","e","e","e","e","e","e","e","e","e","e","e","i","i","i","i","i","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","u","u","u","u","u","u","u","u","u","u","u","y","y","y","y","y",};
            for (int i = 0; i < arr1.Length; i++)
            {
                text = text.Replace(arr1[i], arr2[i]);
                text = text.Replace(arr1[i].ToUpper(), arr2[i].ToUpper());
            }
            return text;
        }

        public static void fnFilterDatagridRow(DataGridView dgv, TextBox txt, int col)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dgv.DataSource;
            bs.Filter = String.Format("CONVERT([" + dgv.Columns[col].DataPropertyName + "], System.String) like '%" + txt.Text.Replace("'", "''") + "%'");
            dgv.DataSource = bs;
        }

        public static void fnFilterDatagridRows(DataGridView dgv, TextBox txt,int col)
        {
            string substring = txt.Text;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                row.Visible = ((string)row.Cells[col].Value).IndexOf(substring, 0, StringComparison.CurrentCultureIgnoreCase) != -1;
            }
        }

        public static string RemoveSpecialCharacters(string str)
        {
            string result = "";
            result = Regex.Replace(str, @"[^0-9a-zA-Z]+", "-");
            return result;
        }

        [DllImport("uxtheme.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]

        private static extern int SetWindowTheme(IntPtr hwnd, string pszSubAppName, string pszSubIdList);

        public static void SetTreeViewTheme(IntPtr treeHandle)
        {
            SetWindowTheme(treeHandle, "explorer", null);
        }

        /// <summary>
        /// Finds a Control recursively. Note finds the first match and exists
        /// </summary>
        /// <param name="container">The container to search for the control passed. Remember
        /// all controls (Panel, GroupBox, Form, etc are all containsers for controls
        /// </param>
        /// <param name="name">Name of the control to look for</param>
        public static Control FindControlRecursive(Control container, string name)
        {
            if (container.Name == name) return container;

            foreach (Control ctrl in container.Controls)
            {
                Control foundCtrl = FindControlRecursive(ctrl, name);

                if (foundCtrl != null) return foundCtrl;
            }

            return null;
        }

        //public static string DecodeText(string sFileName)
        //{
        //    DmtxImageDecoder decoder = new DmtxImageDecoder();
        //    System.Drawing.Bitmap oBitmap = new System.Drawing.Bitmap(sFileName);
        //    List<string> oList = decoder.DecodeImage(oBitmap);

        //    StringBuilder sb = new StringBuilder();
        //    sb.Length = 0;
        //    foreach (string s in oList)
        //    {
        //        sb.Append(s);
        //    }
        //    return sb.ToString();
        //}

        public static void onlynumwithsinglepoint(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
            TextBox txtDecimal = sender as TextBox;
            if (e.KeyChar == '.' && txtDecimal.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        public static string makeRandomPassword(int length)
        {
            string UpperCase = "QWERTYUIOPASDFGHJKLZXCVBNM";
            string LowerCase = "qwertyuiopasdfghjklzxcvbnm";
            string Digits = "1234567890";
            string allCharacters = UpperCase + LowerCase + Digits;
            //Random will give random charactors for given length  
            Random r = new Random();
            String password = "";
            for (int i = 0; i < length; i++)
            {
                double rand = r.NextDouble();
                if (i == 0)
                {
                    password += UpperCase.ToCharArray()[(int)Math.Floor(rand * UpperCase.Length)];
                }
                else
                {
                    password += allCharacters.ToCharArray()[(int)Math.Floor(rand * allCharacters.Length)];
                }
            }
            Console.WriteLine(password);
            Console.ReadLine();
            return password;
        }

        public static DialogResult InputBox(string title, string promptText, ref string value)
        {
            Form form = new Form();
            Label label = new Label();
            TextBox textBox = new TextBox();
            Button buttonOk = new Button();
            Button buttonCancel = new Button();

            form.Text = title;
            label.Text = promptText;
            textBox.Text = value;

            buttonOk.Text = "OK";
            buttonCancel.Text = "Cancel";
            buttonOk.DialogResult = DialogResult.OK;
            buttonCancel.DialogResult = DialogResult.Cancel;

            label.SetBounds(9, 20, 372, 13);
            textBox.SetBounds(12, 36, 372, 20);
            buttonOk.SetBounds(228, 72, 75, 23);
            buttonCancel.SetBounds(309, 72, 75, 23);

            label.AutoSize = true;
            textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
            buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

            form.ClientSize = new Size(396, 107);
            form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
            form.ClientSize = new Size(Math.Max(300, label.Right + 10), form.ClientSize.Height);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;
            form.AcceptButton = buttonOk;
            form.CancelButton = buttonCancel;

            DialogResult dialogResult = form.ShowDialog();
            value = textBox.Text;
            return dialogResult;
        }

        public class Ini
        {
            private string iniPath;

            static bool factory_index;

            /// <summary>
            /// Vị trí file .ini
            /// </summary>
            /// <param name="path">Vị trí file .ini</param>
            public Ini(string path)
            {
                // TODO: Complete member initialization
                iniPath = path;
            }

            [DllImport("kernel32.dll")]
            //ini 파일 읽기
            private static extern int GetPrivateProfileString(String section, String key, String def, StringBuilder retVal, int size, String filepath);
            [DllImport("kernel32.dll")]
            //ini 파일 쓰기
            private static extern int WritePrivateProfileString(String section, String key, String val, String filepath);

            //ini 파일 유무
            /// <summary>
            /// Kiểm tra file .ini
            /// </summary>
            /// <returns>True: có tồn tại | False: không tìm thấy</returns>
            public bool IniExists()
            {
                factory_index = File.Exists(iniPath);

                return factory_index;
            }

            /// <summary>
            /// ini 파일 생성
            /// </summary>
            public void CreateIni()
            {
                File.Create(iniPath).Close();
            }

            /// <summary>
            /// Đọc giá trị từ file .ini
            /// </summary>
            /// <param name="section">Section của nội dung file .ini</param>
            /// <param name="key">Key của section trong file .ini</param>
            /// <returns>Trả về giá trị của [section, key] tương ứng</returns>
            public string GetIniValue(string section, string key)
            {
                StringBuilder result = new StringBuilder(255);
                int i = GetPrivateProfileString(section, key, "", result, 255, iniPath);
                return result.ToString();
            }


            public string GetIniValue(string section, string key, string value)
            {
                StringBuilder result = new StringBuilder(255);

                try
                {
                    int i = GetPrivateProfileString(section, key, "", result, 255, iniPath);

                    if (result.ToString() == "")
                    {
                        SetIniValue(section, key, value);
                        return value.ToString();
                    }
                    else
                    {
                        return result.ToString();
                    }

                }
                catch (Exception)
                {
                    SetIniValue(section, key, value);
                    return value.ToString();

                }

            }
            /// <summary>
            /// Ghi giá trị vào file .ini
            /// </summary>
            /// <param name="section">Section</param>
            /// <param name="key">Key</param>
            /// <param name="val">Giá trị</param>
            public void SetIniValue(string section, string key, string val)
            {
                WritePrivateProfileString(section, key, val, iniPath);
            }
        }

        /// <summary>
        /// PInvoke wrapper for CopyEx
        /// http://msdn.microsoft.com/en-us/library/windows/desktop/aa363852.aspx
        /// </summary>
        public class XCopy
        {
            public static void Copy(string source, string destination, bool overwrite, bool nobuffering)
            {
                new XCopy().CopyInternal(source, destination, overwrite, nobuffering, null);
            }

            public static void Copy(string source, string destination, bool overwrite, bool nobuffering, EventHandler<ProgressChangedEventArgs> handler)
            {
                new XCopy().CopyInternal(source, destination, overwrite, nobuffering, handler);
            }

            private event EventHandler Completed;
            private event EventHandler<ProgressChangedEventArgs> ProgressChanged;

            private int IsCancelled;
            private int FilePercentCompleted;
            private string Source;
            private string Destination;

            private XCopy()
            {
                IsCancelled = 0;
            }

            private void CopyInternal(string source, string destination, bool overwrite, bool nobuffering, EventHandler<ProgressChangedEventArgs> handler)
            {
                try
                {
                    CopyFileFlags copyFileFlags = CopyFileFlags.COPY_FILE_RESTARTABLE;
                    if (!overwrite)
                        copyFileFlags |= CopyFileFlags.COPY_FILE_FAIL_IF_EXISTS;

                    if (nobuffering)
                        copyFileFlags |= CopyFileFlags.COPY_FILE_NO_BUFFERING;

                    Source = source;
                    Destination = destination;

                    if (handler != null)
                        ProgressChanged += handler;

                    bool result = CopyFileEx(Source, Destination, new CopyProgressRoutine(CopyProgressHandler), IntPtr.Zero, ref IsCancelled, copyFileFlags);
                    if (!result)
                        throw new Win32Exception(Marshal.GetLastWin32Error());
                }
                catch (Exception)
                {
                    if (handler != null)
                        ProgressChanged -= handler;

                    throw;
                }
            }

            private void OnProgressChanged(double percent)
            {
                // only raise an event when progress has changed
                if ((int)percent > FilePercentCompleted)
                {
                    FilePercentCompleted = (int)percent;

                    var handler = ProgressChanged;
                    if (handler != null)
                        handler(this, new ProgressChangedEventArgs((int)FilePercentCompleted, null));
                }
            }

            private void OnCompleted()
            {
                var handler = Completed;
                if (handler != null)
                    handler(this, EventArgs.Empty);
            }

            #region PInvoke

            [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
            [return: MarshalAs(UnmanagedType.Bool)]
            private static extern bool CopyFileEx(string lpExistingFileName, string lpNewFileName, CopyProgressRoutine lpProgressRoutine, IntPtr lpData, ref Int32 pbCancel, CopyFileFlags dwCopyFlags);

            private delegate CopyProgressResult CopyProgressRoutine(long TotalFileSize, long TotalBytesTransferred, long StreamSize, long StreamBytesTransferred, uint dwStreamNumber, CopyProgressCallbackReason dwCallbackReason,
                                                            IntPtr hSourceFile, IntPtr hDestinationFile, IntPtr lpData);

            private enum CopyProgressResult : uint
            {
                PROGRESS_CONTINUE = 0,
                PROGRESS_CANCEL = 1,
                PROGRESS_STOP = 2,
                PROGRESS_QUIET = 3
            }

            private enum CopyProgressCallbackReason : uint
            {
                CALLBACK_CHUNK_FINISHED = 0x00000000,
                CALLBACK_STREAM_SWITCH = 0x00000001
            }

            [Flags]
            private enum CopyFileFlags : uint
            {
                COPY_FILE_FAIL_IF_EXISTS = 0x00000001,
                COPY_FILE_NO_BUFFERING = 0x00001000,
                COPY_FILE_RESTARTABLE = 0x00000002,
                COPY_FILE_OPEN_SOURCE_FOR_WRITE = 0x00000004,
                COPY_FILE_ALLOW_DECRYPTED_DESTINATION = 0x00000008
            }

            private CopyProgressResult CopyProgressHandler(long total, long transferred, long streamSize, long streamByteTrans, uint dwStreamNumber,
                                                           CopyProgressCallbackReason reason, IntPtr hSourceFile, IntPtr hDestinationFile, IntPtr lpData)
            {
                if (reason == CopyProgressCallbackReason.CALLBACK_CHUNK_FINISHED)
                    OnProgressChanged((transferred / (double)total) * 100.0);

                if (transferred >= total)
                    OnCompleted();

                return CopyProgressResult.PROGRESS_CONTINUE;
            }

            #endregion

        }

        public static void DoubleBuffered(this DataGridView dgv, bool setting)
        {
            Type dgvType = dgv.GetType();
            PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dgv, setting, null);
        }

        public static void SetDoubleBuffer(Control ctl, bool DoubleBuffered)
        {
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.SetProperty,
                null, ctl, new object[] { DoubleBuffered });
        }

        public static string NumberToTextVN(decimal total)
        {
            try
            {
                string rs = "";
                total = Math.Round(total, 0);
                string[] ch = { "không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín" };
                string[] rch = { "lẻ", "mốt", "", "", "", "lăm" };
                string[] u = { "", "mươi", "trăm", "ngàn", "", "", "triệu", "", "", "tỷ", "", "", "ngàn", "", "", "triệu" };
                string nstr = total.ToString();

                int[] n = new int[nstr.Length];
                int len = n.Length;
                for (int i = 0; i < len; i++)
                {
                    n[len - 1 - i] = Convert.ToInt32(nstr.Substring(i, 1));
                }

                for (int i = len - 1; i >= 0; i--)
                {
                    if (i % 3 == 2)// số 0 ở hàng trăm
                    {
                        if (n[i] == 0 && n[i - 1] == 0 && n[i - 2] == 0) continue;//nếu cả 3 số là 0 thì bỏ qua không đọc
                    }
                    else if (i % 3 == 1) // số ở hàng chục
                    {
                        if (n[i] == 0)
                        {
                            if (n[i - 1] == 0) { continue; }// nếu hàng chục và hàng đơn vị đều là 0 thì bỏ qua.
                            else
                            {
                                rs += " " + rch[n[i]]; continue;// hàng chục là 0 thì bỏ qua, đọc số hàng đơn vị
                            }
                        }
                        if (n[i] == 1)//nếu số hàng chục là 1 thì đọc là mười
                        {
                            rs += " mười"; continue;
                        }
                    }
                    else if (i != len - 1)// số ở hàng đơn vị (không phải là số đầu tiên)
                    {
                        if (n[i] == 0)// số hàng đơn vị là 0 thì chỉ đọc đơn vị
                        {
                            if (i + 2 <= len - 1 && n[i + 2] == 0 && n[i + 1] == 0) continue;
                            rs += " " + (i % 3 == 0 ? u[i] : u[i % 3]);
                            continue;
                        }
                        if (n[i] == 1)// nếu là 1 thì tùy vào số hàng chục mà đọc: 0,1: một / còn lại: mốt
                        {
                            rs += " " + ((n[i + 1] == 1 || n[i + 1] == 0) ? ch[n[i]] : rch[n[i]]);
                            rs += " " + (i % 3 == 0 ? u[i] : u[i % 3]);
                            continue;
                        }
                        if (n[i] == 5) // cách đọc số 5
                        {
                            if (n[i + 1] != 0) //nếu số hàng chục khác 0 thì đọc số 5 là lăm
                            {
                                rs += " " + rch[n[i]];// đọc số 
                                rs += " " + (i % 3 == 0 ? u[i] : u[i % 3]);// đọc đơn vị
                                continue;
                            }
                        }
                    }

                    rs += (rs == "" ? " " : ", ") + ch[n[i]];// đọc số
                    rs += " " + (i % 3 == 0 ? u[i] : u[i % 3]);// đọc đơn vị
                }
                if (rs[rs.Length - 1] != ' ')
                    rs += " đồng";
                else
                    rs += "đồng";

                if (rs.Length > 2)
                {
                    string rs1 = rs.Substring(0, 2);
                    rs1 = rs1.ToUpper();
                    rs = rs.Substring(2);
                    rs = rs1 + rs;
                }
                return rs.Trim().Replace("lẻ,", "lẻ").Replace("mươi,", "mươi").Replace("trăm,", "trăm").Replace("mười,", "mười");
            }
            catch
            {
                return "";
            }

        }

        public static void ExtractFileResource(string resource_name, string file_name)
        {
            try
            {
                if (File.Exists(file_name))
                    File.Delete(file_name);

                if (!Directory.Exists(Path.GetDirectoryName(file_name)))
                    Directory.CreateDirectory(Path.GetDirectoryName(file_name));

                using (Stream sfile = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource_name))
                {
                    byte[] buf = new byte[sfile.Length];
                    sfile.Read(buf, 0, Convert.ToInt32(sfile.Length));

                    using (FileStream fs = File.Create(file_name))
                    {
                        fs.Write(buf, 0, Convert.ToInt32(sfile.Length));
                        fs.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Can't extract resource '{0}' to file '{1}': {2}", resource_name, file_name, ex.Message), ex);
            }
        }

        public static string GetIP()
        {
            string strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            return addr[addr.Length - 1].ToString();
        }

        public static string Fnc_Get_MAC_Address()
        {
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            String sMacAddress = string.Empty;
            foreach (NetworkInterface adapter in nics)
            {
                if (sMacAddress == String.Empty)// only return MAC Address from first card  
                {
                    //IPInterfaceProperties properties = adapter.GetIPProperties(); Line is not required
                    sMacAddress = adapter.GetPhysicalAddress().ToString();
                }
            }
            return sMacAddress;
        }

        public static void showUC(Control uc, Control pnlContainer)
        {
            pnlContainer.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            pnlContainer.Controls.Add(uc);
            uc.BringToFront();
        }

        public static void showUC(Control uc)
        {
            foreach (Control ctl in uc.Parent.Controls) ctl.Visible = ctl != uc;
        }

        public static void ShowFormInControl(Control ctl, Form frm)
        {
            if (ctl != null && frm != null)
            {
                frm.TopLevel = false;
                frm.FormBorderStyle = FormBorderStyle.None;
                frm.Dock = DockStyle.Fill;
                frm.Visible = true;
                ctl.Controls.Add(frm);
                frm.BringToFront();
            }
        }

        public static int CheckItemExistInDatagrid(string chkItem, DataGridView chkList, int chkCol)
        {
            int exist = 0;
            string curItem = "";

            if (chkItem.Length > 0)
            {
                foreach (DataGridViewRow row in chkList.Rows)
                {
                    curItem = row.Cells[chkCol].Value.ToString().ToLower();
                    if (curItem == chkItem.ToLower()) { exist += 1; }
                }
            }

            return exist;
        }

        public static int ReturnErrorCode()
        {
            int errNum = System.Runtime.InteropServices.Marshal.GetExceptionCode();
            return errNum;
        }

        public static void Fnc_Assign_Permission_To_Control(DataTable _p_Dta, int _action, string _func, Control _uc, Control _panel, string _p_Msg)
        {
            string enabled = "";
            bool _enabled = false;

            DataRow[] filteredRows = _p_Dta.Select("actionIDx=" + _action + " and funcResource='" + _func + "'");
            if (filteredRows != null)
            {
                foreach (DataRow row in filteredRows)
                {
                    enabled = row[3].ToString();
                }
            }
            else
            {
                enabled = "False";
            }

            _enabled = (enabled.ToLower() == "true" || enabled.ToLower() == "1") ? true : false;

            if (_enabled == true)
            {
                cls.showUC(_uc, _panel);
            }
            else
            {
                MessageBox.Show(_p_Msg, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static bool Fnc_Assign_Permission_To_Control(DataTable _p_Dta, int _action, string _func)
        {
            string enabled = "";
            bool _enabled = false;

            DataRow[] filteredRows = _p_Dta.Select("actionIDx=" + _action + " and funcResource='" + _func + "'");
            if (filteredRows != null)
            {
                foreach (DataRow row in filteredRows)
                {
                    enabled = row[3].ToString();
                }
            }
            else
            {
                enabled = "False";
            }

            _enabled = (enabled.ToLower() == "true") ? true : false;

            return _enabled;
        }

        public static void Fnc_Assign_Permission_To_Failure(string _p_Msg)
        {
            //string _p_Msg = "RESTRICTED AREA!!!\r\n\r\nYou don't have permission to access this function/area\r\nPlease inform to system administrator if this message is wrong.";
            MessageBox.Show(_p_Msg, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static void Fnc_Assign_Permission_To_Failure(int _action)
        {
            string type = "";
            switch (_action)
            {
                case 1:
                    type = "[Access is Denied]";
                    break;
                case 2:
                    type = "[Viewed is Denied]";
                    break;
                case 3:
                    type = "[Addnew is Denied]";
                    break;
                case 4:
                    type = "[Update is Denied]";
                    break;
                case 5:
                    type = "[Delete is Denied]";
                    break;
                default:
                    type = "[Access is Denied]";
                    break;
            }
            string _p_Msg = "RESTRICTED AREA!!!\r\n" + type + "\r\n\r\nYou don't have permission to access this function/area\r\nPlease inform to system administrator if this message is wrong.";
            MessageBox.Show(_p_Msg, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static string Fnc_Assign_Permission_To_Failure_Message(int _action)
        {
            string type = "";
            switch (_action)
            {
                case 1:
                    type = "[Access is Denied]";
                    break;
                case 2:
                    type = "[Viewed is Denied]";
                    break;
                case 3:
                    type = "[Addnew is Denied]";
                    break;
                case 4:
                    type = "[Update is Denied]";
                    break;
                case 5:
                    type = "[Delete is Denied]";
                    break;
                default:
                    type = "[Access is Denied]";
                    break;
            }
            string _p_Msg = "RESTRICTED AREA!!!\r\n" + type + "\r\n\r\nYou don't have permission to access this function/area\r\nPlease inform to system administrator if this message is wrong.";
            return _p_Msg;
        }

        public static void Fnc_Assign_Permission_To_Failure()
        {
            string _p_Msg = "RESTRICTED AREA!!!\r\n\r\nYou don't have permission to access this function/area\r\nPlease inform to system administrator if this message is wrong.";
            MessageBox.Show(_p_Msg, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static bool Fnc_Check_System_Update(string sql)
        {
            bool newest = true;
            int listCount = 0, rowCount = 0;
            string curVersion = Fnc_Program_Version();
            string newVersion = "", infVersion = "", datVersion = "", msgUPdate = "";
            //string sql = "V2o1_ERP_Configurations_System_Version_SelItem_V1o1_Addnew";

            DataSet ds = new DataSet();
            ds = cls.ExecuteDataSet(sql);
            listCount = ds.Tables.Count;
            rowCount = ds.Tables[0].Rows.Count;

            if (listCount > 0 && rowCount > 0)
            {
                newVersion = ds.Tables[0].Rows[0][0].ToString();
                infVersion = ds.Tables[0].Rows[0][1].ToString();
                datVersion = ds.Tables[0].Rows[0][2].ToString();
            }
            else
            {
                newVersion = Fnc_Program_Version();
                infVersion = "";
                datVersion = "";
            }

            msgUPdate = "UPDATE PROGRAM!!!\r\n\r\n";
            msgUPdate += "There is a new program version on server already\r\n";
            msgUPdate += "If you don't update, the program cannot running now.\r\n\r\n";
            msgUPdate += (infVersion.Length > 0) ? "UPDATE INFO:\r\n" + infVersion + "\r\n\r\n" : "";
            msgUPdate += "NOTE:\r\nThe program will be interupted until it is updated";

            if (curVersion != newVersion)
            {
                MessageBox.Show(msgUPdate, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Information);
                newest = false;
            }
            return newest;
        }

        public static bool Fnc_Check_System_Update()
        {
            bool newest = true;
            int listCount = 0, rowCount = 0, _curVer = 0, _newVer = 0;
            string curVersion = Fnc_Program_Version();
            string newVersion = "", infVersion = "", datVersion = "", msgUPdate = "";
            string curVer = "", newVer = "";
            string sql = "V2o1_ERP_Configurations_System_Version_SelItem_V1o1_Addnew";

            DataSet ds = new DataSet();
            ds = cls.ExecuteDataSet(sql);
            listCount = ds.Tables.Count;
            rowCount = ds.Tables[0].Rows.Count;

            if (listCount > 0 && rowCount > 0)
            {
                newVersion = ds.Tables[0].Rows[0][0].ToString();
                infVersion = ds.Tables[0].Rows[0][1].ToString();
                datVersion = ds.Tables[0].Rows[0][2].ToString();
            }
            else
            {
                newVersion = Fnc_Program_Version();
                infVersion = "";
                datVersion = "";
            }

            curVer = curVersion.Replace(".", "");
            newVer = newVersion.Replace(".", "");

            _curVer = (curVer != "" && curVer != null) ? Convert.ToInt32(curVer) : 0;
            _newVer = (newVer != "" && newVer != null) ? Convert.ToInt32(newVer) : 0;

            msgUPdate = "UPDATE PROGRAM!!!\r\n\r\n";
            msgUPdate += "There is a new program version on server already\r\n";
            msgUPdate += "If you don't update, the program cannot running now.\r\n\r\n";
            msgUPdate += (infVersion.Length > 0) ? "UPDATE INFO:\r\n" + infVersion + "\r\n\r\n" : "";
            msgUPdate += "NOTE:\r\nThe program will be interupted until it is updated";

            //if (curVersion != newVersion)
            if (_curVer != _newVer)
            {
                MessageBox.Show(msgUPdate, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Information);
                newest = false;
            }
            else
            {
                newest = true;
            }
            return newest;
        }

        public static string Fnc_Program_Version()
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            FileVersionInfo fileVersionInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
            string version = fileVersionInfo.ProductVersion.ToString();
            return version;
        }

        public static DataTable Fnc_Check_Permission_All_Action_List(int _level, string _type)
        {
            DataTable _p_Dta = null;
            if (_p_Dta.Rows.Count > 0) { _p_Dta = null; }
            string sql = "V2o1_SUMMARY_ADM_Permission_All_Action_List_Check_V1o1_SelItem_Addnew";

            SqlParameter[] sParams = new SqlParameter[2]; // Parameter count

            sParams[0] = new SqlParameter();
            sParams[0].SqlDbType = SqlDbType.Int;
            sParams[0].ParameterName = "@p_Level";
            sParams[0].Value = _level;

            sParams[1] = new SqlParameter();
            sParams[1].SqlDbType = SqlDbType.VarChar;
            sParams[1].ParameterName = "@p_Type";
            sParams[1].Value = _type;

            _p_Dta = cls.ExecuteDataTable(sql, sParams);
            return _p_Dta;
        }

        public static DataTable Fnc_Check_Permission_All_Action_List(int _idx, int _level, string _type)
        {
            DataTable _p_Dta = null;
            //if (_p_Dta.Rows.Count > 0) { _p_Dta = null; }
            string sql = "V2o1_SUMMARY_ADM_Permission_All_Action_List_Check_V1o2_SelItem_Addnew";

            SqlParameter[] sParams = new SqlParameter[3]; // Parameter count

            sParams[0] = new SqlParameter();
            sParams[0].SqlDbType = SqlDbType.Int;
            sParams[0].ParameterName = "@p_IDx";
            sParams[0].Value = _idx;

            sParams[1] = new SqlParameter();
            sParams[1].SqlDbType = SqlDbType.Int;
            sParams[1].ParameterName = "@p_Level";
            sParams[1].Value = _level;

            sParams[2] = new SqlParameter();
            sParams[2].SqlDbType = SqlDbType.VarChar;
            sParams[2].ParameterName = "@p_Type";
            sParams[2].Value = _type;

            _p_Dta = ExecuteDataTable(sql, sParams);
            return _p_Dta;
        }

        public static void Fnc_Textbox_Access_Number_Only(KeyPressEventArgs e, int _type)
        {
            switch (_type)
            {
                case 0:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '.') && (e.KeyChar != '-'))
                        e.Handled = true;
                    break;
                case 1:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)))
                        e.Handled = true;
                    break;
                case 2:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '.'))
                        e.Handled = true;
                    break;
                case 3:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '-'))
                        e.Handled = true;
                    break;
                default:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '.') && (e.KeyChar != '-'))
                        e.Handled = true;
                    break;
            }

            //// only allow one decimal point
            //if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            //    e.Handled = true;

            //// only allow minus sign at the beginning
            //if (e.KeyChar == '-' && (sender as TextBox).Text.Length > 0)
            //    e.Handled = true;

            ////if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            ////{
            ////    e.Handled = true;
            ////}

            ////// only allow one decimal point
            ////if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            ////{
            ////    e.Handled = true;
            ////}
        }

        public static void Fnc_Textbox_Access_Number_Only(object sender, KeyPressEventArgs e, int _type)
        {
            switch (_type)
            {
                case 0:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '.') && (e.KeyChar != '-'))
                        e.Handled = true;
                    break;
                case 1:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)))
                        e.Handled = true;
                    break;
                case 2:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '.'))
                        e.Handled = true;
                    break;
                case 3:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '-'))
                        e.Handled = true;
                    break;
                case 4:
                    // only allow one decimal point
                    if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
                    {
                        e.Handled = true;
                    }
                    break;
                default:
                    if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && (e.KeyChar != '.') && (e.KeyChar != '-'))
                        e.Handled = true;
                    break;
            }
        }

        public static void Fnc_Textbox_Access_Number_Point_Only(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.'))
            { e.Handled = true; }
            TextBox txtDecimal = sender as TextBox;
            if (e.KeyChar == '.' && txtDecimal.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        public static string ToSafeFileName(this string s)
        {
            return s
                .Replace("\\", "")
                .Replace("/", "")
                .Replace("\"", "")
                .Replace("*", "")
                .Replace(":", "")
                .Replace("?", "")
                .Replace("<", "")
                .Replace(">", "")
                .Replace("|", "");
        }

        public static void Fnc_Show_Message(string _msg_vi,int _msg_no)
        {
            switch (_msg_no)
            {
                case 0:
                    break;
                case 1:     //successful
                    MessageBox.Show(_msg_vi, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                case 2:     //connection error
                    MessageBox.Show(_msg_vi, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case 3:     // common error
                    MessageBox.Show(_msg_vi, cls.appName(), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
            }
        }

        public static string Fnc_Check_Integer_Number(decimal dec_Num)
        {
            string number = "";

            if (Math.Round(dec_Num, 2) == Math.Round(dec_Num))
            {
                number = String.Format("{0:0}", dec_Num);
            }
            else
            {
                number = String.Format("{0:0.0}", dec_Num);
            }

            return number;
        }

        public static string Fnc_Check_Integer_Number(double dou_Num)
        {
            string number = "";

            if (Math.Round(dou_Num, 2) == Math.Round(dou_Num))
            {
                number = String.Format("{0:0}", dou_Num);
            }
            else
            {
                number = String.Format("{0:0.0}", dou_Num);
            }

            return number;
        }

        public static DateTime GetNetworkTime()
        {
            //default Windows time server
            const string ntpServer = "time.windows.com";

            // NTP message size - 16 bytes of the digest (RFC 2030)
            var ntpData = new byte[48];

            //Setting the Leap Indicator, Version Number and Mode values
            ntpData[0] = 0x1B; //LI = 0 (no warning), VN = 3 (IPv4 only), Mode = 3 (Client Mode)

            var addresses = Dns.GetHostEntry(ntpServer).AddressList;

            //The UDP port number assigned to NTP is 123
            var ipEndPoint = new IPEndPoint(addresses[0], 123);
            //NTP uses UDP

            using (var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
            {
                socket.Connect(ipEndPoint);

                //Stops code hang if NTP is blocked
                socket.ReceiveTimeout = 3000;

                socket.Send(ntpData);
                socket.Receive(ntpData);
                socket.Close();
            }

            //Offset to get to the "Transmit Timestamp" field (time at which the reply 
            //departed the server for the client, in 64-bit timestamp format."
            const byte serverReplyTime = 40;

            //Get the seconds part
            ulong intPart = BitConverter.ToUInt32(ntpData, serverReplyTime);

            //Get the seconds fraction
            ulong fractPart = BitConverter.ToUInt32(ntpData, serverReplyTime + 4);

            //Convert From big-endian to little-endian
            intPart = SwapEndianness(intPart);
            fractPart = SwapEndianness(fractPart);

            var milliseconds = (intPart * 1000) + ((fractPart * 1000) / 0x100000000L);

            //**UTC** time
            var networkDateTime = (new DateTime(1900, 1, 1, 0, 0, 0, DateTimeKind.Utc)).AddMilliseconds((long)milliseconds);

            return networkDateTime.ToLocalTime();
        }

        // stackoverflow.com/a/3294698/162671
        static uint SwapEndianness(ulong x)
        {
            return (uint)(((x & 0x000000ff) << 24) +
                           ((x & 0x0000ff00) << 8) +
                           ((x & 0x00ff0000) >> 8) +
                           ((x & 0xff000000) >> 24));
        }

        public static void Fnc_Save_To_CSV(DataGridView dgv)
        {
            string filename = "";
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV (*.csv)|*.csv";
            sfd.FileName = "Output.csv";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                //MessageBox.Show("Data will be exported and you will be notified when it is ready.");
                if (File.Exists(filename))
                {
                    try
                    {
                        File.Delete(filename);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                    }
                }
                int columnCount = dgv.ColumnCount;
                string columnNames = "";
                string[] output = new string[dgv.RowCount + 1];
                for (int i = 0; i < columnCount; i++)
                {
                    columnNames += dgv.Columns[i].Name.ToString() + ",";
                }
                output[0] += columnNames;
                for (int i = 1; (i - 1) < dgv.RowCount; i++)
                {
                    for (int j = 0; j < columnCount; j++)
                    {
                        output[i] += dgv.Rows[i - 1].Cells[j].Value.ToString() + ",";
                    }
                }
                System.IO.File.WriteAllLines(sfd.FileName, output, System.Text.Encoding.UTF8);
                MessageBox.Show("Your file was generated and its ready for use.");
            }
        }

        public static void Fnc_Set_Tooltip(Button ctrl, string s_title, string s_tooltip)
        {
            ToolTip t = new ToolTip();
            t.ToolTipTitle = s_title;
            t.UseFading = true;
            t.UseAnimation = true;
            t.IsBalloon = true;
            t.ShowAlways = true;
            t.AutoPopDelay = 5000;
            t.InitialDelay = 1000;
            t.ReshowDelay = 500;
            t.SetToolTip(ctrl, s_tooltip);
        }

        public static void Fnc_Set_Tooltip(RadioButton ctrl, string s_title, string s_tooltip)
        {
            ToolTip t = new ToolTip();
            t.ToolTipTitle = s_title;
            t.UseFading = true;
            t.UseAnimation = true;
            t.IsBalloon = true;
            t.ShowAlways = true;
            t.AutoPopDelay = 5000;
            t.InitialDelay = 1000;
            t.ReshowDelay = 500;
            t.SetToolTip(ctrl, s_tooltip);
        }

        public static void Fnc_Set_Tooltip(CheckBox ctrl, string s_title, string s_tooltip)
        {
            ToolTip t = new ToolTip();
            t.ToolTipTitle = s_title;
            t.UseFading = true;
            t.UseAnimation = true;
            t.IsBalloon = true;
            t.ShowAlways = true;
            t.AutoPopDelay = 5000;
            t.InitialDelay = 1000;
            t.ReshowDelay = 500;
            t.SetToolTip(ctrl, s_tooltip);
        }

        public static void Fnc_Set_Tooltip(Label ctrl, string s_title, string s_tooltip)
        {
            ToolTip t = new ToolTip();
            t.ToolTipTitle = s_title;
            t.UseFading = true;
            t.UseAnimation = true;
            t.IsBalloon = true;
            t.ShowAlways = true;
            t.AutoPopDelay = 5000;
            t.InitialDelay = 1000;
            t.ReshowDelay = 500;
            t.SetToolTip(ctrl, s_tooltip);
        }

        public static void Fnc_Set_Tooltip(ComboBox ctrl, string s_title, string s_tooltip)
        {
            ToolTip t = new ToolTip();
            t.ToolTipTitle = s_title;
            t.UseFading = true;
            t.UseAnimation = true;
            t.IsBalloon = true;
            t.ShowAlways = true;
            t.AutoPopDelay = 5000;
            t.InitialDelay = 1000;
            t.ReshowDelay = 500;
            t.SetToolTip(ctrl, s_tooltip);
        }

        public static void Fnc_Set_Tooltip(LinkLabel ctrl, string s_title, string s_tooltip)
        {
            ToolTip t = new ToolTip();
            t.ToolTipTitle = s_title;
            t.UseFading = true;
            t.UseAnimation = true;
            t.IsBalloon = true;
            t.ShowAlways = true;
            t.AutoPopDelay = 5000;
            t.InitialDelay = 1000;
            t.ReshowDelay = 500;
            t.SetToolTip(ctrl, s_tooltip);
        }

        public static void Fnc_Set_Tooltip(TextBox ctrl, string s_title, string s_tooltip)
        {
            ToolTip t = new ToolTip();
            t.ToolTipTitle = s_title;
            t.UseFading = true;
            t.UseAnimation = true;
            t.IsBalloon = true;
            t.ShowAlways = true;
            t.AutoPopDelay = 5000;
            t.InitialDelay = 1000;
            t.ReshowDelay = 500;
            t.SetToolTip(ctrl, s_tooltip);
        }

        private static bool IsAdministrator()
        {
            var identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        public static bool Fnc_Compare_String(string str1, string str2)
        {
            bool same = false;

            same = (str1.Length == str2.Length) ? ((string.Compare(str1, str2, true) == 0) ? true : false) : false;

            return same;
        }

        public static bool Fnc_Compare_String_OrdinalIgnoreCase(string s1, string s2)
        {
            bool result = false;

            string normalized1 = Regex.Replace(s1, @"\s", "");
            string normalized2 = Regex.Replace(s2, @"\s", "");

            result = String.Equals(normalized1, normalized2, StringComparison.OrdinalIgnoreCase);


            return result;
        }

    }

    class IniFile   //// revision 11
    {
        string Path;
        string EXE = Assembly.GetExecutingAssembly().GetName().Name;

        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        static extern long WritePrivateProfileString(string Section, string Key, string Value, string FilePath);

        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        static extern int GetPrivateProfileString(string Section, string Key, string Default, StringBuilder RetVal, int Size, string FilePath);

        public IniFile(string IniPath = null)
        {
            Path = new FileInfo(IniPath ?? EXE + ".ini").FullName.ToString();
        }

        public string Read(string Key, string Section = null)
        {
            var RetVal = new StringBuilder(255);
            GetPrivateProfileString(Section ?? EXE, Key, "", RetVal, 255, Path);
            return RetVal.ToString();
        }

        public void Write(string Key, string Value, string Section = null)
        {
            WritePrivateProfileString(Section ?? EXE, Key, Value, Path);
        }

        public void DeleteKey(string Key, string Section = null)
        {
            Write(Key, null, Section ?? EXE);
        }

        public void DeleteSection(string Section = null)
        {
            Write(null, null, Section ?? EXE);
        }

        public bool KeyExists(string Key, string Section = null)
        {
            return Read(Key, Section).Length > 0;
        }
    }

    class msServer
    {
        //DB 접속 정보
        string _serverinfo = "";
        string _mdbinfo = "";

        //실행할 쿼리
        public string _query = "";
        public string _mdbquery = "";

        private SqlConnection _conn;
        private OleDbConnection _mdbconn;

        public DataSet _ds;
        public DataSet _mdbds;

        /// <summary>
        /// 생성자
        /// </summary>
        public msServer()
        {

        }

        public void SetDBInfo(string ip, string name)
        {
            // ini 파일의 DB ip로 세팅, DB 계정 정보는 보안상 프로그램 내에 하드코딩하자!
            //_serverinfo = "server=" + ip + "; database=" + name + "; user id=sait; password=it4118vcs";
            _serverinfo = "server=" + ip + "; database=" + name + "; user id=vnuser; password=dung@2016";
        }

        public void SetMdbInfo()
        {
            _mdbinfo = "Provider = Microsoft.JET.OLEDB.4.0;" + "Data Source = c:\\disconnected.mdb";
        }

        public string State()
        {
            string state;

            //this._conn = new SqlConnection(_serverinfo);

            if (this._conn.State == ConnectionState.Open)
            {
                state = "YES";
            }
            else
            {
                state = "NO";
            }

            return state;
        }

        public void Open()
        {
            try
            {
                this._conn = new SqlConnection(_serverinfo);
                this._conn.Open();
            }
            catch (IndexOutOfRangeException e)
            {
                int a = 0;
            }
            catch (Exception e)
            {
                int a = 0;
            }
        }

        public void MdbOpen()
        {
            try
            {
                this._mdbconn = new OleDbConnection(_mdbinfo);
                this._mdbconn.Open();
            }
            catch (IndexOutOfRangeException e)
            {
                int a = 0;
            }
            catch (Exception e)
            {
                int a = 0;
            }

        }

        public void Close()
        {
            try
            {
                this._conn.Close();
            }
            catch (IndexOutOfRangeException e)
            {
                int a = 0;
            }
            catch (Exception e)
            {
                int a = 0;
            }
        }

        public void MdbClose()
        {
            try
            {
                this._mdbconn.Close();
            }
            catch (IndexOutOfRangeException e)
            {
                int a = 0;
            }
            catch (Exception e)
            {
                int a = 0;
            }
        }

        /// <summary>
        /// select 쿼리 실행
        /// </summary>
        public bool execQuery()
        {
            try
            {
                //SqlDataAdapter 객체 생성
                SqlDataAdapter _sda = new SqlDataAdapter();

                _sda.SelectCommand = new SqlCommand(_query, _conn);

                _ds = new DataSet();    //DataSet 객체 생성

                _sda.Fill(_ds); //생성한 DataSet 객체에 Sda 객체의 데이터를 채우기

                if (_ds.Tables[0].Rows.Count > 0)
                    return true;
                else
                    return false;
            }
            catch (IndexOutOfRangeException e)
            {
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool MdbexecQuery()
        {
            try
            {
                OleDbDataAdapter _oda = new OleDbDataAdapter();

                _oda.SelectCommand = new OleDbCommand(_mdbquery, _mdbconn);

                _mdbds = new DataSet();

                _oda.Fill(_mdbds);

                if (_mdbds.Tables[0].Rows.Count > 0)
                    return true;
                else
                    return false;
            }
            catch (IndexOutOfRangeException e)
            {
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        /// <summary>
        /// insert, update 등의 쿼리 실행
        /// </summary>
        public bool execNonQuery()
        {
            try
            {
                SqlCommand _comm = new SqlCommand(_query, _conn);

                if (_comm.ExecuteNonQuery() == -1)  //성공
                {
                    return true;
                }
                else  //실패
                {
                    return false;
                }
            }
            catch (IndexOutOfRangeException e)
            {
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool MdbexecNonQuery()
        {
            try
            {
                OleDbCommand _mdbcomm = new OleDbCommand(_mdbquery, _mdbconn);

                if (_mdbcomm.ExecuteNonQuery() == -1)
                {
                    return true;
                }
                else  //실패
                {
                    return false;
                }
            }
            catch (IndexOutOfRangeException e)
            {
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }
    }

    public static class check
    {
        //Creating the extern function...
        [DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int Description, int ReservedValue);

        //Creating a function that uses the API function...
        public static bool IsConnectedToInternet()
        {
            int Desc;
            return InternetGetConnectedState(out Desc, 0);

        }

        public static bool IsConnectedToLAN(string ip)
        {
            Ping x = new Ping();
            PingReply reply = x.Send(IPAddress.Parse(ip));

            if (reply.Status == IPStatus.Success)
                return true;
            else
                return false;
        }

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("Local IP Address Not Found!");
        }
    }

    public static class Prompt
    {
        public static string ShowDialog(string text, string caption, string type)
        {
            Form prompt = new Form()
            {
                Width = 500,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };
            Label textLabel = new Label() { Left = 50, Top = 20, Text = text };
            TextBox textBox = new TextBox() { Left = 50, Top = 40, Width = 400 };
            Button confirmation = new Button() { Text = "CONFIRM", Left = 350, Width = 100, Top = 80, DialogResult = DialogResult.OK };
            switch (type)
            {
                case "1":
                case "pass":
                    textBox.UseSystemPasswordChar = true;
                    break;
                case "0":
                case "text":
                    break;
            }
            confirmation.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(textBox);
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.AcceptButton = confirmation;

            return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }
    }

    public static class netShare
    {
        /// <summary>
        /// Connects to the remote share
        /// </summary>
        /// <returns>Null if successful, otherwise error message.</returns>
        public static string ConnectToShare(string uri, string username, string password)
        {
            //Create netresource and point it at the share
            NETRESOURCE nr = new NETRESOURCE();
            nr.dwType = RESOURCETYPE_DISK;
            nr.lpRemoteName = uri;

            //Create the share
            int ret = WNetUseConnection(IntPtr.Zero, nr, password, username, 0, null, null, null);

            //Check for errors
            if (ret == NO_ERROR)
                return null;
            else
                return GetError(ret);
        }

        /// <summary>
        /// Remove the share from cache.
        /// </summary>
        /// <returns>Null if successful, otherwise error message.</returns>
        public static string DisconnectFromShare(string uri, bool force)
        {
            //remove the share
            int ret = WNetCancelConnection(uri, force);

            //Check for errors
            if (ret == NO_ERROR)
                return null;
            else
                return GetError(ret);
        }

        #region P/Invoke Stuff
        [DllImport("Mpr.dll")]
        private static extern int WNetUseConnection(
            IntPtr hwndOwner,
            NETRESOURCE lpNetResource,
            string lpPassword,
            string lpUserID,
            int dwFlags,
            string lpAccessName,
            string lpBufferSize,
            string lpResult
            );

        [DllImport("Mpr.dll")]
        private static extern int WNetCancelConnection(
            string lpName,
            bool fForce
            );

        [StructLayout(LayoutKind.Sequential)]
        private class NETRESOURCE
        {
            public int dwScope = 0;
            public int dwType = 0;
            public int dwDisplayType = 0;
            public int dwUsage = 0;
            public string lpLocalName = "";
            public string lpRemoteName = "";
            public string lpComment = "";
            public string lpProvider = "";
        }

        #region Consts
        const int RESOURCETYPE_DISK = 0x00000001;
        const int CONNECT_UPDATE_PROFILE = 0x00000001;
        #endregion

        #region Errors
        const int NO_ERROR = 0;

        const int ERROR_ACCESS_DENIED = 5;
        const int ERROR_ALREADY_ASSIGNED = 85;
        const int ERROR_BAD_DEVICE = 1200;
        const int ERROR_BAD_NET_NAME = 67;
        const int ERROR_BAD_PROVIDER = 1204;
        const int ERROR_CANCELLED = 1223;
        const int ERROR_EXTENDED_ERROR = 1208;
        const int ERROR_INVALID_ADDRESS = 487;
        const int ERROR_INVALID_PARAMETER = 87;
        const int ERROR_INVALID_PASSWORD = 1216;
        const int ERROR_MORE_DATA = 234;
        const int ERROR_NO_MORE_ITEMS = 259;
        const int ERROR_NO_NET_OR_BAD_PATH = 1203;
        const int ERROR_NO_NETWORK = 1222;
        const int ERROR_SESSION_CREDENTIAL_CONFLICT = 1219;

        const int ERROR_BAD_PROFILE = 1206;
        const int ERROR_CANNOT_OPEN_PROFILE = 1205;
        const int ERROR_DEVICE_IN_USE = 2404;
        const int ERROR_NOT_CONNECTED = 2250;
        const int ERROR_OPEN_FILES = 2401;

        private struct ErrorClass
        {
            public int num;
            public string message;
            public ErrorClass(int num, string message)
            {
                this.num = num;
                this.message = message;
            }
        }

        private static ErrorClass[] ERROR_LIST = new ErrorClass[] {
            new ErrorClass(ERROR_ACCESS_DENIED, "Error: Access Denied"),
            new ErrorClass(ERROR_ALREADY_ASSIGNED, "Error: Already Assigned"),
            new ErrorClass(ERROR_BAD_DEVICE, "Error: Bad Device"),
            new ErrorClass(ERROR_BAD_NET_NAME, "Error: Bad Net Name"),
            new ErrorClass(ERROR_BAD_PROVIDER, "Error: Bad Provider"),
            new ErrorClass(ERROR_CANCELLED, "Error: Cancelled"),
            new ErrorClass(ERROR_EXTENDED_ERROR, "Error: Extended Error"),
            new ErrorClass(ERROR_INVALID_ADDRESS, "Error: Invalid Address"),
            new ErrorClass(ERROR_INVALID_PARAMETER, "Error: Invalid Parameter"),
            new ErrorClass(ERROR_INVALID_PASSWORD, "Error: Invalid Password"),
            new ErrorClass(ERROR_MORE_DATA, "Error: More Data"),
            new ErrorClass(ERROR_NO_MORE_ITEMS, "Error: No More Items"),
            new ErrorClass(ERROR_NO_NET_OR_BAD_PATH, "Error: No Net Or Bad Path"),
            new ErrorClass(ERROR_NO_NETWORK, "Error: No Network"),
            new ErrorClass(ERROR_BAD_PROFILE, "Error: Bad Profile"),
            new ErrorClass(ERROR_CANNOT_OPEN_PROFILE, "Error: Cannot Open Profile"),
            new ErrorClass(ERROR_DEVICE_IN_USE, "Error: Device In Use"),
            new ErrorClass(ERROR_EXTENDED_ERROR, "Error: Extended Error"),
            new ErrorClass(ERROR_NOT_CONNECTED, "Error: Not Connected"),
            new ErrorClass(ERROR_OPEN_FILES, "Error: Open Files"),
            new ErrorClass(ERROR_SESSION_CREDENTIAL_CONFLICT, "Error: Credential Conflict"),
        };

        private static string GetError(int errNum)
        {
            foreach (ErrorClass er in ERROR_LIST)
            {
                if (er.num == errNum) return er.message;
            }
            return "Error: Unknown, " + errNum;
        }
        #endregion

        #endregion

    }

    class ClsPrint
    {
        #region Variables

        int iCellHeight = 0; //Used to get/set the datagridview cell height
        int iTotalWidth = 0; //
        int iRow = 0;//Used as counter
        bool bFirstPage = false; //Used to check whether we are printing first page
        bool bNewPage = false;// Used to check whether we are printing a new page
        int iHeaderHeight = 0; //Used for the header height
        StringFormat strFormat; //Used to format the grid rows.
        ArrayList arrColumnLefts = new ArrayList();//Used to save left coordinates of columns
        ArrayList arrColumnWidths = new ArrayList();//Used to save column widths
        private PrintDocument _printDocument = new PrintDocument();
        private DataGridView gw = new DataGridView();
        private string _ReportHeader;

        #endregion

        public ClsPrint(DataGridView gridview, string ReportHeader)
        {
            _printDocument.PrintPage += new PrintPageEventHandler(_printDocument_PrintPage);
            _printDocument.BeginPrint += new PrintEventHandler(_printDocument_BeginPrint);
            _printDocument.DefaultPageSettings.Landscape = true;

            Margins margins = new Margins(50, 50, 100, 50);
            _printDocument.DefaultPageSettings.Margins = margins;
            gw = gridview;
            _ReportHeader = ReportHeader;
        }

        public void PrintForm()
        {
            ////Open the print dialog
            //PrintDialog printDialog = new PrintDialog();
            //printDialog.Document = _printDocument;
            //printDialog.UseEXDialog = true;

            ////Get the document
            //if (DialogResult.OK == printDialog.ShowDialog())
            //{
            //    _printDocument.DocumentName = "Test Page Print";
            //    _printDocument.Print();
            //}

            //Open the print preview dialog
            PrintPreviewDialog objPPdialog = new PrintPreviewDialog();
            objPPdialog.Document = _printDocument;
            objPPdialog.ShowDialog();
        }

        private void _printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //try
            //{
            //Set the left margin
            int iLeftMargin = e.MarginBounds.Left;
            //Set the top margin
            int iTopMargin = e.MarginBounds.Top;
            //Whether more pages have to print or not
            bool bMorePagesToPrint = false;
            int iTmpWidth = 0;

            //For the first page to print set the cell width and header height
            if (bFirstPage)
            {
                foreach (DataGridViewColumn GridCol in gw.Columns)
                {
                    iTmpWidth = (int)(Math.Floor((double)((double)GridCol.Width /
                        (double)iTotalWidth * (double)iTotalWidth *
                        ((double)e.MarginBounds.Width / (double)iTotalWidth))));

                    iHeaderHeight = (int)(e.Graphics.MeasureString(GridCol.HeaderText,
                        GridCol.InheritedStyle.Font, iTmpWidth).Height) + 21;

                    // Save width and height of headers
                    arrColumnLefts.Add(iLeftMargin);
                    arrColumnWidths.Add(iTmpWidth);
                    iLeftMargin += iTmpWidth;
                }
            }
            //Loop till all the grid rows not get printed
            while (iRow <= gw.Rows.Count - 1)
            {
                DataGridViewRow GridRow = gw.Rows[iRow];
                //Set the cell height
                iCellHeight = GridRow.Height + 15;
                int iCount = 0;
                //Check whether the current page settings allows more rows to print
                if (iTopMargin + iCellHeight >= e.MarginBounds.Height + e.MarginBounds.Top)
                {
                    bNewPage = true;
                    bFirstPage = false;
                    bMorePagesToPrint = true;
                    break;
                }
                else
                {

                    if (bNewPage)
                    {
                        //Draw Header
                        e.Graphics.DrawString(_ReportHeader,
                            new Font(gw.Font, FontStyle.Bold),
                            Brushes.Black, e.MarginBounds.Left,
                            e.MarginBounds.Top - e.Graphics.MeasureString(_ReportHeader,
                            new Font(gw.Font, FontStyle.Bold),
                            e.MarginBounds.Width).Height - 13);

                        String strDate = "";
                        //Draw Date
                        e.Graphics.DrawString(strDate,
                            new Font(gw.Font, FontStyle.Bold), Brushes.Black,
                            e.MarginBounds.Left +
                            (e.MarginBounds.Width - e.Graphics.MeasureString(strDate,
                            new Font(gw.Font, FontStyle.Bold),
                            e.MarginBounds.Width).Width),
                            e.MarginBounds.Top - e.Graphics.MeasureString(_ReportHeader,
                            new Font(new Font(gw.Font, FontStyle.Bold),
                            FontStyle.Bold), e.MarginBounds.Width).Height - 13);

                        //Draw Columns                 
                        iTopMargin = e.MarginBounds.Top;
                        DataGridViewColumn[] _GridCol = new DataGridViewColumn[gw.Columns.Count];
                        int colcount = 0;
                        //Convert ltr to rtl
                        foreach (DataGridViewColumn GridCol in gw.Columns)
                        {
                            _GridCol[colcount++] = GridCol;
                        }
                        for (int i = (_GridCol.Count() - 1); i >= 0; i--)
                        {
                            e.Graphics.FillRectangle(new SolidBrush(Color.LightGray),
                                new Rectangle((int)arrColumnLefts[iCount], iTopMargin,
                                (int)arrColumnWidths[iCount], iHeaderHeight));

                            e.Graphics.DrawRectangle(Pens.Black,
                                new Rectangle((int)arrColumnLefts[iCount], iTopMargin,
                                (int)arrColumnWidths[iCount], iHeaderHeight));

                            e.Graphics.DrawString(_GridCol[i].HeaderText,
                                _GridCol[i].InheritedStyle.Font,
                                new SolidBrush(_GridCol[i].InheritedStyle.ForeColor),
                                new RectangleF((int)arrColumnLefts[iCount], iTopMargin,
                                (int)arrColumnWidths[iCount], iHeaderHeight), strFormat);
                            iCount++;
                        }
                        bNewPage = false;
                        iTopMargin += iHeaderHeight;
                    }
                    iCount = 0;
                    DataGridViewCell[] _GridCell = new DataGridViewCell[GridRow.Cells.Count];
                    int cellcount = 0;
                    //Convert ltr to rtl
                    foreach (DataGridViewCell Cel in GridRow.Cells)
                    {
                        _GridCell[cellcount++] = Cel;
                    }
                    //Draw Columns Contents                
                    for (int i = (_GridCell.Count() - 1); i >= 0; i--)
                    {
                        if (_GridCell[i].Value != null)
                        {
                            e.Graphics.DrawString(_GridCell[i].FormattedValue.ToString(),
                                _GridCell[i].InheritedStyle.Font,
                                new SolidBrush(_GridCell[i].InheritedStyle.ForeColor),
                                new RectangleF((int)arrColumnLefts[iCount],
                                (float)iTopMargin,
                                (int)arrColumnWidths[iCount], (float)iCellHeight),
                                strFormat);
                        }
                        //Drawing Cells Borders 
                        e.Graphics.DrawRectangle(Pens.Black,
                            new Rectangle((int)arrColumnLefts[iCount], iTopMargin,
                            (int)arrColumnWidths[iCount], iCellHeight));
                        iCount++;
                    }
                }
                iRow++;
                iTopMargin += iCellHeight;
            }
            //If more lines exist, print another page.
            if (bMorePagesToPrint)
                e.HasMorePages = true;
            else
                e.HasMorePages = false;
            //}
            //catch (Exception exc)
            //{
            //    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK,
            //       MessageBoxIcon.Error);
            //}
        }

        private void _printDocument_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            try
            {
                strFormat = new StringFormat();
                strFormat.Alignment = StringAlignment.Center;
                strFormat.LineAlignment = StringAlignment.Center;
                strFormat.Trimming = StringTrimming.EllipsisCharacter;

                arrColumnLefts.Clear();
                arrColumnWidths.Clear();
                iCellHeight = 0;
                iRow = 0;
                bFirstPage = true;
                bNewPage = true;

                // Calculating Total Widths
                iTotalWidth = 0;
                foreach (DataGridViewColumn dgvGridCol in gw.Columns)
                {
                    iTotalWidth += dgvGridCol.Width;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }

    public static class RawPrinterHelper
    {
        // Structure and API declarions:
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public class DOCINFOA
        {
            [MarshalAs(UnmanagedType.LPStr)] public string pDocName;
            [MarshalAs(UnmanagedType.LPStr)] public string pOutputFile;
            [MarshalAs(UnmanagedType.LPStr)] public string pDataType;
        }
        [DllImport("winspool.Drv", EntryPoint = "OpenPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);

        [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool ClosePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);

        [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndDocPrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartPagePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndPagePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);

        // SendBytesToPrinter()
        // When the function is given a printer name and an unmanaged array
        // of bytes, the function sends those bytes to the print queue.
        // Returns true on success, false on failure.
        public static bool SendBytesToPrinter(string szPrinterName, IntPtr pBytes, Int32 dwCount)
        {
            Int32 dwError = 0, dwWritten = 0;
            IntPtr hPrinter = new IntPtr(0);
            DOCINFOA di = new DOCINFOA();
            bool bSuccess = false; // Assume failure unless you specifically succeed.

            di.pDocName = "My C#.NET RAW Document";
            di.pDataType = "RAW";

            // Open the printer.
            if (OpenPrinter(szPrinterName.Normalize(), out hPrinter, IntPtr.Zero))
            {
                // Start a document.
                if (StartDocPrinter(hPrinter, 1, di))
                {
                    // Start a page.
                    if (StartPagePrinter(hPrinter))
                    {
                        // Write your bytes.
                        bSuccess = WritePrinter(hPrinter, pBytes, dwCount, out dwWritten);
                        EndPagePrinter(hPrinter);
                    }
                    EndDocPrinter(hPrinter);
                }
                ClosePrinter(hPrinter);
            }
            // If you did not succeed, GetLastError may give more information
            // about why not.
            if (bSuccess == false)
            {
                dwError = Marshal.GetLastWin32Error();
            }
            return bSuccess;
        }

        public static bool SendFileToPrinter(string szPrinterName, string szFileName)
        {
            // Open the file.
            FileStream fs = new FileStream(szFileName, FileMode.Open);
            // Create a BinaryReader on the file.
            BinaryReader br = new BinaryReader(fs);
            // Dim an array of bytes big enough to hold the file's contents.
            Byte[] bytes = new Byte[fs.Length];
            bool bSuccess = false;
            // Your unmanaged pointer.
            IntPtr pUnmanagedBytes = new IntPtr(0);
            int nLength;

            nLength = Convert.ToInt32(fs.Length);
            // Read the contents of the file into the array.
            bytes = br.ReadBytes(nLength);
            // Allocate some unmanaged memory for those bytes.
            pUnmanagedBytes = Marshal.AllocCoTaskMem(nLength);
            // Copy the managed byte array into the unmanaged array.
            Marshal.Copy(bytes, 0, pUnmanagedBytes, nLength);
            // Send the unmanaged bytes to the printer.
            bSuccess = SendBytesToPrinter(szPrinterName, pUnmanagedBytes, nLength);
            // Free the unmanaged memory that you allocated earlier.
            Marshal.FreeCoTaskMem(pUnmanagedBytes);
            return bSuccess;
        }
        public static bool SendStringToPrinter(string szPrinterName, string szString)
        {
            IntPtr pBytes;
            Int32 dwCount;
            // How many characters are in the string?
            dwCount = szString.Length;
            // Assume that the printer is expecting ANSI text, and then convert
            // the string to ANSI text.
            pBytes = Marshal.StringToCoTaskMemAnsi(szString);
            // Send the converted ANSI string to the printer.
            SendBytesToPrinter(szPrinterName, pBytes, dwCount);
            Marshal.FreeCoTaskMem(pBytes);
            return true;
        }
    }

    public static class NetworkShare
    {
        /// <summary>
        /// Connects to the remote share
        /// </summary>
        /// <returns>Null if successful, otherwise error message.</returns>
        public static string ConnectToShare(string uri, string username, string password)
        {
            //Create netresource and point it at the share
            NETRESOURCE nr = new NETRESOURCE();
            nr.dwType = RESOURCETYPE_DISK;
            nr.lpRemoteName = uri;

            //Create the share
            int ret = WNetUseConnection(IntPtr.Zero, nr, password, username, 0, null, null, null);

            //Check for errors
            if (ret == NO_ERROR)
                return null;
            else
                return GetError(ret);
        }

        /// <summary>
        /// Remove the share from cache.
        /// </summary>
        /// <returns>Null if successful, otherwise error message.</returns>
        public static string DisconnectFromShare(string uri, bool force)
        {
            //remove the share
            int ret = WNetCancelConnection(uri, force);

            //Check for errors
            if (ret == NO_ERROR)
                return null;
            else
                return GetError(ret);
        }

        #region P/Invoke Stuff
        [DllImport("Mpr.dll")]
        private static extern int WNetUseConnection(
            IntPtr hwndOwner,
            NETRESOURCE lpNetResource,
            string lpPassword,
            string lpUserID,
            int dwFlags,
            string lpAccessName,
            string lpBufferSize,
            string lpResult
            );

        [DllImport("Mpr.dll")]
        private static extern int WNetCancelConnection(
            string lpName,
            bool fForce
            );

        [StructLayout(LayoutKind.Sequential)]
        private class NETRESOURCE
        {
            public int dwScope = 0;
            public int dwType = 0;
            public int dwDisplayType = 0;
            public int dwUsage = 0;
            public string lpLocalName = "";
            public string lpRemoteName = "";
            public string lpComment = "";
            public string lpProvider = "";
        }

        #region Consts
        const int RESOURCETYPE_DISK = 0x00000001;
        const int CONNECT_UPDATE_PROFILE = 0x00000001;
        #endregion

        #region Errors
        const int NO_ERROR = 0;

        const int ERROR_ACCESS_DENIED = 5;
        const int ERROR_ALREADY_ASSIGNED = 85;
        const int ERROR_BAD_DEVICE = 1200;
        const int ERROR_BAD_NET_NAME = 67;
        const int ERROR_BAD_PROVIDER = 1204;
        const int ERROR_CANCELLED = 1223;
        const int ERROR_EXTENDED_ERROR = 1208;
        const int ERROR_INVALID_ADDRESS = 487;
        const int ERROR_INVALID_PARAMETER = 87;
        const int ERROR_INVALID_PASSWORD = 1216;
        const int ERROR_MORE_DATA = 234;
        const int ERROR_NO_MORE_ITEMS = 259;
        const int ERROR_NO_NET_OR_BAD_PATH = 1203;
        const int ERROR_NO_NETWORK = 1222;
        const int ERROR_SESSION_CREDENTIAL_CONFLICT = 1219;

        const int ERROR_BAD_PROFILE = 1206;
        const int ERROR_CANNOT_OPEN_PROFILE = 1205;
        const int ERROR_DEVICE_IN_USE = 2404;
        const int ERROR_NOT_CONNECTED = 2250;
        const int ERROR_OPEN_FILES = 2401;

        private struct ErrorClass
        {
            public int num;
            public string message;
            public ErrorClass(int num, string message)
            {
                this.num = num;
                this.message = message;
            }
        }

        private static ErrorClass[] ERROR_LIST = new ErrorClass[] {
        new ErrorClass(ERROR_ACCESS_DENIED, "Error: Access Denied"),
        new ErrorClass(ERROR_ALREADY_ASSIGNED, "Error: Already Assigned"),
        new ErrorClass(ERROR_BAD_DEVICE, "Error: Bad Device"),
        new ErrorClass(ERROR_BAD_NET_NAME, "Error: Bad Net Name"),
        new ErrorClass(ERROR_BAD_PROVIDER, "Error: Bad Provider"),
        new ErrorClass(ERROR_CANCELLED, "Error: Cancelled"),
        new ErrorClass(ERROR_EXTENDED_ERROR, "Error: Extended Error"),
        new ErrorClass(ERROR_INVALID_ADDRESS, "Error: Invalid Address"),
        new ErrorClass(ERROR_INVALID_PARAMETER, "Error: Invalid Parameter"),
        new ErrorClass(ERROR_INVALID_PASSWORD, "Error: Invalid Password"),
        new ErrorClass(ERROR_MORE_DATA, "Error: More Data"),
        new ErrorClass(ERROR_NO_MORE_ITEMS, "Error: No More Items"),
        new ErrorClass(ERROR_NO_NET_OR_BAD_PATH, "Error: No Net Or Bad Path"),
        new ErrorClass(ERROR_NO_NETWORK, "Error: No Network"),
        new ErrorClass(ERROR_BAD_PROFILE, "Error: Bad Profile"),
        new ErrorClass(ERROR_CANNOT_OPEN_PROFILE, "Error: Cannot Open Profile"),
        new ErrorClass(ERROR_DEVICE_IN_USE, "Error: Device In Use"),
        new ErrorClass(ERROR_EXTENDED_ERROR, "Error: Extended Error"),
        new ErrorClass(ERROR_NOT_CONNECTED, "Error: Not Connected"),
        new ErrorClass(ERROR_OPEN_FILES, "Error: Open Files"),
        new ErrorClass(ERROR_SESSION_CREDENTIAL_CONFLICT, "Error: Credential Conflict"),
    };

        private static string GetError(int errNum)
        {
            foreach (ErrorClass er in ERROR_LIST)
            {
                if (er.num == errNum) return er.message;
            }
            return "Error: Unknown, " + errNum;
        }
        #endregion

        #endregion
    }

    public class CommunicationManager
    {
        #region Manager Enums
        /// <summary>
        /// enumeration to hold our transmission types
        /// </summary>
        public enum TransmissionType { Text, Hex }

        /// <summary>
        /// enumeration to hold our message types
        /// </summary>
        public enum MessageType { Incoming, Outgoing, Normal, Warning, Error };
        #endregion

        #region Manager Variables
        //property variables
        public static string _baudRate = string.Empty;
        public static string _parity = string.Empty;
        public static string _stopBits = string.Empty;
        public static string _dataBits = string.Empty;
        public static string _portName = string.Empty;
        public static TransmissionType _transType;
        public static RichTextBox _displayWindow;
        //global manager variables
        public static Color[] MessageColor = { Color.Blue, Color.Green, Color.Black, Color.Orange, Color.Red };
        public static SerialPort comPort = new SerialPort();
        #endregion

        #region Manager Properties
        /// <summary>
        /// Property to hold the BaudRate
        /// of our manager class
        /// </summary>
        public string BaudRate
        {
            get { return _baudRate; }
            set { _baudRate = value; }
        }

        /// <summary>
        /// property to hold the Parity
        /// of our manager class
        /// </summary>
        public string Parity
        {
            get { return _parity; }
            set { _parity = value; }
        }

        /// <summary>
        /// property to hold the StopBits
        /// of our manager class
        /// </summary>
        public string StopBits
        {
            get { return _stopBits; }
            set { _stopBits = value; }
        }

        /// <summary>
        /// property to hold the DataBits
        /// of our manager class
        /// </summary>
        public string DataBits
        {
            get { return _dataBits; }
            set { _dataBits = value; }
        }

        /// <summary>
        /// property to hold the PortName
        /// of our manager class
        /// </summary>
        public string PortName
        {
            get { return _portName; }
            set { _portName = value; }
        }

        /// <summary>
        /// property to hold our TransmissionType
        /// of our manager class
        /// </summary>
        public TransmissionType CurrentTransmissionType
        {
            get { return _transType; }
            set { _transType = value; }
        }

        /// <summary>
        /// property to hold our display window
        /// value
        /// </summary>
        public RichTextBox DisplayWindow
        {
            get { return _displayWindow; }
            set { _displayWindow = value; }
        }
        #endregion

        #region Manager Constructors
        /// <summary>
        /// Constructor to set the properties of our Manager Class
        /// </summary>
        /// <param name="baud">Desired BaudRate</param>
        /// <param name="par">Desired Parity</param>
        /// <param name="sBits">Desired StopBits</param>
        /// <param name="dBits">Desired DataBits</param>
        /// <param name="name">Desired PortName</param>
        public CommunicationManager(string baud, string par, string sBits, string dBits, string name, RichTextBox rtb)
        {
            _baudRate = baud;
            _parity = par;
            _stopBits = sBits;
            _dataBits = dBits;
            _portName = name;
            _displayWindow = rtb;
            //now add an event handler
            comPort.DataReceived += new SerialDataReceivedEventHandler(comPort_DataReceived);
        }

        /// <summary>
        /// Comstructor to set the properties of our
        /// serial port communicator to nothing
        /// </summary>
        public CommunicationManager()
        {
            _baudRate = string.Empty;
            _parity = string.Empty;
            _stopBits = string.Empty;
            _dataBits = string.Empty;
            _portName = "COM1";
            _displayWindow = null;
            //add event handler
            comPort.DataReceived += new SerialDataReceivedEventHandler(comPort_DataReceived);
        }
        #endregion

        #region WriteData
        public void WriteData(string msg)
        {
            switch (CurrentTransmissionType)
            {
                case TransmissionType.Text:
                    //first make sure the port is open
                    //if its not open then open it
                    if (!(comPort.IsOpen == true)) comPort.Open();
                    //send the message to the port
                    comPort.Write(msg);
                    //display the message
                    DisplayData(MessageType.Outgoing, msg + "\n");
                    break;
                case TransmissionType.Hex:
                    try
                    {
                        //convert the message to byte array
                        byte[] newMsg = HexToByte(msg);
                        //send the message to the port
                        comPort.Write(newMsg, 0, newMsg.Length);
                        //convert back to hex and display
                        DisplayData(MessageType.Outgoing, ByteToHex(newMsg) + "\n");
                    }
                    catch (FormatException ex)
                    {
                        //display error message
                        DisplayData(MessageType.Error, ex.Message);
                    }
                    finally
                    {
                        _displayWindow.SelectAll();
                    }
                    break;
                default:
                    //first make sure the port is open
                    //if its not open then open it
                    if (!(comPort.IsOpen == true)) comPort.Open();
                    //send the message to the port
                    comPort.Write(msg);
                    //display the message
                    DisplayData(MessageType.Outgoing, msg + "\n");
                    break;
                    break;
            }
        }
        #endregion

        #region HexToByte
        /// <summary>
        /// method to convert hex string into a byte array
        /// </summary>
        /// <param name="msg">string to convert</param>
        /// <returns>a byte array</returns>
        public static byte[] HexToByte(string msg)
        {
            //remove any spaces from the string
            msg = msg.Replace(" ", "");
            //create a byte array the length of the
            //divided by 2 (Hex is 2 characters in length)
            byte[] comBuffer = new byte[msg.Length / 2];
            //loop through the length of the provided string
            for (int i = 0; i < msg.Length; i += 2)
                //convert each set of 2 characters to a byte
                //and add to the array
                comBuffer[i / 2] = (byte)Convert.ToByte(msg.Substring(i, 2), 16);
            //return the array
            return comBuffer;
        }
        #endregion

        #region ByteToHex
        /// <summary>
        /// method to convert a byte array into a hex string
        /// </summary>
        /// <param name="comByte">byte array to convert</param>
        /// <returns>a hex string</returns>
        public static string ByteToHex(byte[] comByte)
        {
            //create a new StringBuilder object
            StringBuilder builder = new StringBuilder(comByte.Length * 3);
            //loop through each byte in the array
            foreach (byte data in comByte)
                //convert the byte to a string and add to the stringbuilder
                builder.Append(Convert.ToString(data, 16).PadLeft(2, '0').PadRight(3, ' '));
            //return the converted value
            return builder.ToString().ToUpper();
        }
        #endregion

        #region DisplayData
        /// <summary>
        /// method to display the data to & from the port
        /// on the screen
        /// </summary>
        /// <param name="type">MessageType of the message</param>
        /// <param name="msg">Message to display</param>
        [STAThread]
        public static void DisplayData(MessageType type, string msg)
        {
            _displayWindow.Invoke(new EventHandler(delegate
            {
                _displayWindow.SelectedText = string.Empty;
                _displayWindow.SelectionFont = new Font(_displayWindow.SelectionFont, FontStyle.Bold);
                _displayWindow.SelectionColor = MessageColor[(int)type];
                _displayWindow.AppendText(msg);
                _displayWindow.ScrollToCaret();
            }));
        }
        #endregion

        #region OpenPort
        public bool OpenPort()
        {
            try
            {
                //first check if the port is already open
                //if its open then close it
                if (comPort.IsOpen == true) comPort.Close();

                //set the properties of our SerialPort Object
                comPort.BaudRate = int.Parse(_baudRate);    //BaudRate
                comPort.DataBits = int.Parse(_dataBits);    //DataBits
                comPort.StopBits = (StopBits)Enum.Parse(typeof(StopBits), _stopBits);    //StopBits
                comPort.Parity = (Parity)Enum.Parse(typeof(Parity), _parity);    //Parity
                comPort.PortName = _portName;   //PortName
                //now open the port
                comPort.Open();
                //display message
                DisplayData(MessageType.Normal, "Port opened at " + DateTime.Now + "\n");
                //return true
                return true;
            }
            catch (Exception ex)
            {
                DisplayData(MessageType.Error, ex.Message);
                return false;
            }
        }
        #endregion

        #region SetParityValues
        public void SetParityValues(object obj)
        {
            foreach (string str in Enum.GetNames(typeof(Parity)))
            {
                ((ComboBox)obj).Items.Add(str);
            }
        }
        #endregion

        #region SetStopBitValues
        public void SetStopBitValues(object obj)
        {
            foreach (string str in Enum.GetNames(typeof(StopBits)))
            {
                ((ComboBox)obj).Items.Add(str);
            }
        }
        #endregion

        #region SetPortNameValues
        public void SetPortNameValues(object obj)
        {

            foreach (string str in SerialPort.GetPortNames())
            {
                ((ComboBox)obj).Items.Add(str);
            }
        }
        #endregion

        #region comPort_DataReceived
        /// <summary>
        /// method that will be called when theres data waiting in the buffer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void comPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //determine the mode the user selected (binary/string)
            switch (CurrentTransmissionType)
            {
                //user chose string
                case TransmissionType.Text:
                    //read data waiting in the buffer
                    string msg = comPort.ReadExisting();
                    //display the data to the user
                    DisplayData(MessageType.Incoming, msg + "\n");
                    break;
                //user chose binary
                case TransmissionType.Hex:
                    //retrieve number of bytes in the buffer
                    int bytes = comPort.BytesToRead;
                    //create a byte array to hold the awaiting data
                    byte[] comBuffer = new byte[bytes];
                    //read the data and store it
                    comPort.Read(comBuffer, 0, bytes);
                    //display the data to the user
                    DisplayData(MessageType.Incoming, ByteToHex(comBuffer) + "\n");
                    break;
                default:
                    //read data waiting in the buffer
                    string str = comPort.ReadExisting();
                    //display the data to the user
                    DisplayData(MessageType.Incoming, str + "\n");
                    break;
            }
        }
        #endregion
    }

    public class HexDecEncoding
    {
        public static string ToHexString(string str)
        {
            var sb = new StringBuilder();

            var bytes = Encoding.Unicode.GetBytes(str);
            foreach (var t in bytes)
            {
                sb.Append(t.ToString("X2"));
            }

            return sb.ToString(); // returns: "48656C6C6F20776F726C64" for "Hello world"
        }

        public static string FromHexString(string hexString)
        {
            var bytes = new byte[hexString.Length / 2];
            for (var i = 0; i < bytes.Length; i++)
            {
                bytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            }

            return Encoding.Unicode.GetString(bytes); // returns: "Hello world" for "48656C6C6F20776F726C64"
        }
    }

    //public delegate void ProgressChangeDelegate(double Persentage, ref bool Cancel);
    //public delegate void Completedelegate();

    //public static class CustomFileCopier
    //{
    //    public static CustomFileCopier(string Source, string Dest)
    //    {
    //        SourceFilePath = Source;
    //        DestFilePath = Dest;

    //        OnProgressChanged += delegate { };
    //        OnComplete += delegate { };
    //    }

    //    public static void Copy()
    //    {
    //        byte[] buffer = new byte[1024 * 1024]; // 1MB buffer
    //        bool cancelFlag = false;

    //        using (FileStream source = new FileStream(SourceFilePath, FileMode.Open, FileAccess.Read))
    //        {
    //            long fileLength = source.Length;
    //            using (FileStream dest = new FileStream(DestFilePath, FileMode.CreateNew, FileAccess.Write))
    //            {
    //                long totalBytes = 0;
    //                int currentBlockSize = 0;

    //                while ((currentBlockSize = source.Read(buffer, 0, buffer.Length)) > 0)
    //                {
    //                    totalBytes += currentBlockSize;
    //                    double persentage = (double)totalBytes * 100.0 / fileLength;

    //                    dest.Write(buffer, 0, currentBlockSize);

    //                    cancelFlag = false;
    //                    OnProgressChanged(persentage, ref cancelFlag);

    //                    if (cancelFlag == true)
    //                    {
    //                        // Delete dest file here
    //                        break;
    //                    }
    //                }
    //            }
    //        }

    //        OnComplete();
    //    }

    //    public static string SourceFilePath { get; set; }
    //    public static string DestFilePath { get; set; }

    //    public static event ProgressChangeDelegate OnProgressChanged;
    //    public static event Completedelegate OnComplete;
    //}

    //public class ClsPrint
    //{
    //    #region Variables

    //    int iCellHeight = 0; //Used to get/set the datagridview cell height
    //    int iTotalWidth = 0; //
    //    int iRow = 0;//Used as counter
    //    bool bFirstPage = false; //Used to check whether we are printing first page
    //    bool bNewPage = false;// Used to check whether we are printing a new page
    //    int iHeaderHeight = 0; //Used for the header height
    //    StringFormat strFormat; //Used to format the grid rows.
    //    ArrayList arrColumnLefts = new ArrayList();//Used to save left coordinates of columns
    //    ArrayList arrColumnWidths = new ArrayList();//Used to save column widths
    //    private PrintDocument _printDocument = new PrintDocument();
    //    private DataGridView gw = new DataGridView();
    //    private string _ReportHeader;

    //    #endregion

    //    public ClsPrint(DataGridView gridview, string ReportHeader)
    //    {
    //        _printDocument.PrintPage += new PrintPageEventHandler(_printDocument_PrintPage);
    //        _printDocument.BeginPrint += new PrintEventHandler(_printDocument_BeginPrint);
    //        gw = gridview;
    //        _ReportHeader = ReportHeader;
    //    }

    //    public void PrintForm()
    //    {
    //        ////Open the print dialog
    //        //PrintDialog printDialog = new PrintDialog();
    //        //printDialog.Document = _printDocument;
    //        //printDialog.UseEXDialog = true;

    //        ////Get the document
    //        //if (DialogResult.OK == printDialog.ShowDialog())
    //        //{
    //        //    _printDocument.DocumentName = "Test Page Print";
    //        //    _printDocument.Print();
    //        //}

    //        //Open the print preview dialog
    //        PrintPreviewDialog objPPdialog = new PrintPreviewDialog();
    //        objPPdialog.Document = _printDocument;
    //        objPPdialog.ShowDialog();
    //    }

    //    private void _printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
    //    {
    //        //try
    //        //{
    //        //Set the left margin
    //        int iLeftMargin = e.MarginBounds.Left;
    //        //Set the top margin
    //        int iTopMargin = e.MarginBounds.Top;
    //        //Whether more pages have to print or not
    //        bool bMorePagesToPrint = false;
    //        int iTmpWidth = 0;

    //        //For the first page to print set the cell width and header height
    //        if (bFirstPage)
    //        {
    //            foreach (DataGridViewColumn GridCol in gw.Columns)
    //            {
    //                iTmpWidth = (int)(Math.Floor((double)((double)GridCol.Width /
    //                    (double)iTotalWidth * (double)iTotalWidth *
    //                    ((double)e.MarginBounds.Width / (double)iTotalWidth))));

    //                iHeaderHeight = (int)(e.Graphics.MeasureString(GridCol.HeaderText,
    //                    GridCol.InheritedStyle.Font, iTmpWidth).Height) + 11;

    //                // Save width and height of headers
    //                arrColumnLefts.Add(iLeftMargin);
    //                arrColumnWidths.Add(iTmpWidth);
    //                iLeftMargin += iTmpWidth;
    //            }
    //        }
    //        //Loop till all the grid rows not get printed
    //        while (iRow <= gw.Rows.Count - 1)
    //        {
    //            DataGridViewRow GridRow = gw.Rows[iRow];
    //            //Set the cell height
    //            iCellHeight = GridRow.Height + 5;
    //            int iCount = 0;
    //            //Check whether the current page settings allows more rows to print
    //            if (iTopMargin + iCellHeight >= e.MarginBounds.Height + e.MarginBounds.Top)
    //            {
    //                bNewPage = true;
    //                bFirstPage = false;
    //                bMorePagesToPrint = true;
    //                break;
    //            }
    //            else
    //            {

    //                if (bNewPage)
    //                {
    //                    //Draw Header
    //                    e.Graphics.DrawString(_ReportHeader,
    //                        new Font(gw.Font, FontStyle.Bold),
    //                        Brushes.Black, e.MarginBounds.Left,
    //                        e.MarginBounds.Top - e.Graphics.MeasureString(_ReportHeader,
    //                        new Font(gw.Font, FontStyle.Bold),
    //                        e.MarginBounds.Width).Height - 13);

    //                    String strDate = "";
    //                    //Draw Date
    //                    e.Graphics.DrawString(strDate,
    //                        new Font(gw.Font, FontStyle.Bold), Brushes.Black,
    //                        e.MarginBounds.Left +
    //                        (e.MarginBounds.Width - e.Graphics.MeasureString(strDate,
    //                        new Font(gw.Font, FontStyle.Bold),
    //                        e.MarginBounds.Width).Width),
    //                        e.MarginBounds.Top - e.Graphics.MeasureString(_ReportHeader,
    //                        new Font(new Font(gw.Font, FontStyle.Bold),
    //                        FontStyle.Bold), e.MarginBounds.Width).Height - 13);

    //                    //Draw Columns                 
    //                    iTopMargin = e.MarginBounds.Top;
    //                    DataGridViewColumn[] _GridCol = new DataGridViewColumn[gw.Columns.Count];
    //                    int colcount = 0;
    //                    //Convert ltr to rtl
    //                    foreach (DataGridViewColumn GridCol in gw.Columns)
    //                    {
    //                        _GridCol[colcount++] = GridCol;
    //                    }
    //                    //for (int i = (_GridCol.Count() - 1); i >= 0; i--)
    //                    for (int i = 0; i < (_GridCol.Count() - 1); i++)
    //                    {
    //                        e.Graphics.FillRectangle(new SolidBrush(Color.LightGray),
    //                        new Rectangle((int)arrColumnLefts[iCount], iTopMargin,
    //                        (int)arrColumnWidths[iCount], iHeaderHeight));

    //                        e.Graphics.DrawRectangle(Pens.Black,
    //                            new Rectangle((int)arrColumnLefts[iCount], iTopMargin,
    //                            (int)arrColumnWidths[iCount], iHeaderHeight));

    //                        e.Graphics.DrawString(_GridCol[i].HeaderText,
    //                            _GridCol[i].InheritedStyle.Font,
    //                            new SolidBrush(_GridCol[i].InheritedStyle.ForeColor),
    //                            new RectangleF((int)arrColumnLefts[iCount], iTopMargin,
    //                            (int)arrColumnWidths[iCount], iHeaderHeight), strFormat);
    //                        iCount++;
    //                    }
    //                    bNewPage = false;
    //                    iTopMargin += iHeaderHeight;
    //                }
    //                iCount = 0;
    //                DataGridViewCell[] _GridCell = new DataGridViewCell[GridRow.Cells.Count];
    //                int cellcount = 0;
    //                //Convert ltr to rtl
    //                foreach (DataGridViewCell Cel in GridRow.Cells)
    //                {
    //                    _GridCell[cellcount++] = Cel;
    //                }
    //                //Draw Columns Contents                
    //                //for (int i = (_GridCell.Count() - 1); i >= 0; i--)
    //                for (int i = 0; i < (_GridCell.Count() - 1); i++)
    //                {
    //                    if (_GridCell[i].Value != null)
    //                    {
    //                        e.Graphics.DrawString(_GridCell[i].FormattedValue.ToString(),
    //                            _GridCell[i].InheritedStyle.Font,
    //                            new SolidBrush(_GridCell[i].InheritedStyle.ForeColor),
    //                            new RectangleF((int)arrColumnLefts[iCount],
    //                            (float)iTopMargin,
    //                            (int)arrColumnWidths[iCount], (float)iCellHeight),
    //                            strFormat);
    //                    }
    //                    //Drawing Cells Borders 
    //                    e.Graphics.DrawRectangle(Pens.Black,
    //                        new Rectangle((int)arrColumnLefts[iCount], iTopMargin,
    //                        (int)arrColumnWidths[iCount], iCellHeight));
    //                    iCount++;
    //                }
    //            }
    //            iRow++;
    //            iTopMargin += iCellHeight;
    //        }
    //        //If more lines exist, print another page.
    //        if (bMorePagesToPrint)
    //            e.HasMorePages = true;
    //        else
    //            e.HasMorePages = false;
    //        //}
    //        //catch (Exception exc)
    //        //{
    //        //    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK,
    //        //       MessageBoxIcon.Error);
    //        //}
    //    }

    //    private void _printDocument_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
    //    {
    //        try
    //        {
    //            strFormat = new StringFormat();
    //            strFormat.Alignment = StringAlignment.Center;
    //            strFormat.LineAlignment = StringAlignment.Center;
    //            strFormat.Trimming = StringTrimming.EllipsisCharacter;

    //            arrColumnLefts.Clear();
    //            arrColumnWidths.Clear();
    //            iCellHeight = 0;
    //            iRow = 0;
    //            bFirstPage = true;
    //            bNewPage = true;

    //            // Calculating Total Widths
    //            iTotalWidth = 0;
    //            foreach (DataGridViewColumn dgvGridCol in gw.Columns)
    //            {
    //                iTotalWidth += dgvGridCol.Width;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //        }
    //    }

    //}

    //class myLabel : System.Windows.Forms.Label
    //{
    //    public int RotateAngle { get; set; }  // to rotate your text
    //    public string NewText { get; set; }   // to draw text
    //    protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
    //    {
    //        Brush b = new SolidBrush(this.ForeColor);
    //        e.Graphics.TranslateTransform(this.Width / 2, this.Height / 2);
    //        e.Graphics.RotateTransform(this.RotateAngle);
    //        e.Graphics.DrawString(this.NewText, this.Font, b, 0f, 0f);
    //        base.OnPaint(e);
    //    }
    //}
}
